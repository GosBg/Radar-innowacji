import React from 'react';
import { Heart } from 'lucide-react';

export default function FavoriteButton({ selected, onToggle, compact = false }) {
  return (
    <button
      type="button"
      className={`${compact ? 'icon' : 'favorite'} ${selected ? 'saved' : ''}`}
      aria-label={selected ? 'Usuń z ulubionych' : 'Dodaj do ulubionych'}
      aria-pressed={selected}
      onClick={onToggle}
    >
      <Heart size={19} fill={selected ? 'currentColor' : 'none'} />
    </button>
  );
}
