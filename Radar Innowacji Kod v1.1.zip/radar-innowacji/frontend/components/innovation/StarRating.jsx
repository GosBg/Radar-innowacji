import React, { useState } from 'react';

export default function StarRating({ value, onChange, label, disabled = false }) {
  const [hover, setHover] = useState(null);
  const displayed = hover ?? value ?? 0;
  return (
    <div className="stars" role="group" aria-label={label} onMouseLeave={() => setHover(null)}>
      {Array.from({ length: 10 }, (_, index) => {
        const rating = (index + 1) / 2;
        return (
          <button
            type="button"
            key={rating}
            disabled={disabled}
            aria-label={`${label}: ${rating} na 5`}
            aria-pressed={value === rating}
            className={`half ${index % 2 ? 'right' : 'left'}${displayed >= rating ? ' lit' : ''}`}
            onMouseEnter={() => setHover(rating)}
            onFocus={() => setHover(rating)}
            onBlur={() => setHover(null)}
            onClick={() => onChange(rating)}
          >
            <span aria-hidden="true">★</span>
          </button>
        );
      })}
      <b aria-live="polite">{value == null ? '—' : value.toFixed(1)}</b>
    </div>
  );
}
