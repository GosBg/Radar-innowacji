import React, { useState } from 'react';
import { Radar, Menu, Heart } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../ui/Button.jsx';
import ThemeToggle from './ThemeToggle.jsx';
import AccountMenu from './AccountMenu.jsx';

const links = [
  { page: 'discover', label: 'Odkrywaj' },
  { page: 'favorites', label: 'Ulubione', icon: Heart },
  { page: 'compare', label: 'Porównaj' },
  { page: 'future', label: 'Rozwój Radaru' },
];

export default function Header() {
  const { navigation, profile, favorites, setDialog } = useRadar();
  const [menuOpen, setMenuOpen] = useState(false);
  const go = (page) => {
    navigation.go(page);
    setMenuOpen(false);
  };
  const openProfile = () => {
    setDialog({ type: 'login' });
    setMenuOpen(false);
  };
  return (
    <>
      <div className="demo-bar">
        HACKNATION 2026 <span>Wersja BETA projektu strony Radar innowacji</span>
      </div>
      <a className="skip-link" href="#main-content">
        Przejdź do treści
      </a>
      <header className="topbar">
        <button
          className="brand"
          onClick={() => go('discover')}
          aria-label="Radar innowacji — strona główna"
        >
          <span className="brand-icon">
            <Radar size={28} />
          </span>
          <span>
            radar<span className="brand-light">innowacji</span>
            <small>ODKRYWAJ POLSKIE ROZWIĄZANIA</small>
          </span>
        </button>
        <Button
          variant="icon"
          className="mobile-menu"
          aria-label="Menu"
          aria-expanded={menuOpen}
          aria-controls="main-navigation"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <Menu />
        </Button>
        <nav id="main-navigation" aria-label="Główna nawigacja" className={menuOpen ? 'open' : ''}>
          {links.map(({ page, label, icon: Icon }) => (
            <button
              key={page}
              className={navigation.page === page ? 'active' : ''}
              aria-current={navigation.page === page ? 'page' : undefined}
              onClick={() => go(page)}
            >
              {Icon && <Icon size={17} />}
              {label}
              {page === 'favorites' && favorites.length > 0 && (
                <span className="count">{favorites.length}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="account account-stack">
          <div className="auth-links">
            {profile ? (
              <AccountMenu />
            ) : (
              <>
                <button onClick={openProfile}>Zaloguj</button>
                <span className="auth-divider" aria-hidden="true" />
                <button onClick={() => setDialog({ type: 'profile', create: true })}>
                  Zarejestruj
                </button>
              </>
            )}
          </div>
          <ThemeToggle />
        </div>
      </header>
    </>
  );
}
