import React, { useEffect, useState } from 'react';
export default function ThemeToggle() {
  const [dark, setDark] = useState(() => {
    try {
      return localStorage.getItem('radar-theme') === 'dark';
    } catch {
      return false;
    }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    try {
      localStorage.setItem('radar-theme', dark ? 'dark' : 'light');
    } catch {}
  }, [dark]);
  return (
    <button className="theme-toggle" aria-pressed={dark} onClick={() => setDark(!dark)}>
      {dark ? '☀ Tryb jasny' : '☾ Tryb ciemny'}
    </button>
  );
}
