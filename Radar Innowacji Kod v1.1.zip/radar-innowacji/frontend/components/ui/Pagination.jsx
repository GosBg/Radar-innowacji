import React from 'react';
import Button from './Button.jsx';
export default function Pagination({ page, setPage, total, limit = 12 }) {
  if (total <= limit) return null;
  return (
    <nav className="pagination" aria-label="Strony wyników">
      <Button variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)}>
        Poprzednia
      </Button>
      <span>
        {page} / {Math.ceil(total / limit)}
      </span>
      <Button variant="outline" disabled={page * limit >= total} onClick={() => setPage(page + 1)}>
        Następna
      </Button>
    </nav>
  );
}
