import React, { useEffect, useState } from 'react';
export default function Countdown({ until }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  if (!until) return <span>Bezterminowo</span>;
  let seconds = Math.max(0, Math.ceil((new Date(until) - now) / 1000));
  if (!seconds) return <span>Blokada wygasła. Możesz spróbować ponownie.</span>;
  const days = Math.floor(seconds / 86400);
  seconds %= 86400;
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  return (
    <span>
      {days} dni {hours} godz. {Math.floor(seconds / 60)} min {seconds % 60} sek.
    </span>
  );
}
