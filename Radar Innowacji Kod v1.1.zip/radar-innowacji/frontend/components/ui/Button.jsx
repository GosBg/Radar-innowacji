import React from 'react';

/** Shared behavior and styling; callers explicitly choose submit for forms. */
export default function Button({
  variant = 'primary',
  full = false,
  className = '',
  type = 'button',
  children,
  ...props
}) {
  return (
    <button
      type={type}
      className={[variant, full && 'full', className].filter(Boolean).join(' ')}
      {...props}
    >
      {children}
    </button>
  );
}
