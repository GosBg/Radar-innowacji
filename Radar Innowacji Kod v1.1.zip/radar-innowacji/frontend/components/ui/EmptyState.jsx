import React from 'react';
import { Search } from 'lucide-react';

export default function EmptyState({ title, description, icon: Icon = Search, children }) {
  return (
    <div className="empty">
      <Icon size={38} aria-hidden="true" />
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {children}
    </div>
  );
}
