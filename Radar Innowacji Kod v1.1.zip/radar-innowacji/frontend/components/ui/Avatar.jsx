import React from 'react';
import { Building2 } from 'lucide-react';

export default function Avatar({ profile, size = 'small' }) {
  if (profile?.avatar)
    return (
      <img
        className={`avatar avatar--${size}`}
        src={profile.avatar}
        alt={`Zdjęcie: ${profile.name}`}
      />
    );
  const initials = (profile?.name || '?')
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join('');
  return (
    <span className={`avatar avatar--${size}`} aria-hidden="true">
      {profile?.type === 'company' ? <Building2 size={17} /> : initials}
    </span>
  );
}
