import React from 'react';
import { Check, X } from 'lucide-react';
import Button from './Button.jsx';

export default function Toast({ message, onDismiss }) {
  if (!message) return null;
  return (
    <div className="toast" role="status">
      <Check size={20} />
      {message}
      <Button variant="icon" aria-label="Zamknij powiadomienie" onClick={onDismiss}>
        <X size={16} />
      </Button>
    </div>
  );
}
