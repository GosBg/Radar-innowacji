export const regions = [
  'Dolnośląskie',
  'Kujawsko-pomorskie',
  'Lubelskie',
  'Lubuskie',
  'Łódzkie',
  'Małopolskie',
  'Mazowieckie',
  'Opolskie',
  'Podkarpackie',
  'Podlaskie',
  'Pomorskie',
  'Śląskie',
  'Świętokrzyskie',
  'Warmińsko-mazurskie',
  'Wielkopolskie',
  'Zachodniopomorskie',
];
export const criteria = ['Dalszy rozwój', 'Transfer', 'Komercjalizacja', 'Wdrożenie'];
export const times = [
  ['Teraz', 0],
  ['Godzinę temu', 1 / 24],
  ['5 godzin temu', 5 / 24],
  ['10 godzin temu', 10 / 24],
  ['24 godziny temu', 1],
  ['3 dni temu', 3],
  ['5 dni temu', 5],
  ['Tydzień temu', 7],
  ['2 tygodnie temu', 14],
  ['Miesiąc temu', 30],
  ['3 miesiące temu', 90],
  ['6 miesięcy temu', 180],
  ['Rok temu', 365],
  ['2 lata temu', 730],
];

export const categories = ['Technologiczny', 'Edukacyjny', 'Administracyjny'];
export const stages = ['Nie ustalono', 'Koncepcja', 'Prototyp', 'Testy', 'Pilotaż', 'W praktyce'];
export const statusLabels = {
  rejected: 'Odrzucone',
  pending: 'Oczekuje na moderację',
  published: 'Opublikowane',
  archived: 'Archiwum',
};
export const DAY_MS = 86400000;
