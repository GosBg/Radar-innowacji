import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import { useRadar } from '../app/RadarContext.jsx';
export default function useRemoteIdeas({ scope = '', filters = {}, favorites = false } = {}) {
  const { ready, revision, mergeIdeas, profile } = useRadar();
  const [page, setPage] = useState(1),
    [data, setData] = useState({ items: [], total: 0, limit: 12 }),
    [error, setError] = useState(''),
    [loading, setLoading] = useState(true);
  const serialized = JSON.stringify(filters);
  useEffect(() => {
    setPage(1);
  }, [serialized, scope, favorites, profile?.id]);
  useEffect(() => {
    if (!ready) return;
    const controller = new AbortController();
    setLoading(true);
    const timer = setTimeout(() => {
      const params = new URLSearchParams({
        scope,
        filters: serialized,
        favorites: String(favorites),
        page: String(page),
      });
      api(`/ideas?${params}`, { signal: controller.signal })
        .then((result) => {
          setData(result);
          mergeIdeas(result.items);
          setError('');
        })
        .catch((e) => {
          if (e.name !== 'AbortError') {
            setError(e.message);
            setData({ items: [], total: 0, limit: 12 });
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    }, 150);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [ready, revision, serialized, scope, favorites, page, profile?.id, mergeIdeas]);
  return { ...data, page, setPage, error, loading };
}
