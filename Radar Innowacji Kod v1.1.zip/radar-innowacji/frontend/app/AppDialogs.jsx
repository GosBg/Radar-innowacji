import React from 'react';
import { useRadar } from './RadarContext.jsx';
import ProfileDialog from '../features/profiles/ProfileDialog.jsx';
import LoginDialog from '../features/profiles/LoginDialog.jsx';

import IdeaDetailDialog from '../features/innovations/IdeaDetailDialog.jsx';
import DeleteIdeaDialog from '../features/moderation/DeleteIdeaDialog.jsx';
import HowItWorksDialog from '../features/help/HowItWorksDialog.jsx';
import ContactDialog from '../features/help/ContactDialog.jsx';
import TokenDialog from '../features/profiles/TokenDialog.jsx';
import SanctionNotice from '../features/moderation/SanctionNotice.jsx';
import SanctionDialog from '../features/moderation/SanctionDialog.jsx';
import ReportDialog from '../features/moderation/ReportDialog.jsx';
import ReportContextDialog from '../features/moderation/ReportContextDialog.jsx';
import AdminActionDialog from '../features/moderation/AdminActionDialog.jsx';

/** Exactly one modal at a time, so focus and Escape have a single owner. */
export default function AppDialogs() {
  const { dialog, closeDialog, setDialog, navigation } = useRadar();
  switch (dialog?.type) {
    case 'contact':
      return <ContactDialog onClose={closeDialog} />;
    case 'token':
      return <TokenDialog onClose={closeDialog} />;
    case 'sanction':
      return <SanctionNotice {...dialog} onClose={closeDialog} />;
    case 'setSanction':
      return <SanctionDialog {...dialog} onClose={closeDialog} />;
    case 'report':
      return <ReportDialog {...dialog} onClose={closeDialog} />;
    case 'reportContext':
      return <ReportContextDialog {...dialog} onClose={closeDialog} />;
    case 'reject':
      return <AdminActionDialog {...dialog} action="reject" onClose={closeDialog} />;
    case 'deleteAccount':
      return <AdminActionDialog {...dialog} action="deleteAccount" onClose={closeDialog} />;
    case 'profile':
      return (
        <ProfileDialog
          key={dialog.create ? 'create' : 'edit'}
          create={dialog.create}
          onClose={closeDialog}
          onSaved={closeDialog}
        />
      );
    case 'login':
      return <LoginDialog onClose={closeDialog} />;

    case 'delete':
      return <DeleteIdeaDialog ideaId={dialog.ideaId} onClose={closeDialog} />;
    case 'how':
      return <HowItWorksDialog onClose={closeDialog} />;
    default:
      return navigation.ideaId ? (
        <IdeaDetailDialog ideaId={navigation.ideaId} onClose={navigation.closeIdea} />
      ) : null;
  }
}
