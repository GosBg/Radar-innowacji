/** Lexical heuristics shared with the server; they are signals, not semantic guarantees. */
export function containsProfanity(text) {
  return /(?:^|[^\p{L}])(kurw[\p{L}]*|chuj[\p{L}]*|pierdol[\p{L}]*|jeba[\p{L}]*)(?=$|[^\p{L}])/iu.test(
    text.normalize('NFKC'),
  );
}

function words(text) {
  return new Set(text.toLocaleLowerCase('pl').match(/[\p{L}]{4,}/gu) || []);
}

export function findSimilarInnovation(draft, items) {
  const draftWords = words(`${draft.title} ${draft.description}`);
  if (!draftWords.size) return null;
  const matches = items
    .filter((item) => item.status === 'published')
    .map((item) => {
      const existing = words(`${item.title} ${item.description}`);
      const overlap = [...draftWords].filter((word) => existing.has(word)).length;
      return { id: item.id, similarity: overlap / draftWords.size };
    });
  return (
    matches.filter((item) => item.similarity > 0.28).sort((a, b) => b.similarity - a.similarity)[0]
      ?.id ?? null
  );
}

export function publishInnovation(item, now = Date.now()) {
  return { ...item, status: 'published', publishedAt: item.publishedAt ?? now };
}

export function removeInnovation(state, id) {
  const ratings = { ...state.ratings };
  delete ratings[id];
  return {
    ...state,
    items: state.items
      .filter((item) => item.id !== id)
      .map((item) => (item.similar === id ? { ...item, similar: null } : item)),
    favorites: Object.fromEntries(
      Object.entries(state.favorites).map(([owner, ids]) => [
        owner,
        ids.filter((value) => value !== id),
      ]),
    ),
    ratings,
  };
}
