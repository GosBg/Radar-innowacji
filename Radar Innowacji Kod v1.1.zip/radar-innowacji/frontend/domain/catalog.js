import { criteria, DAY_MS, times } from '../data/constants.js';
import { summarizeRatings } from './ratings.js';

export function createFilters() {
  return {
    query: '',
    category: 'Wszystkie',
    author: 'all',
    age: times.length - 1,
    days: ['', ''],
    bounds: criteria.map(() => ['', '']),
    sort: 'new',
    period: 'all',
  };
}

export function validateFilters(filters) {
  const [from, to] = filters.days;
  if (
    [from, to].some(
      (value) => value !== '' && (!Number.isFinite(+value) || +value < 0 || +value > 730),
    )
  ) {
    return 'Podaj liczbę dni od 0 do 730.';
  }
  if (from !== '' && to !== '' && +from > +to)
    return 'Początek przedziału nie może być większy niż koniec.';
  if (filters.bounds.some(([min, max]) => min !== '' && max !== '' && +min > +max)) {
    return 'Minimalna ocena nie może przekraczać maksymalnej.';
  }
  return '';
}

/** Rankings use publication time, not the time at which individual votes were cast. */
export function filterInnovations(
  items,
  filters,
  { favorites = [], onlyFavorites = false, ratings = {}, now = Date.now() } = {},
) {
  if (validateFilters(filters)) return [];
  const query = filters.query.trim().toLocaleLowerCase('pl');
  const lower = filters.days[0] === '' ? 0 : +filters.days[0];
  // The first slider stop means the last hour; an exact instant cannot be selected usefully.
  const upper = filters.days[1] === '' ? Math.max(times[filters.age][1], 1 / 24) : +filters.days[1];
  const visible = items.filter((item) => {
    const daysOld = Math.max(0, (now - (item.publishedAt ?? item.created)) / DAY_MS);
    const scores = summarizeRatings(item, ratings).categories;
    return (
      item.status === 'published' &&
      (!onlyFavorites || favorites.includes(item.id)) &&
      (filters.category === 'Wszystkie' || item.category === filters.category) &&
      (!query ||
        `${item.title} ${item.description} ${item.author}`
          .toLocaleLowerCase('pl')
          .includes(query)) &&
      (filters.author === 'all' || item.type === filters.author) &&
      daysOld >= lower &&
      daysOld <= upper &&
      (filters.period === 'all' || daysOld <= +filters.period) &&
      filters.bounds.every(([min, max], index) => {
        if (min === '' && max === '') return true;
        return (
          scores[index] != null &&
          (min === '' || scores[index] >= +min) &&
          (max === '' || scores[index] <= +max)
        );
      })
    );
  });
  return visible.sort((a, b) =>
    filters.sort === 'rating'
      ? (summarizeRatings(b, ratings).overall ?? -1) - (summarizeRatings(a, ratings).overall ?? -1)
      : (b.publishedAt ?? b.created) - (a.publishedAt ?? a.created),
  );
}
