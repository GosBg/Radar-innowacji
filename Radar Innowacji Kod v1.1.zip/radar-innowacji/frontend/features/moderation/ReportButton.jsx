import React from 'react';

import { useRadar } from '../../app/RadarContext.jsx';
export default function ReportButton({ kind = 'idea', targetId, owner }) {
  const { profile, setDialog } = useRadar();
  if (!profile || profile.id === owner) return null;
  const label = kind === 'idea' ? 'Zgłoś błąd w karcie' : 'Zgłoś komentarz';
  return (
    <button
      type="button"
      className="report-button"
      aria-label={label}
      onClick={() => setDialog({ type: 'report', kind, targetId })}
    >
      <span className="report-mark" aria-hidden="true">
        !
      </span>
      <span>{label}</span>
    </button>
  );
}
