import React, { useState } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
export default function SanctionDialog({ userId, kind, onClose }) {
  const { refresh } = useRadar();
  const [draft, setDraft] = useState({
      kind,
      reason: '',
      days: 0,
      hours: 1,
      seconds: 0,
      permanent: false,
    }),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const duration = draft.days * 86400 + draft.hours * 3600 + draft.seconds;
  const update = (key, value) =>
    setDraft((d) => ({
      ...d,
      [key]: value,
      ...(key === 'days' && value === 365 ? { hours: 0, seconds: 0 } : {}),
    }));
  return (
    <Modal
      title={kind === 'post' ? 'Zablokuj dodawanie pomysłów' : 'Wycisz komentowanie'}
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            await api(`/admin/users/${userId}/sanctions`, { method: 'POST', body: draft });
            await refresh();
            onClose();
          } catch (e) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label>
          Powód widoczny dla użytkownika
          <textarea
            required
            minLength={5}
            maxLength={2000}
            value={draft.reason}
            onChange={(e) => update('reason', e.target.value)}
          />
        </label>
        {kind === 'post' && (
          <label className="check-field">
            <input
              type="checkbox"
              checked={draft.permanent}
              onChange={(e) => update('permanent', e.target.checked)}
            />
            Blokada permanentna
          </label>
        )}
        {!draft.permanent && (
          <>
            <label>
              Czas: {draft.days} dni, {draft.hours} godz., {draft.seconds} sek.
              <input
                type="range"
                min={3600}
                max={31536000}
                step={3600}
                value={Math.max(3600, duration)}
                onChange={(e) => {
                  const total = +e.target.value;
                  setDraft((d) => ({
                    ...d,
                    days: Math.floor(total / 86400),
                    hours: Math.floor((total % 86400) / 3600),
                    seconds: 0,
                  }));
                }}
              />
            </label>
            <div className="three-fields">
              {[
                ['days', 'Dni', 365],
                ['hours', 'Godziny', 23],
                ['seconds', 'Sekundy', 3599],
              ].map(([key, label, max]) => (
                <label key={key}>
                  {label}
                  <input
                    type="number"
                    min={0}
                    max={max}
                    step={1}
                    required
                    disabled={draft.days === 365 && key !== 'days'}
                    value={draft[key]}
                    onChange={(e) =>
                      update(key, Math.min(max, Math.max(0, Number(e.target.value))))
                    }
                  />
                </label>
              ))}
            </div>
            <p className="muted">
              Od 1 godziny do 365 dni. Przy 365 dniach godziny i sekundy wynoszą zero.
            </p>
          </>
        )}
        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}
        <Button full type="submit" disabled={busy || (!draft.permanent && duration < 3600)}>
          Zastosuj {kind === 'post' ? 'blokadę' : 'wyciszenie'}
        </Button>
      </form>
    </Modal>
  );
}
