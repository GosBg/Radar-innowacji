import React from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';

export default function DeleteIdeaDialog({ ideaId, onClose }) {
  const { state, innovations, handleError } = useRadar();
  const idea = state.items.find((item) => item.id === ideaId);
  return (
    <Modal title="Usunąć innowację?" onClose={onClose}>
      <p>Usunięcie „{idea?.title}” wraz z ocenami i załącznikami jest nieodwracalne.</p>
      <Button
        variant="danger"
        full
        onClick={async () => {
          try {
            await innovations.deleteIdea(ideaId);
            onClose();
          } catch (error) {
            handleError(error);
          }
        }}
      >
        Usuń innowację
      </Button>
      <Button variant="outline" full onClick={onClose}>
        Anuluj
      </Button>
    </Modal>
  );
}
