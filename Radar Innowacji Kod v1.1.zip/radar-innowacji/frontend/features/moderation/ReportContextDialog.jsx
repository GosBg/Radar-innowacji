import React, { useState, useEffect } from 'react';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import { api } from '../../api/client.js';
export default function ReportContextDialog({ reportId, onClose }) {
  const [data, setData] = useState(null),
    [error, setError] = useState('');
  useEffect(() => {
    api(`/admin/reports/${reportId}/context`)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [reportId]);
  return (
    <Modal title="Kontekst zgłoszonego komentarza" onClose={onClose}>
      {error && <p role="alert">{error}</p>}
      {!data && !error && <p>Wczytywanie…</p>}
      {data?.comments.map((c) => (
        <article
          className={c.id === data.reportedCommentId ? 'notice field-error' : 'comment'}
          key={c.id}
        >
          <b>{c.author || 'Usunięte konto'}</b>
          {c.id === data.reportedCommentId && <strong> · Zgłoszony komentarz</strong>}
          <p>{c.body}</p>
          {!c.hidden && (
            <Button
              variant="outline"
              onClick={async () => {
                try {
                  await api(`/comments/${c.id}`, { method: 'DELETE' });
                  setData((d) => ({
                    ...d,
                    comments: d.comments.map((x) =>
                      x.id === c.id ? { ...x, hidden: true, body: 'Komentarz usunięty.' } : x,
                    ),
                  }));
                } catch (e) {
                  setError(e.message);
                }
              }}
            >
              Usuń komentarz
            </Button>
          )}
        </article>
      ))}
    </Modal>
  );
}
