import React, { useState } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
export default function ReportDialog({ kind, targetId, onClose }) {
  const { refresh, notify } = useRadar();
  const [reason, setReason] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  return (
    <Modal title={kind === 'idea' ? 'Zgłoś błąd w karcie' : 'Zgłoś komentarz'} onClose={onClose}>
      <p>
        {kind === 'comment'
          ? 'Administrator będzie mógł odczytać ten komentarz w celu rozpatrzenia zgłoszenia.'
          : 'Napisz, co administrator powinien sprawdzić.'}
      </p>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            await api('/reports', { method: 'POST', body: { kind, targetId, reason } });
            await refresh();
            notify('Zgłoszenie wysłane do administratora.');
            onClose();
          } catch (e) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label>
          Powód zgłoszenia
          <textarea
            required
            minLength={5}
            maxLength={2000}
            rows={4}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
        </label>
        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}
        <Button type="submit" full disabled={busy}>
          Wyślij zgłoszenie
        </Button>
      </form>
    </Modal>
  );
}
