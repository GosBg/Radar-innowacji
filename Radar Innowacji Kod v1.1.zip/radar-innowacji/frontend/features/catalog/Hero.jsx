import React from 'react';
import {
  Plus,
  ShieldCheck,
  Radar,
  Leaf,
  Lightbulb,
  Check,
  Activity,
  Building2,
  Users,
  Layers,
} from 'lucide-react';
export default function Hero({ onSubmit, onHow }) {
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">
            <span /> POLSKIE INNOWACJE. SPRAWDZALNE ŹRÓDŁA.
          </div>
          <h1>
            Realne wyzwania.
            <br />
            <em>Odkryte rozwiązania.</em>
          </h1>
          <p>
            Znajdź istniejące innowacje dla swojej organizacji.
            <br />
            Porównuj zastosowania, źródła i poziom rozwoju.
          </p>
          <div className="hero-actions">
            <button className="primary" onClick={onSubmit}>
              <Plus size={18} /> Znajdź rozwiązanie
            </button>
            <button className="text-button" onClick={onHow}>
              Jak to działa?
            </button>
          </div>
          <div className="hero-note">
            <ShieldCheck size={17} /> Automatyczny research · źródła sprawdzane cyklicznie
          </div>
        </div>
        <div className="radar-visual" aria-hidden="true">
          <div className="radar-grid" />
          <div className="radar-ring r1" />
          <div className="radar-ring r2" />
          <div className="radar-ring r3" />
          <div className="radar-sweep" />
          <div className="radar-center">
            <Radar size={44} />
          </div>
          <div className="signal signal1">
            <Leaf size={23} />
            <div>
              Zielona przyszłość<small>Energia i środowisko</small>
            </div>
          </div>
          <div className="signal signal2">
            <Lightbulb size={24} />
            <div>
              Potencjał odkryty<small>Czas na kolejny krok</small>
            </div>
            <span className="signal-check">
              <Check size={14} />
            </span>
          </div>
          <div className="signal signal3">
            <Activity size={23} />
          </div>
          <i className="point p1" />
          <i className="point p2" />
          <span className="radar-label">OD ŹRÓDŁA DO ZASTOSOWANIA</span>
        </div>
      </section>
      <div className="trust-strip">
        <span>Wiedza dla każdej organizacji.</span>
        <span>
          <Building2 /> Uczelnie i instytucje
        </span>
        <span>
          <Users /> Administracja i edukacja
        </span>
        <span>
          <Layers /> Biznes i partnerzy
        </span>
        <b>Jeden wspólny kierunek.</b>
      </div>
    </>
  );
}
