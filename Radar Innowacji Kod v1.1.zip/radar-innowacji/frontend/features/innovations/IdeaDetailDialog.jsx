import React from 'react';
import EvidencePanel from '../research/EvidencePanel.jsx';
import Comments from '../research/Comments.jsx';
import { Mail, Star } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { criteria } from '../../data/constants.js';
import { summarizeRatings, formatRating, getRecommendation } from '../../domain/ratings.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import Avatar from '../../components/ui/Avatar.jsx';
import InnovationArt from '../../components/innovation/InnovationArt.jsx';
import FavoriteButton from '../../components/innovation/FavoriteButton.jsx';
import StarRating from '../../components/innovation/StarRating.jsx';
import ReportButton from '../moderation/ReportButton.jsx';
import { api } from '../../api/client.js';

export default function IdeaDetailDialog({ ideaId, onClose }) {
  const { state, profile, favorites, innovations, openConversation, setDialog, handleError } =
    useRadar();

  const idea = state.items.find((item) => item.id === ideaId);
  if (!idea)
    return (
      <Modal title="Wczytywanie karty" onClose={onClose}>
        <p>Pobieramy dane źródłowe. Jeśli karta jest niedostępna, wróć do katalogu.</p>
        <Button full onClick={onClose}>
          Wróć do strony
        </Button>
      </Modal>
    );
  const summary = summarizeRatings(idea, state.ratings);
  const recommendation = getRecommendation(summary);
  const ballot = idea.ballot || [];
  const author = state.profiles.find((candidate) => candidate.id === idea.owner);
  const mayRate = Boolean(profile && idea.status === 'published');

  return (
    <Modal title="Poznaj innowację" onClose={onClose}>
      <InnovationArt kind={idea.art} />
      <div className="detail-meta">
        <span className="tag">{idea.category}</span>
        <span>{idea.stage}</span>
      </div>
      <h2>{idea.title}</h2>
      <p className="idea-description">{idea.description}</p>
      <EvidencePanel idea={idea} />
      <ReportButton targetId={idea.id} owner={idea.owner} />
      {profile?.role === 'admin' && (
        <Button
          variant="danger-text"
          onClick={() => setDialog({ type: 'delete', ideaId: idea.id })}
        >
          Usuń innowację
        </Button>
      )}
      <div className="author-row">
        <Avatar
          profile={author || { name: idea.author, type: idea.type, avatar: idea.authorAvatar }}
        />
        <div>
          <b>{idea.author}</b>
          <small>{idea.creatorType}</small>
        </div>
        <FavoriteButton
          compact
          selected={favorites.includes(idea.id)}
          onToggle={() => innovations.toggleFavorite(idea.id)}
        />
      </div>
      <h3>Opinia społeczności o potencjale</h3>
      <p className="muted">Gwiazdki są opinią, nie dowodem wdrożenia ani oceną TRL.</p>
      <p className="muted">
        Każdy głos od 0,5 do 5 ma równą wagę. Średnia obejmuje tylko oddane oceny. Ponowne
        kliknięcie zmienia Twój głos.
      </p>
      {!profile && (
        <Button variant="outline" full onClick={() => setDialog({ type: 'login' })}>
          Wybierz profil, aby oceniać
        </Button>
      )}
      {idea.status !== 'published' && (
        <p className="notice">Oceny są dostępne dopiero po publikacji.</p>
      )}
      {criteria.map((criterion, index) => (
        <div className="rating-row" key={criterion}>
          <div>
            <span>{criterion}</span>
            <small className="criterion-average">
              Średnia: {formatRating(summary.categories[index])}
            </small>
          </div>
          <StarRating
            label={criterion}
            value={ballot[index]}
            disabled={!mayRate}
            onChange={(value) => innovations.rateIdea(idea.id, index, value)}
          />
        </div>
      ))}
      <div className="overall">
        <b>Ogólna ocena użytkowników</b>
        <span>
          <Star size={18} fill="currentColor" />
          {formatRating(summary.overall)}
          {summary.overall != null && ' / 5'}
        </span>
      </div>
      <p className="notice">
        {recommendation
          ? `Sugestia kolejnego kroku: ${recommendation}. Wynika z najwyżej ocenionego obszaru; wymaga rozmowy z ekspertem.`
          : 'Brak ocen — za wcześnie na rekomendację ścieżki rozwoju.'}
      </p>
      <Comments ideaId={idea.id} />
    </Modal>
  );
}
