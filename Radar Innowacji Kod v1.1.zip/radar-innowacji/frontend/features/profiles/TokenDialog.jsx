import React, { useState } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
export default function TokenDialog({ onClose }) {
  const params = new URLSearchParams(location.search),
    kind = params.get('auth'),
    token = params.get('token');
  const { bootstrap } = useRadar();
  const [password, setPassword] = useState(''),
    [result, setResult] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const close = () => {
    history.replaceState({}, '', location.pathname);
    onClose();
  };
  return (
    <Modal title={kind === 'reset' ? 'Ustaw nowe hasło' : 'Potwierdź adres e-mail'} onClose={close}>
      {result ? (
        <>
          <p role="status">{result}</p>
          <Button full onClick={close}>
            Gotowe
          </Button>
        </>
      ) : (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              const data = await api('/auth/token', {
                method: 'POST',
                body: { kind, token, ...(kind === 'reset' ? { password } : {}) },
              });
              setResult(data.message);
              await bootstrap();
            } catch (e) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          {kind === 'reset' && (
            <label>
              Nowe hasło
              <input
                required
                type="password"
                minLength={12}
                maxLength={128}
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </label>
          )}
          {error && (
            <p className="field-error" role="alert">
              {error}
            </p>
          )}
          <Button full type="submit" disabled={busy}>
            Potwierdź
          </Button>
        </form>
      )}
    </Modal>
  );
}
