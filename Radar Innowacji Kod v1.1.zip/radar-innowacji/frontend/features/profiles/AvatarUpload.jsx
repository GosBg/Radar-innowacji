import React, { useState } from 'react';
import { validateAvatar } from '../../domain/validation.js';
import Avatar from '../../components/ui/Avatar.jsx';
import Button from '../../components/ui/Button.jsx';

export default function AvatarUpload({ value, name, onChange, onBusy }) {
  const [error, setError] = useState('');
  async function readFile(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const validation = validateAvatar(file);
    setError(validation);
    if (validation) {
      event.target.value = '';
      return;
    }
    onBusy(true);
    try {
      const data = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      // Check that the selected bytes are a decodable image, not just a renamed file.
      await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = resolve;
        image.onerror = reject;
        image.src = data;
      });
      onChange(data);
    } catch {
      setError('Nie można odczytać tego zdjęcia. Wybierz inny plik.');
    } finally {
      onBusy(false);
    }
  }
  return (
    <div className="avatar-upload">
      <Avatar profile={{ name, avatar: value }} size="large" />
      <label>
        Zdjęcie profilowe (PNG/JPG, do 5 MB)
        <input type="file" accept="image/png,image/jpeg" onChange={readFile} />
      </label>
      {value && (
        <Button variant="outline" onClick={() => onChange('')}>
          Usuń zdjęcie z formularza
        </Button>
      )}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
