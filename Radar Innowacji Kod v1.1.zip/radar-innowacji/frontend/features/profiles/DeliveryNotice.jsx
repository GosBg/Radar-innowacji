import React from 'react';
export default function DeliveryNotice({ delivery }) {
  if (!delivery) return null;
  return (
    <div className="notice">
      <p>{delivery.message}</p>
      {delivery.developmentLink && (
        <p>
          Lokalna skrzynka deweloperska — poczta SMTP nie jest podłączona.
          <br />
          <a href={delivery.developmentLink}>Otwórz link do potwierdzenia operacji</a>
        </p>
      )}
    </div>
  );
}
