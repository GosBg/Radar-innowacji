import React, { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../../components/ui/Button.jsx';
import ReportButton from '../moderation/ReportButton.jsx';
export default function Comments({ ideaId }) {
  const { profile, setDialog, handleError } = useRadar();
  const [items, setItems] = useState([]),
    [page, setPage] = useState(1),
    [total, setTotal] = useState(0),
    [body, setBody] = useState(''),
    [reply, setReply] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  async function refresh() {
    const data = await api(`/ideas/${ideaId}/comments?page=${page}`);
    setItems(data.items);
    setTotal(data.total);
  }
  useEffect(() => {
    refresh().catch((e) => setError(e.message));
  }, [ideaId, page]);
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    try {
      await api(`/ideas/${ideaId}/comments`, {
        method: 'POST',
        body: { body, parentId: reply?.id || null },
      });
      setBody('');
      setReply(null);
      await refresh();
    } catch (e) {
      handleError(e);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="comments">
      <h3>Dyskusja o zastosowaniu ({total})</h3>
      <p className="muted">
        Pytania, doświadczenia i uwagi do tego rozwiązania. Komentarze nie zmieniają danych
        źródłowych.
      </p>
      {error && <p role="alert">{error}</p>}
      {items.map((c) => (
        <article className={`comment ${c.parent_id ? 'comment-reply' : ''}`} key={c.id}>
          <b>{c.author}</b>
          <small> · {new Date(c.created_at).toLocaleString('pl')}</small>
          {c.parent_id && (
            <small className="muted">
              Odpowiedź do:{' '}
              {items.find((x) => x.id === c.parent_id)?.author ||
                'komentarza z innej strony dyskusji'}
            </small>
          )}
          <p className="preserve-lines">{c.body}</p>
          {!c.hidden && (
            <div className="row-actions">
              {!c.parent_id && profile && (
                <button
                  onClick={() => {
                    setReply(c);
                    document.getElementById('comment-body')?.focus();
                  }}
                >
                  Odpowiedz
                </button>
              )}
              <ReportButton kind="comment" targetId={c.id} owner={c.user_id} />
              {(profile?.id === c.user_id || ['admin', 'moderator'].includes(profile?.role)) && (
                <button
                  onClick={async () => {
                    try {
                      await api(`/comments/${c.id}`, { method: 'DELETE' });
                      await refresh();
                    } catch (e) {
                      handleError(e);
                    }
                  }}
                >
                  Usuń komentarz
                </button>
              )}
            </div>
          )}
        </article>
      ))}
      {total > 50 && (
        <div className="row-actions">
          <Button variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)}>
            Poprzednie
          </Button>
          <span>Strona {page}</span>
          <Button variant="outline" disabled={page * 50 >= total} onClick={() => setPage(page + 1)}>
            Następne
          </Button>
        </div>
      )}
      {profile ? (
        <form onSubmit={submit} className="comment-form">
          {reply && (
            <p>
              Odpowiadasz: {reply.author}{' '}
              <button type="button" onClick={() => setReply(null)}>
                Anuluj odpowiedź
              </button>
            </p>
          )}
          <label htmlFor="comment-body">{reply ? 'Twoja odpowiedź' : 'Twój komentarz'}</label>
          <textarea
            id="comment-body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={2000}
            required
            rows={3}
          />
          <Button disabled={busy || !body.trim()}>
            {busy ? 'Zapisywanie…' : 'Dodaj komentarz'}
          </Button>
        </form>
      ) : (
        <Button variant="outline" onClick={() => setDialog({ type: 'login' })}>
          Zaloguj, aby komentować
        </Button>
      )}
    </section>
  );
}
