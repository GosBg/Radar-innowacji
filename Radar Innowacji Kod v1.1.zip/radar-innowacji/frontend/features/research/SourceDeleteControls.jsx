import React, { useState } from 'react';
import Button from '../../components/ui/Button.jsx';
import Modal from '../../components/ui/Modal.jsx';
export default function SourceDeleteControls({
  selecting,
  selected,
  busy,
  onStart,
  onCancel,
  onDelete,
  onAdd,
}) {
  const [confirm, setConfirm] = useState(false);
  const [error, setError] = useState('');
  return (
    <>
      <div className="source-toolbar">
        {selecting ? (
          <>
            <Button
              variant="danger"
              disabled={!selected.length || busy}
              onClick={() => {
                setError('');
                setConfirm(true);
              }}
            >
              Usuń ({selected.length})
            </Button>
            <button className="source-cancel" disabled={busy} onClick={onCancel}>
              Anuluj zaznaczanie
            </button>
          </>
        ) : (
          <>
            <Button onClick={onAdd}>Dodaj źródło</Button>
            <Button variant="outline" disabled={busy} onClick={onStart}>
              Usuń źródło
            </Button>
          </>
        )}
      </div>
      {confirm && (
        <Modal
          title="Czy na pewno chcesz usunąć trwale?"
          onClose={() => !busy && setConfirm(false)}
        >
          <p>
            Wybrane źródła: {selected.length}. Usuniemy konfigurację pobierania i historię
            przebiegów. Istniejące karty oraz linki do materiałów pozostaną dostępne.
          </p>
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <div className="row-actions">
            <Button
              variant="danger"
              disabled={busy}
              onClick={async () => {
                if (await onDelete()) setConfirm(false);
                else
                  setError(
                    'Nie udało się usunąć źródeł. Zamknij okno i sprawdź komunikat na liście źródeł.',
                  );
              }}
            >
              {busy ? 'Usuwanie…' : 'Tak'}
            </Button>
            <Button variant="outline" disabled={busy} onClick={() => setConfirm(false)}>
              Nie
            </Button>
          </div>
        </Modal>
      )}
    </>
  );
}
