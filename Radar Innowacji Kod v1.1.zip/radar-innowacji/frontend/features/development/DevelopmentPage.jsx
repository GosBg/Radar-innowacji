import React from 'react';
import { Lightbulb, Layers } from 'lucide-react';
export default function DevelopmentPage() {
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <span className="large-icon">
        <Lightbulb />
      </span>
      <div className="eyebrow dark">KOLEJNY ROZDZIAŁ</div>
      <h1>
        Innowacje nie mają
        <br />
        ostatniego rozdziału.
      </h1>
      <p>Tu można dalej rozwijać ten projekt o dodatkowe rzeczy.</p>
      <div className="future-grid">
        {[
          'Integracje z bazami patentowymi',
          'Semantyczne wyszukiwanie zastosowań',
          'Eksport raportów wdrożeniowych',
        ].map((t) => (
          <div className="panel" key={t}>
            <Layers />
            <h3>{t}</h3>
            <span className="tag">W planach</span>
          </div>
        ))}
      </div>
    </main>
  );
}
