import React from 'react';
import Modal from '../../components/ui/Modal.jsx';
export default function HowItWorksDialog({ onClose }) {
  return (
    <Modal title="Jak działa Radar?" onClose={onClose}>
      <ol>
        <li>Worker pobiera opisy istniejących rozwiązań z aktywnych źródeł.</li>
        <li>
          Reguły językowe porządkują obszar, rodzaj podmiotu i etap. Niepewne informacje są
          oznaczone.
        </li>
        <li>Każda karta pokazuje źródła, czas odczytu i podstawę klasyfikacji.</li>
        <li>Wyszukujesz według problemu, filtrujesz i porównujesz rozwiązania.</li>
        <li>Konto pozwala zapisywać ulubione, oceniać potencjał i dyskutować o zastosowaniu.</li>
        <li>
          Źródła są sprawdzane w cyklach co 24 godziny. Administrator zarządza integracjami i
          wyjątkami.
        </li>
      </ol>
      <p>
        Radar nie przyjmuje nowych pomysłów, nie prowadzi prywatnych rozmów ani zbiórek
        finansowania. Analiza nie zastępuje audytu dojrzałości lub badania patentowego.
      </p>
    </Modal>
  );
}
