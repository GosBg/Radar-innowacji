import React from 'react';
import Modal from '../../components/ui/Modal.jsx';
export default function ContactDialog({ onClose }) {
  return (
    <Modal title="Kontakt do administratora" onClose={onClose}>
      <p>
        <a href="mailto:admin@radarinnowacji.pl">admin@radarinnowacji.pl</a>
      </p>
      <p>
        <a href="tel:+48100010001">+48 100 010 001</a>
      </p>
      <h3>Godziny kontaktu telefonicznego</h3>
      <dl className="contact-hours">
        <dt>Poniedziałek–piątek</dt>
        <dd>8:00–16:00</dd>
        <dt>Sobota</dt>
        <dd>9:00–19:00</dd>
        <dt>Niedziela</dt>
        <dd>10:00–15:00</dd>
      </dl>
    </Modal>
  );
}
