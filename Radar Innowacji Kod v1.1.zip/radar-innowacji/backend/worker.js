import { configuration } from './config.js';
import { connectDatabase } from './db/connection.js';
import { seedSources } from './research/sources.js';
import { runDue } from './research/pipeline.js';
const db = await connectDatabase(configuration());
await seedSources(db);
let stopping = false;
for (const signal of ['SIGINT', 'SIGTERM'])
  process.on(signal, () => {
    stopping = true;
  });
const heartbeat = setInterval(
  () =>
    db
      .query(
        "INSERT INTO worker_status VALUES('research',now()) ON CONFLICT(id) DO UPDATE SET heartbeat_at=now()",
      )
      .catch(console.error),
  15000,
);
await db.query(
  "INSERT INTO worker_status VALUES('research',now()) ON CONFLICT(id) DO UPDATE SET heartbeat_at=now()",
);
console.log('Worker Radaru: trwały harmonogram PostgreSQL, cykl źródła co 24 h.');
while (!stopping) {
  await runDue(db).catch((error) => console.error('Worker:', error.message));
  for (let second = 0; second < 60 && !stopping; second++)
    await new Promise((resolve) => setTimeout(resolve, 1000));
}
clearInterval(heartbeat);
await db.close();
