import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import { requireRole, durationSeconds, audit } from '../lib/policy.js';
import { sanctionInput } from '../lib/validation.js';

export function adminRoutes({ db, mail }) {
  const router = Router();
  router.use((req, res, next) => {
    try {
      requireRole(req, 'admin');
      next();
    } catch (error) {
      next(error);
    }
  });
  router.get(
    '/users',
    route(async (req, res) => {
      const page = z.coerce
        .number()
        .int()
        .min(1)
        .max(10000)
        .parse(req.query.page || 1);
      const rows = (
        await db.query(
          'SELECT u.id,u.name,u.login,u.email,u.account_type,u.role,u.email_verified,u.example,EXISTS(SELECT 1 FROM memberships m JOIN organizations o ON o.id=m.organization_id WHERE m.user_id=u.id AND o.verified) AS verified FROM users u ORDER BY u.created_at,u.id LIMIT 25 OFFSET $1',
          [(page - 1) * 25],
        )
      ).rows;
      const sanctions = (
        await db.query(
          'SELECT user_id,kind,reason,expires_at FROM sanctions WHERE user_id=ANY($1::uuid[]) AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>now())',
          [rows.map((r) => r.id)],
        )
      ).rows;
      await audit(db, req.user, 'accounts.read', null, { page });
      res.json({
        items: rows.map((r) => ({ ...r, sanctions: sanctions.filter((s) => s.user_id === r.id) })),
        page,
        total: (await db.query('SELECT count(*)::int AS total FROM users')).rows[0].total,
      });
    }),
  );
  async function target(id) {
    z.string().uuid().parse(id);
    const user = (await db.query('SELECT * FROM users WHERE id=$1', [id])).rows[0];
    ensure(user, 404, 'Brak konta.');
    ensure(user.role !== 'admin', 403, 'Konta administratorów są chronione przed tą operacją.');
    return user;
  }
  router.post(
    '/users/:id/reset',
    route(async (req, res) => {
      const user = await target(req.params.id);
      await db.query('DELETE FROM sessions WHERE user_id=$1', [user.id]);
      const delivery = await mail.issue(user, 'reset');
      await audit(db, req.user, 'account.reset', user.id);
      res.json({
        message: 'Wysłano instrukcję resetu hasła. Sesje konta zostały unieważnione.',
        ...delivery,
      });
    }),
  );
  router.delete(
    '/users/:id',
    route(async (req, res) => {
      const user = await target(req.params.id);
      await db.transaction(async (tx) => {
        await tx.query('DELETE FROM users WHERE id=$1', [user.id]);
        await tx.query(
          'DELETE FROM organizations WHERE tenant_id=$1 AND NOT EXISTS(SELECT 1 FROM memberships WHERE tenant_id=$1)',
          [user.tenant_id],
        );
        await tx.query(
          'DELETE FROM conversations WHERE NOT EXISTS(SELECT 1 FROM conversation_members m WHERE m.conversation_id=conversations.id)',
        );
        await audit(tx, req.user, 'account.delete', user.id);
      });
      res.json({ ok: true });
    }),
  );
  router.patch(
    '/users/:id/role',
    route(async (req, res) => {
      const user = await target(req.params.id);
      ensure(user.account_type === 'private', 400, 'Moderatorem może zostać osoba prywatna.');
      const role = z.enum(['user', 'moderator']).parse(req.body.role);
      await db.query('UPDATE users SET role=$2 WHERE id=$1', [user.id, role]);
      await audit(db, req.user, 'account.role', user.id, { role });
      res.json({ ok: true });
    }),
  );
  router.patch(
    '/users/:id/verification',
    route(async (req, res) => {
      const user = await target(req.params.id);
      ensure(user.account_type === 'company', 400, 'To nie jest organizacja.');
      const verified = z.boolean().parse(req.body.verified);
      await db.query(
        'UPDATE organizations SET verified=$2 WHERE id IN(SELECT organization_id FROM memberships WHERE user_id=$1)',
        [user.id, verified],
      );
      await audit(db, req.user, 'organization.verify', user.id, { verified });
      res.json({ ok: true });
    }),
  );
  router.post(
    '/users/:id/sanctions',
    route(async (req, res) => {
      const user = await target(req.params.id),
        input = sanctionInput.parse(req.body),
        duration = durationSeconds(input, input.kind);
      ensure(input.kind === 'mute', 400, 'Blokady dotyczą teraz wyłącznie komentarzy.');
      const expires = duration === null ? null : new Date(Date.now() + duration * 1000);
      await db.transaction(async (tx) => {
        await tx.query(
          'UPDATE sanctions SET revoked_at=now() WHERE user_id=$1 AND kind=$2 AND revoked_at IS NULL',
          [user.id, input.kind],
        );
        await tx.query(
          'INSERT INTO sanctions(id,user_id,kind,reason,expires_at,created_by) VALUES($1,$2,$3,$4,$5,$6)',
          [randomUUID(), user.id, input.kind, input.reason, expires, req.user.id],
        );
        await audit(tx, req.user, 'sanction.create', user.id, { ...input, expires });
      });
      res.json({ ok: true });
    }),
  );
  router.delete(
    '/users/:id/sanctions/:kind',
    route(async (req, res) => {
      await target(req.params.id);
      const kind = z.enum(['post', 'mute']).parse(req.params.kind);
      await db.query(
        'UPDATE sanctions SET revoked_at=now() WHERE user_id=$1 AND kind=$2 AND revoked_at IS NULL',
        [req.params.id, kind],
      );
      await audit(db, req.user, 'sanction.revoke', req.params.id, { kind });
      res.json({ ok: true });
    }),
  );
  router.get(
    '/reports',
    route(async (req, res) => {
      const kind = z.enum(['idea', 'comment']).parse(req.query.kind || 'idea'),
        page = z.coerce
          .number()
          .int()
          .min(1)
          .max(10000)
          .parse(req.query.page || 1);
      res.json({
        items: (
          await db.query(
            'SELECT r.*,u.name AS author,i.title FROM reports r LEFT JOIN users u ON u.id=r.target_user_id LEFT JOIN innovations i ON i.id=r.innovation_id WHERE r.kind=$1 ORDER BY r.created_at DESC LIMIT 25 OFFSET $2',
            [kind, (page - 1) * 25],
          )
        ).rows,
        total: (await db.query('SELECT count(*)::int AS total FROM reports WHERE kind=$1', [kind]))
          .rows[0].total,
        page,
      });
    }),
  );
  router.get(
    '/reports/:id/context',
    route(async (req, res) => {
      const report = (
        await db.query('SELECT * FROM reports WHERE id=$1', [
          z.string().uuid().parse(req.params.id),
        ])
      ).rows[0];
      ensure(report, 404, 'Brak zgłoszenia.');
      ensure(report.kind === 'comment', 400, 'To zgłoszenie karty.');
      const comment = (
        await db.query(
          'SELECT c.*,u.name AS author FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.id=$1',
          [report.comment_id],
        )
      ).rows[0];
      ensure(comment, 404, 'Komentarz nie istnieje.');
      const context = (
        await db.query(
          'SELECT c.*,u.name AS author FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.id=$1 OR c.id=$2 OR c.parent_id=$1 ORDER BY c.created_at LIMIT 100',
          [comment.parent_id || comment.id, comment.id],
        )
      ).rows;
      await audit(db, req.user, 'report.comment.read', report.id);
      res.json({ comments: context, reportedCommentId: comment.id });
    }),
  );
  router.patch(
    '/reports/:id',
    route(async (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      const result = await db.query(
        "UPDATE reports SET status='resolved',resolved_at=now() WHERE id=$1 RETURNING id",
        [id],
      );
      ensure(result.rows.length, 404, 'Brak zgłoszenia.');
      await audit(db, req.user, 'report.resolve', id);
      res.json({ ok: true });
    }),
  );
  return router;
}
