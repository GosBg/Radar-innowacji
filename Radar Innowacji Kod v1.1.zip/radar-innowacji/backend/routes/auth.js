import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import argon2 from 'argon2';
import { TOTP, Secret } from 'otpauth';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import { registration, password, profileFields } from '../lib/validation.js';
import { digest, token } from '../lib/crypto.js';
import { requireUser, audit } from '../lib/policy.js';
import { getProfile, publicProfile } from '../services/projections.js';

export function authRoutes({ db, config, sessions, mail, crypto, authLimiter }) {
  const router = Router();
  const dummyHash = argon2.hash(randomUUID(), { type: argon2.argon2id });
  router.get(
    '/session',
    route(async (req, res) => {
      const csrf = await sessions.current(req, res);
      res.json({
        csrf,
        user: req.user ? await getProfile(db, req.user.id, true) : null,
        examples: config.examples,
        serverTime: Date.now(),
      });
    }),
  );
  router.get(
    '/examples',
    route(async (req, res) => {
      ensure(config.examples, 404, 'Niedostępne.');
      res.json(
        (await db.query('SELECT * FROM users WHERE example=true ORDER BY role DESC,name')).rows.map(
          publicProfile,
        ),
      );
    }),
  );
  router.post(
    '/example',
    authLimiter,
    route(async (req, res) => {
      ensure(config.examples, 404, 'Niedostępne.');
      const id = z.string().uuid().parse(req.body.id);
      const user = (
        await db.query("SELECT * FROM users WHERE id=$1 AND example=true AND role<>'admin'", [id])
      ).rows[0];
      ensure(user, 403, 'Administrator wymaga loginu i hasła.');
      const csrf = await sessions.create(res, user.id, req.session?.token_hash);
      res.json({ csrf, user: await getProfile(db, user.id, true) });
    }),
  );
  router.post(
    '/register',
    authLimiter,
    route(async (req, res) => {
      const input = registration.parse(req.body),
        id = randomUUID(),
        tenant = randomUUID();
      const hash = await argon2.hash(input.password, {
        type: argon2.argon2id,
        memoryCost: 65536,
        timeCost: 3,
      });
      await db.transaction(async (tx) => {
        await tx.query(
          'INSERT INTO users(id,tenant_id,login,email,password_hash,name,account_type,city,region,affiliation,contact_consent) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',
          [
            id,
            tenant,
            input.login,
            input.email,
            hash,
            input.name,
            input.type,
            input.city,
            input.region,
            input.affiliation,
            input.contactConsent,
          ],
        );
        if (input.type === 'company') {
          const org = randomUUID();
          await tx.query('INSERT INTO organizations(id,tenant_id,name) VALUES($1,$2,$3)', [
            org,
            tenant,
            input.name,
          ]);
          await tx.query(
            'INSERT INTO memberships(user_id,organization_id,tenant_id) VALUES($1,$2,$3)',
            [id, org, tenant],
          );
        }
      });
      const delivery = await mail.issue({ id, email: input.email }, 'verify');
      const avatarTicket = token();
      await db.query(
        "INSERT INTO registration_uploads(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval '30 minutes')",
        [digest(avatarTicket), id],
      );
      res.status(201).json({
        message: 'Konto utworzone. Potwierdź adres e-mail przed logowaniem.',
        avatarTicket,
        ...delivery,
      });
    }),
  );
  router.post(
    '/login',
    authLimiter,
    route(async (req, res) => {
      const input = z
        .object({
          login: z.string().trim().toLowerCase().max(254),
          password: z.string().max(128),
          otp: z.string().max(10).optional(),
        })
        .parse(req.body);
      const user = (await db.query('SELECT * FROM users WHERE login=$1 OR email=$1', [input.login]))
        .rows[0];
      const valid = await argon2.verify(user?.password_hash || (await dummyHash), input.password);
      ensure(user && valid, 401, 'Nieprawidłowy login lub hasło.');
      ensure(user.email_verified, 403, 'Najpierw potwierdź adres e-mail.');
      if (user.role === 'admin' && (config.production || user.mfa_secret)) {
        ensure(user.mfa_secret, 403, 'Administrator wymaga skonfigurowanego MFA.');
        const secret = crypto.open(Buffer.from(user.mfa_secret, 'base64')).toString();
        const totp = new TOTP({
          secret: Secret.fromBase32(secret),
          digits: 6,
          period: 30,
          algorithm: 'SHA1',
        });
        const timestamp = Date.now(),
          delta = totp.validate({ token: input.otp || '', window: 1, timestamp });
        const step = Math.floor(timestamp / 30000) + (delta ?? 0);
        ensure(
          delta !== null && (!user.mfa_last_step || step > Number(user.mfa_last_step)),
          401,
          'Podaj aktualny, nieużyty kod MFA.',
        );
        const updated = await db.query(
          'UPDATE users SET mfa_last_step=$2 WHERE id=$1 AND (mfa_last_step IS NULL OR mfa_last_step<$2) RETURNING id',
          [user.id, step],
        );
        ensure(updated.rows.length, 401, 'Ten kod MFA został już użyty.');
      }
      const csrf = await sessions.create(res, user.id, req.session?.token_hash);
      await audit(db, user, 'login', user.id);
      res.json({ csrf, user: await getProfile(db, user.id, true) });
    }),
  );
  router.post(
    '/logout',
    route(async (req, res) => {
      const csrf = await sessions.create(res, null, req.session?.token_hash);
      res.json({ csrf, user: null });
    }),
  );
  router.post(
    '/forgot',
    authLimiter,
    route(async (req, res) => {
      const email = z.string().email().toLowerCase().parse(req.body.email);
      const user = (await db.query('SELECT id,email FROM users WHERE email=$1', [email])).rows[0];
      const delivery = user ? await mail.issue(user, 'reset') : {};
      res.json({ message: 'Jeśli konto istnieje, wysłano instrukcję resetu.', ...delivery });
    }),
  );
  router.post(
    '/resend-verification',
    authLimiter,
    route(async (req, res) => {
      const email = z.string().email().toLowerCase().parse(req.body.email);
      const user = (
        await db.query('SELECT id,email FROM users WHERE email=$1 AND email_verified=false', [
          email,
        ])
      ).rows[0];
      res.json({
        message: 'Jeśli konto wymaga weryfikacji, wysłano link.',
        ...(user ? await mail.issue(user, 'verify') : {}),
      });
    }),
  );
  router.post(
    '/token',
    authLimiter,
    route(async (req, res) => {
      const input = z
        .object({
          token: z.string().min(20).max(100),
          kind: z.enum(['verify', 'reset']),
          password: password.optional(),
        })
        .parse(req.body);
      if (input.kind === 'reset') password.parse(input.password);
      const hash =
        input.kind === 'reset'
          ? await argon2.hash(input.password, { type: argon2.argon2id })
          : null;
      await db.transaction(async (tx) => {
        const result = await tx.query(
          'DELETE FROM auth_tokens WHERE token_hash=$1 AND kind=$2 AND expires_at>now() RETURNING user_id',
          [digest(input.token), input.kind],
        );
        ensure(result.rows.length, 400, 'Link jest nieaktualny lub został już użyty.');
        const id = result.rows[0].user_id;
        if (input.kind === 'verify')
          await tx.query('UPDATE users SET email_verified=true WHERE id=$1', [id]);
        else {
          await tx.query('UPDATE users SET password_hash=$2 WHERE id=$1', [id, hash]);
          await tx.query('DELETE FROM sessions WHERE user_id=$1', [id]);
          await tx.query("DELETE FROM auth_tokens WHERE user_id=$1 AND kind='reset'", [id]);
        }
        await audit(tx, null, `auth.${input.kind}`, id);
      });
      res.json({
        message:
          input.kind === 'verify'
            ? 'E-mail potwierdzony. Możesz się zalogować.'
            : 'Hasło zmienione. Zaloguj się ponownie.',
      });
    }),
  );
  router.patch(
    '/profile',
    route(async (req, res) => {
      const user = requireUser(req);
      const input = z
        .object({ ...profileFields, avatarId: z.string().uuid().nullable().optional() })
        .strict()
        .parse(req.body);
      if (input.avatarId)
        ensure(
          (
            await db.query(
              "SELECT 1 FROM attachments WHERE id=$1 AND owner_id=$2 AND purpose='avatar'",
              [input.avatarId, user.id],
            )
          ).rows.length,
          403,
          'To nie jest Twoje zdjęcie.',
        );
      await db.query(
        'UPDATE users SET name=$2,city=$3,region=$4,affiliation=$5,contact_consent=$6,avatar_id=$7 WHERE id=$1',
        [
          user.id,
          input.name,
          input.city,
          input.region,
          input.affiliation,
          input.contactConsent,
          input.avatarId === undefined ? user.avatar_id : input.avatarId,
        ],
      );
      res.json(await getProfile(db, user.id, true));
    }),
  );
  return router;
}
