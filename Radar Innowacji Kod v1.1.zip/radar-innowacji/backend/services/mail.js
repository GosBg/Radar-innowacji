import nodemailer from 'nodemailer';
import { token, digest } from '../lib/crypto.js';

export function mailService(db, config) {
  const transport = config.smtpUrl ? nodemailer.createTransport(config.smtpUrl) : null;
  return {
    async issue(user, kind) {
      const value = token();
      await db.query('DELETE FROM auth_tokens WHERE user_id=$1 AND kind=$2', [user.id, kind]);
      await db.query(
        'INSERT INTO auth_tokens(token_hash,user_id,kind,expires_at) VALUES($1,$2,$3,$4)',
        [
          digest(value),
          user.id,
          kind,
          new Date(Date.now() + (kind === 'reset' ? 3600000 : 86400000)),
        ],
      );
      const url = `${config.origin}/?auth=${kind}&token=${encodeURIComponent(value)}`;
      if (transport)
        await transport.sendMail({
          from: config.mailFrom,
          to: user.email,
          subject:
            kind === 'verify'
              ? 'Potwierdź adres e-mail — Radar innowacji'
              : 'Reset hasła — Radar innowacji',
          text: `Otwórz link: ${url}\nJeśli to nie Ty, zignoruj tę wiadomość.`,
        });
      return !config.production && !transport ? { developmentLink: url } : {};
    },
  };
}
