import { readdir, unlink, stat } from 'node:fs/promises';
import path from 'node:path';

export async function applyRetention(db, config) {
  await db.query('DELETE FROM sessions WHERE expires_at<now()');
  await db.query('DELETE FROM auth_tokens WHERE expires_at<now()');
  await db.query('DELETE FROM registration_uploads WHERE expires_at<now()');
  await db.query(
    "DELETE FROM attachments a WHERE a.innovation_id IS NULL AND a.created_at<now()-interval '1 day' AND NOT EXISTS(SELECT 1 FROM users u WHERE u.avatar_id=a.id)",
  );
  await db.query(
    "DELETE FROM reports WHERE status='resolved' AND resolved_at<now()-($1::int * interval '1 day')",
    [config.retentionDays],
  );
  await db.query("DELETE FROM moderation_log WHERE created_at<now()-($1::int * interval '1 day')", [
    config.retentionDays,
  ]);
  const folder = path.join(config.dataDir, 'uploads');
  for (const id of await readdir(folder).catch(() => [])) {
    if (!/^[a-f0-9-]{36}$/.test(id)) continue;
    if ((await db.query('SELECT 1 FROM attachments WHERE id=$1', [id])).rows.length) continue;
    const location = path.join(folder, id);
    if (Date.now() - (await stat(location)).mtimeMs > 3600000) await unlink(location);
  }
}
