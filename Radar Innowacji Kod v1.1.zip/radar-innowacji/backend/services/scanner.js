import net from 'node:net';
import yauzl from 'yauzl';
import { ensure } from '../lib/errors.js';

// Office documents are ZIP containers. Inspect without extracting paths to disk.
export function inspectOffice(buffer, extension) {
  return new Promise((resolve, reject) =>
    yauzl.fromBuffer(buffer, { lazyEntries: true, validateEntrySizes: true }, (error, zip) => {
      if (error) return reject(error);
      let count = 0,
        total = 0,
        found = false,
        done = false;
      const fail = (error) => {
        if (done) return;
        done = true;
        zip.close();
        reject(error);
      };
      zip.on('error', fail);
      zip.on('end', () => {
        if (done) return;
        try {
          ensure(found, 400, 'Niepoprawny dokument Office.');
          done = true;
          resolve();
        } catch (e) {
          fail(e);
        }
      });
      zip.on('entry', (entry) => {
        try {
          count++;
          total += entry.uncompressedSize;
          ensure(
            count <= 1500 &&
              total <= 100 * 1024 * 1024 &&
              entry.uncompressedSize / Math.max(1, entry.compressedSize) < 200,
            400,
            'Dokument ma zbyt złożoną strukturę.',
          );
          ensure(
            !(entry.generalPurposeBitFlag & 1) &&
              !entry.fileName.includes('..') &&
              !/vbaProject|embeddings\//i.test(entry.fileName),
            400,
            'Dokument zawiera niedozwolone elementy.',
          );
          if (
            entry.fileName === (extension === 'docx' ? 'word/document.xml' : 'ppt/presentation.xml')
          )
            found = true;
          if (entry.fileName.endsWith('.rels')) {
            ensure(entry.uncompressedSize < 1024 * 1024, 400, 'Niepoprawne relacje dokumentu.');
            zip.openReadStream(entry, (err, stream) => {
              if (err) return fail(err);
              const parts = [];
              stream.on('data', (p) => parts.push(p));
              stream.on('error', fail);
              stream.on('end', () => {
                try {
                  ensure(
                    !/TargetMode\s*=\s*["']External/i.test(Buffer.concat(parts).toString()),
                    400,
                    'Usuń z dokumentu zewnętrzne odwołania.',
                  );
                  zip.readEntry();
                } catch (e) {
                  fail(e);
                }
              });
            });
          } else zip.readEntry();
        } catch (e) {
          fail(e);
        }
      });
      zip.readEntry();
    }),
  );
}
export async function scan(buffer, config) {
  if (!config.clamHost) {
    ensure(!config.production, 503, 'Skaner plików jest niedostępny.');
    return 'structural-only';
  }
  await new Promise((resolve, reject) => {
    const socket = net.createConnection({ host: config.clamHost, port: config.clamPort });
    let result = '';
    socket.setTimeout(30000, () => socket.destroy(new Error('Przekroczono czas skanowania.')));
    socket.on('error', reject);
    socket.on('data', (chunk) => {
      result += chunk.toString();
      if (result.length > 4096) socket.destroy(new Error('Nieprawidłowa odpowiedź skanera.'));
    });
    socket.on('end', () => {
      try {
        ensure(
          /: OK\x00?$/.test(result),
          422,
          'Skaner odrzucił plik lub nie potwierdził jego bezpieczeństwa.',
        );
        resolve();
      } catch (e) {
        reject(e);
      }
    });
    socket.on('connect', () => {
      socket.write('zINSTREAM\0');
      for (let i = 0; i < buffer.length; i += 65536) {
        const chunk = buffer.subarray(i, i + 65536),
          length = Buffer.alloc(4);
        length.writeUInt32BE(chunk.length);
        socket.write(length);
        socket.write(chunk);
      }
      socket.write(Buffer.alloc(4));
    });
  });
  return 'clamav-clean';
}
