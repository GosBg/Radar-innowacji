export function publicProfile(user) {
  return {
    id: user.id,
    name: user.name,
    type: user.account_type,
    role: user.role,
    city: user.city,
    region: user.region,
    affiliation: user.affiliation,
    avatar: user.avatar_id ? `/api/v1/files/${user.avatar_id}?inline=1` : '',
    verified: !!user.verified,
    example: user.example,
  };
}
export function ownProfile(user) {
  return {
    ...publicProfile(user),
    email: user.email,
    login: user.login,
    emailVerified: user.email_verified,
    contactConsent: user.contact_consent,
  };
}
export async function getProfile(db, id, own = false) {
  const { rows } = await db.query(
    'SELECT u.*,EXISTS(SELECT 1 FROM memberships m JOIN organizations o ON o.id=m.organization_id WHERE m.user_id=u.id AND o.verified) AS verified FROM users u WHERE u.id=$1',
    [id],
  );
  return rows[0] ? (own ? ownProfile : publicProfile)(rows[0]) : null;
}
export async function projectIdeas(db, rows, userId) {
  if (!rows.length) return [];
  const ids = rows.map((row) => row.id);
  const totals = await db.query(
    'SELECT innovation_id,category,avg(value)::float AS average,count(*)::int AS count FROM ratings WHERE innovation_id=ANY($1::uuid[]) GROUP BY innovation_id,category',
    [ids],
  );
  const overall = await db.query(
    'SELECT innovation_id,avg(value)::float AS average,count(DISTINCT user_id)::int AS voters FROM ratings WHERE innovation_id=ANY($1::uuid[]) GROUP BY innovation_id',
    [ids],
  );
  const own = userId
    ? (
        await db.query(
          'SELECT innovation_id,category,value::float FROM ratings WHERE innovation_id=ANY($1::uuid[]) AND user_id=$2',
          [ids, userId],
        )
      ).rows
    : [];
  const sources = (
    await db.query(
      'SELECT e.innovation_id,e.url,e.title,e.excerpt,e.source_date,e.fetched_at,COALESCE(s.name,e.publisher_name) AS name FROM evidence e LEFT JOIN research_sources s ON s.id=e.source_id WHERE innovation_id=ANY($1::uuid[])',
      [ids],
    )
  ).rows;
  const history = (
    await db.query(
      "SELECT innovation_id,changed_at,snapshot->>'stage' AS stage FROM innovation_history WHERE innovation_id=ANY($1::uuid[]) ORDER BY changed_at DESC LIMIT 100",
      [ids],
    )
  ).rows;
  return rows.map((row) => {
    const categories = [null, null, null, null],
      ballot = [null, null, null, null];
    totals.rows
      .filter((r) => r.innovation_id === row.id)
      .forEach((r) => (categories[r.category] = r.average));
    own.filter((r) => r.innovation_id === row.id).forEach((r) => (ballot[r.category] = r.value));
    const aggregate = overall.rows.find((r) => r.innovation_id === row.id);
    return {
      id: row.id,
      owner: row.owner_id,
      title: row.title,
      description: row.description,
      category: row.category,
      stage: row.stage,
      art:
        { Technologiczny: 'tech', Edukacyjny: 'education', Administracyjny: 'social' }[
          row.category
        ] || row.art,
      status: row.status,
      author: row.creator,
      creatorType: row.creator_type,
      problem: row.problem,
      application: row.application,
      recipient: row.recipient,
      assessment: row.assessment,
      checkedAt: row.checked_at,
      changedAt: row.changed_at,
      sources: sources.filter((e) => e.innovation_id === row.id),
      history: history.filter((e) => e.innovation_id === row.id),
      authorAvatar: row.avatar_id ? `/api/v1/files/${row.avatar_id}?inline=1` : '',
      type: row.account_type,
      city: row.city,
      region: row.region,
      created: +new Date(row.created_at),
      publishedAt: row.published_at ? +new Date(row.published_at) : null,
      similar: row.similar_id,
      rejectionReason: row.rejection_reason,
      ratings: [0, 0, 0, 0],
      votes: 0,
      summary: { categories, overall: aggregate?.average ?? null, voters: aggregate?.voters ?? 0 },
      ballot,
      attachments: [],
    };
  });
}
export const ideaSelect = 'SELECT i.* FROM innovations i';
