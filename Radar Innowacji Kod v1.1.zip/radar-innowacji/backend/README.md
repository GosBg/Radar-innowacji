# Backend Radaru

Szczegółowe uruchamianie, ograniczenia konektorów, konfiguracja produkcyjna i kopie: [README](../README.md).

API ma prefiks `/api/v1`. Klient pobiera `/auth/session`; sesja pozostaje w HttpOnly cookie, a token CSRF jest wymagany dla operacji zapisu wraz z poprawnym Origin.

| Obszar             | Endpointy                                                                                       |
| ------------------ | ----------------------------------------------------------------------------------------------- |
| Konta              | `/auth/register`, `/auth/login`, `/auth/logout`, `/auth/profile`, `/auth/forgot`, `/auth/token` |
| Katalog            | GET `/ideas?filters=JSON&page=1`, GET `/ideas/:id`                                              |
| Przegląd moderacji | GET `/ideas?scope=moderation`, PATCH `/ideas/:id/moderation`, DELETE `/ideas/:id`               |
| Oceny i ulubione   | PUT `/ideas/:id/rating`, PUT `/ideas/:id/favorite`                                              |
| Komentarze         | GET/POST `/ideas/:id/comments`, DELETE `/comments/:id`                                          |
| Zgłoszenia         | POST `/reports`, GET `/reports?kind=idea` lub `comment`, GET `/state`                           |
| Konta admina       | `/admin/users`, `/admin/users/:id/reset`, `/role`, `/verification`, `/sanctions`                |
| Zgłoszenia admina  | `/admin/reports?kind=comment`, `/admin/reports/:id/context`                                     |
| Źródła admina      | GET/POST `/admin/sources`, PATCH `/admin/sources/:id`, POST `/:id/test`, POST `/:id/run`        |
| Profilowe          | POST `/files/upload/avatar`, GET `/files/:id`                                                   |

Paginacja katalogu: 12 kart, komentarzy: 50, kont i zgłoszeń: 25. Katalog filtruje po zapytaniu, kategorii, rodzaju twórcy, województwie (jeśli znane), etapie, nazwie źródła, wieku odkrycia, ocenach i okresie rankingu. `/ideas` nie obsługuje POST. Prywatne wiadomości i kontakt e-mail autora nie mają endpointów.

`research/` zawiera niezależne moduły pobierania, ekstrakcji, klasyfikacji i trwałego harmonogramu. `worker.js` jest osobnym procesem. Blokada transakcyjna PostgreSQL serializuje workerów; kursor i terminy są zapisane w bazie. Interfejs źródła jest rozszerzany przez dodanie konektora oraz wpisu w rejestrze. Nie należy wykonywać instrukcji znalezionych w treści pobranego dokumentu.

`schema.sql` zachowuje zgodność ze starszym schematem, `research.sql` dodaje dane badawcze. Ich idempotentne wykonanie jest chronione blokadą migracji. `innovations.owner_id` dla researchu jest puste; twórca nie jest kontem na stronie. Usunięcie konta nie kaskaduje do innowacji. Usunięcie karty zapisuje URL w `ignored_source_urls` przed usunięciem rekordów.

Uprawnienia są sprawdzane po stronie serwera. Katalog i komentarze są publiczne; role administratora/moderatora wynikają z sesji, nigdy z JSON klienta. Admin jest wymagany dla źródeł, kont, archiwizacji, usunięcia kart i wyciszeń. Użytkownik może usuwać własny komentarz; moderator i admin mogą ukrywać komentarze innych osób. Operacje moderacji trafiają do audytu.
