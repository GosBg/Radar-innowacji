// Evidence of completed activity, rather than funding, novelty or patent status.
export const trlRules = [
  [
    9,
    /(?:system|technologi|urządzeni|produkt|rozwiązani|oprogramowan).*(?:jest|są|został[ao]?|zostały|zostało)\s+(?:z powodzeniem\s+)?(?:stosowan|wdrożon|wykorzystywan|eksploatowan).*(?:warunkach operacyjnych|eksploatacj|produkcji seryjnej|codziennej pracy)/i,
  ],
  [
    8,
    /(?:system|technologi|urządzeni|produkt).*(?:ukończon|kompletn|gotow).*(?:pomyślnie.*test|kwalifikacj|certyfikacj)|(?:zakończono|przeprowadzono).*kwalifikacj.*(?:system|technologi)/i,
  ],
  [
    7,
    /prototyp.*(?:przetestowano|zademonstrowano|został przetestowany|został zademonstrowany).*(?:warunkach operacyjnych|rzeczywistym środowisku pracy)/i,
  ],
  [
    6,
    /(?:prototyp|demonstrator).*(?:przetestowano|zademonstrowano|zweryfikowano|został przetestowany).*(?:warunkach zbliżonych do rzeczywistych|warunkach reprezentatywnych|środowisku zbliżonym do rzeczywistego)/i,
  ],
  [
    5,
    /(?:komponent|podzespół|technologi).*(?:zweryfikowano|przetestowano|został zweryfikowany).*(?:warunkach zbliżonych do rzeczywistych|warunkach reprezentatywnych)/i,
  ],
  [
    4,
    /(?:przetestowano|zweryfikowano|potwierdzono|przetestowan[ayoe]|zweryfikowan[ayoe]).*(?:warunkach laboratoryjnych|w laboratorium)/i,
  ],
  [
    3,
    /(?:potwierdzono|wykazano|zweryfikowano).*(?:koncepcj.*eksperymentaln|eksperymentaln.*koncepcj)|(?:przeprowadzono|wykonano).*proof.of.concept/i,
  ],
  [
    2,
    /(?:sformułowano|opracowano|zdefiniowano).*koncepcj.*(?:technolog|rozwiązani|system|urządzeni)/i,
  ],
  [
    1,
    /(?:zaobserwowano|opisano|zidentyfikowano).*(?:podstawowe zasady|podstawowe zjawiska|zasady fizyczne)/i,
  ],
];
