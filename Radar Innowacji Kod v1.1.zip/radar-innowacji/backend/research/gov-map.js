import { load } from 'cheerio';
import { createHash } from 'node:crypto';
// Semicolon-separated data embedded by gov.pl; quoted cells can contain line breaks.
export function parseDelimited(text) {
  const rows = [];
  let row = [],
    cell = '',
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else quoted = !quoted;
    } else if (!quoted && (c === ';' || c === '\n')) {
      row.push(cell.replace(/\r$/, ''));
      cell = '';
      if (c === '\n') {
        rows.push(row);
        row = [];
      }
    } else cell += c;
  }
  if (quoted) throw new Error('Nieprawidłowy format danych mapy.');
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ''));
    rows.push(row);
  }
  return rows;
}
export function mapRecords(html, sourceUrl) {
  const $ = load(html);
  const data = JSON.parse($('#registerData').text());
  const [header, ...rows] = parseDelimited(data.data);
  const titleIndex = header.indexOf('Nazwa projektu'),
    descriptionIndex = header.indexOf('Opis projektu');
  if (titleIndex < 0 || descriptionIndex < 0)
    throw new Error('Zmieniły się kolumny Mapy innowacji.');
  return rows
    .filter((r) => r[titleIndex]?.trim() && r[descriptionIndex]?.trim())
    .map((r) => {
      const title = r[titleIndex].trim(),
        text = r[descriptionIndex].trim();
      const location = r[header.indexOf('Miejscowość')] || '';
      const key = createHash('sha256')
        .update(title + '|' + location)
        .digest('hex')
        .slice(0, 24);
      return {
        url: sourceUrl.split('#')[0] + '#radar-' + key,
        title,
        text,
        intro: text.slice(0, 900),
        creator: 'Nie ustalono',
        problem: '',
        application: '',
        date: null,
      };
    });
}
