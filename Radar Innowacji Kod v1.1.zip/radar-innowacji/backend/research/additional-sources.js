// Curated institutions: broad lists require editorial review before publication.
const html = (
  name,
  url,
  linkSelector = 'main a[href], article a[href]',
  contentSelector = 'main',
  keywords = [],
) => ({
  name,
  url,
  connector: 'html',
  enabled: false,
  config: { linkSelector, contentSelector, keywords, reviewRequired: true },
});
const localKeywords = [
  'innowac',
  'technolog',
  'cyfrow',
  'cyfryzac',
  'system',
  'dron',
  'inteligent',
  'wdroż',
  'wdroz',
  'badawcz',
];
export const additionalSources = [
  html(
    'Urząd Miasta Ciechanów',
    'https://www.umciechanow.pl/',
    'a[href]',
    'main, #content',
    localKeywords,
  ),
  html(
    'Urząd Gminy Ciechanów',
    'https://gminaciechanow.pl/',
    'a[href*="/art/"]',
    'main, article, #content',
    localKeywords,
  ),
  html(
    'Starostwo Powiatowe w Ciechanowie — BIP',
    'https://bip.powiat-ciechanow.pl/',
    'a[href]',
    'main, article, #content',
    localKeywords,
  ),
  html(
    'Urząd Miejski w Płońsku',
    'https://plonsk.pl/aktualnosci/',
    'a[href*="/aktualnosci/"]',
    'main, article',
    localKeywords,
  ),
  html(
    'Samorząd Województwa Mazowieckiego — Mazovia',
    'https://bip.mazovia.pl/pl/dla_mediow/informacje_prasowe/',
    'a[href*="informacje_prasowe/"]',
    'main, article',
    localKeywords,
  ),
  {
    name: 'Ministerstwo Cyfryzacji — Mapa innowacji',
    url: 'https://www.gov.pl/web/cyfryzacja/mapa-innowacji',
    connector: 'pending',
    enabled: false,
    config: {
      note: 'Mapa zawiera zbiór danych; wymaga parsera rekordów zamiast traktowania całej mapy jako jednej innowacji.',
    },
  },
  html(
    'NASK Science — projekty badawczo-rozwojowe',
    'https://science.nask.pl/research-areas/projects/page/1',
    'a[href*="/projects/"]',
    'main, article',
  ),
  html(
    'Łukasiewicz — Instytut Tele- i Radiotechniczny',
    'https://itr.lukasiewicz.gov.pl/oferta/',
    'a[href*="/oferta/"]',
    'main, article',
  ),
  html(
    'Łukasiewicz — Instytut Lotnictwa',
    'https://ilot.lukasiewicz.gov.pl/oferta/technologie/',
    'a[href*="/technologie/"]',
    'main, article',
  ),
  html(
    'Politechnika Wrocławska — Elektronika, Fotonika i Mikrosystemy',
    'https://wefim.pwr.edu.pl/badania-i-wspolpraca/projekty-badawcze',
    'a[href*="/badania-i-wspolpraca/"]',
    'main, article',
  ),
  html(
    'Politechnika Warszawska — poligon Sierakowo / Przasnysz',
    'https://www.meil.pw.edu.pl/dm/MEiL/Wydzial/Lotnisko-Przasnysz',
    'a[href*="Przasnysz"], a[href*="Sierakow"]',
    'main, article, #content',
  ),
  html(
    'Powiat Przasnyski',
    'https://samorzad.gov.pl/web/powiat-przasnyski',
    'a[href*="/web/powiat-przasnyski/"]',
    'main',
    localKeywords,
  ),
  {
    name: 'Miasto Przasnysz — dokumenty rady miejskiej',
    url: 'https://rada.przasnysz.um.gov.pl/',
    connector: 'pending',
    enabled: false,
    config: {
      note: 'Dokumenty uchwał PDF wymagają konektora dokumentowego i rozróżnienia projektu uchwały od przyjętego dokumentu.',
    },
  },
  html(
    'Urząd Gminy Przasnysz',
    'https://www.przasnysz.pl/nowy/',
    'a[href]',
    'main, article, #content',
    localKeywords,
  ),
  html(
    'Miasto Mława — BIP',
    'https://bip.mlawa.pl/',
    'a[href*="/projekt/"], a[href*="/artykul/"]',
    'main, article',
    localKeywords,
  ),
  html(
    'Powiat Mławski',
    'https://www.powiatmlawski.pl/',
    'a[href]',
    'main, article, #content',
    localKeywords,
  ),
  html(
    'Miasto i Gmina Chorzele',
    'https://chorzele.pl/aktualnosci/',
    'a[href*="/aktualnosci/"]',
    'main, article',
    localKeywords,
  ),
  html(
    'NCBR — baza projektów',
    'https://www.gov.pl/web/ncbr/baza-projektow',
    'main a[href*="/web/ncbr/"]',
    'main',
  ),
  html(
    'OPI PIB — systemy informatyczne',
    'https://opi.org.pl/systemy/',
    'main a[href]',
    'main, article',
  ),
];

// Known project pages are monitored individually; list sources discover new articles.
const projectPages = {
  'Urząd Gminy Ciechanów': [
    'https://gminaciechanow.pl/art/2854/projekt-rozwiazania-cyfrowe-dla-mazowieckiej-administracji',
    '.article-wrp, article, main',
  ],
  'Urząd Miejski w Płońsku': [
    'https://plonsk.pl/aktualnosci/zaczynamy-realizacje-zadania-dostosowanie-zielono-niebieskiej-infrastruktury-w-plonsku-do-zmian-klimatu.html',
    'main, article',
  ],
  'Miasto Mława — BIP': [
    'https://bip.mlawa.pl/projekt/cyberbezpieczny-samorzad-projekt-grantowy',
    'main, article',
  ],
  'Powiat Mławski': [
    'https://www.powiatmlawski.pl/4223%2Crozwiazania-cyfrowe-dla-mazowieckiej-administracji',
    '.content, main, article',
  ],
  'Powiat Przasnyski': [
    'https://samorzad.gov.pl/web/powiat-przasnyski/uroczyste-otwarcie-osrodka-badan-lotniczych-i-kosmicznych-w-przasnyszu',
    'article',
  ],
  'Politechnika Warszawska — poligon Sierakowo / Przasnysz': [
    'https://www.meil.pw.edu.pl/dm/MEiL/Wydzial/Lotnisko-Przasnysz',
    '.content-view-full',
  ],
};
for (const source of additionalSources) {
  const page = projectPages[source.name];
  if (page) {
    source.url = page[0];
    Object.assign(source.config, {
      singlePage: true,
      contentSelector: page[1],
      note: 'Monitorowanie wskazanej strony projektu co 24 h; nie jest pełnym przeszukiwaniem serwisu.',
    });
  }
}
// These pages contain several records or external links, not an article list.
for (const source of additionalSources.filter((s) =>
  [
    'NCBR — baza projektów',
    'OPI PIB — systemy informatyczne',
    'Politechnika Wrocławska — Elektronika, Fotonika i Mikrosystemy',
  ].includes(s.name),
)) {
  source.connector = 'pending';
  source.config.note =
    'Wymaga wydzielania rekordów z treści zbiorczej lub integracji z zewnętrznymi stronami projektów.';
}

for (const source of additionalSources) {
  if (source.name === 'Urząd Miejski w Płońsku')
    source.config.contentSelector = 'article.news_entry__element';
  if (source.name === 'Powiat Mławski') source.config.contentSelector = '#PageContent';
  if (source.name === 'Miasto Mława — BIP') source.config.contentSelector = '.region-content';
  if (source.name === 'Urząd Gminy Ciechanów') {
    source.config.contentSelector = '.sidebar-content';
    source.config.titleSelector = '.lead h3';
  }
  if (source.name.startsWith('NASK'))
    source.config.linkSelector = 'a[href^="/research-areas/projects/"]:not([href*="/page/"])';
}

const map = additionalSources.find((s) => s.name.includes('Mapa innowacji'));
Object.assign(map, {
  connector: 'html',
  enabled: true,
  config: {
    format: 'gov-map',
    reviewRequired: true,
    note: 'Odczyt osobnych rekordów z oficjalnej Mapy innowacji. Data pobrania nie oznacza daty wdrożenia; opis może być historyczny.',
  },
});

const verifiedUrls = [
  'https://gminaciechanow.pl/art/2854/projekt-rozwiazania-cyfrowe-dla-mazowieckiej-administracji',
  'https://plonsk.pl/aktualnosci/zaczynamy-realizacje-zadania-dostosowanie-zielono-niebieskiej-infrastruktury-w-plonsku-do-zmian-klimatu.html',
  'https://bip.powiat-ciechanow.pl/',
  'https://science.nask.pl/research-areas/projects/page/1',
  'https://www.meil.pw.edu.pl/dm/MEiL/Wydzial/Lotnisko-Przasnysz',
  'https://samorzad.gov.pl/web/powiat-przasnyski/uroczyste-otwarcie-osrodka-badan-lotniczych-i-kosmicznych-w-przasnyszu',
  'https://bip.mlawa.pl/projekt/cyberbezpieczny-samorzad-projekt-grantowy',
  'https://www.powiatmlawski.pl/4223%2Crozwiazania-cyfrowe-dla-mazowieckiej-administracji',
];
for (const source of additionalSources)
  if (verifiedUrls.includes(source.url)) source.enabled = true;

for (const source of additionalSources) {
  if (source.name === 'Urząd Miasta Ciechanów')
    source.config.note =
      'Test 21.11.2026: serwer zwraca HTTP 403. Pobieranie wyłączone; potrzebny dozwolony kanał dostępu.';
  if (source.name.startsWith('Łukasiewicz'))
    source.config.note =
      'Test 21.11.2026: serwis wyświetla przerwę techniczną. Ponów test po przywróceniu strony.';
  if (source.name === 'Urząd Gminy Przasnysz')
    source.config.note =
      'Test: przekierowanie do innej domeny. Zweryfikuj docelowy adres i skonfiguruj go jawnie.';
  if (!source.enabled && source.connector === 'html' && !source.config.note)
    source.config.note =
      'Test: brak pasujących artykułów na bieżącej liście. Wymaga dopasowania zakresu pobierania przed aktywacją.';
}
