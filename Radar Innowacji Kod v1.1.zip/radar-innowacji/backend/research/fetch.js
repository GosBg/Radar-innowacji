import https from 'node:https';
import { Resolver } from 'node:dns/promises';
const dns = new Resolver({ timeout: 3000, tries: 2 });
import { BlockList, isIP } from 'node:net';
import robotsParser from 'robots-parser';

const blocked = new BlockList();
for (const [ip, bits] of [
  ['0.0.0.0', 8],
  ['10.0.0.0', 8],
  ['100.64.0.0', 10],
  ['127.0.0.0', 8],
  ['169.254.0.0', 16],
  ['172.16.0.0', 12],
  ['192.168.0.0', 16],
  ['192.0.0.0', 24],
  ['198.18.0.0', 15],
  ['224.0.0.0', 4],
  ['240.0.0.0', 4],
])
  blocked.addSubnet(ip, bits);
export function validateUrl(value) {
  const url = new URL(value);
  if (
    url.protocol !== 'https:' ||
    url.username ||
    url.password ||
    (url.port && url.port !== '443') ||
    isIP(url.hostname) ||
    !url.hostname.includes('.')
  )
    throw new Error('Źródło musi mieć publiczny adres HTTPS bez danych logowania.');
  url.hash = '';
  return url;
}
export async function publicFetch(value, origin, redirects = 0) {
  const url = validateUrl(value);
  if (origin && url.origin !== origin) throw new Error('Przekierowanie poza domenę źródła.');
  const addresses = await dns.resolve4(url.hostname);
  if (!addresses.length || addresses.some((ip) => blocked.check(ip)))
    throw new Error('Adres prywatny lub zastrzeżony jest zabroniony.');
  // Pin a validated DNS answer for the request, preventing DNS rebinding.
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      {
        headers: {
          'User-Agent': 'RadarInnovacji/0.4 (+research; contact: admin@radarinnowacji.pl)',
          Accept: 'text/html,application/xml,text/xml,application/rss+xml',
        },
        lookup: (_host, options, cb) =>
          options.all
            ? cb(null, [{ address: addresses[0], family: 4 }])
            : cb(null, addresses[0], 4),
      },
      async (response) => {
        if ([301, 302, 303, 307, 308].includes(response.statusCode)) {
          response.resume();
          if (redirects >= 3) return reject(new Error('Zbyt wiele przekierowań.'));
          try {
            resolve(
              await publicFetch(
                new URL(response.headers.location, url).href,
                url.origin,
                redirects + 1,
              ),
            );
          } catch (e) {
            reject(e);
          }
          return;
        }
        if (response.statusCode !== 200) {
          response.resume();
          reject(new Error(`HTTP ${response.statusCode}`));
          return;
        }
        const type = response.headers['content-type'] || '';
        if (!/(text\/|xml|json)/i.test(type)) {
          response.resume();
          reject(new Error('Ten konektor obsługuje HTML/XML, nie pliki binarne.'));
          return;
        }
        const chunks = [];
        let size = 0;
        response.on('data', (chunk) => {
          size += chunk.length;
          if (size > 5 * 1024 * 1024) req.destroy(new Error('Źródło przekracza 5 MB.'));
          else chunks.push(chunk);
        });
        response.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        response.on('error', reject);
      },
    );
    const timer = setTimeout(
      () => req.destroy(new Error('Przekroczono czas pobierania źródła.')),
      20000,
    );
    req.on('close', () => clearTimeout(timer));
    req.on('error', reject);
  });
}
export async function sourceFetcher(source) {
  const origin = validateUrl(source.url).origin;
  let rules;
  try {
    rules = robotsParser(`${origin}/robots.txt`, await publicFetch(`${origin}/robots.txt`, origin));
  } catch (e) {
    if (!e.message.includes('HTTP 404')) throw e;
  }
  let last = 0;
  return async (value) => {
    const url = validateUrl(value);
    if (url.origin !== origin || rules?.isAllowed(url.href, 'RadarInnovacji') === false)
      throw new Error('Źródło nie pozwala na pobranie tego adresu.');
    const delay = Math.max(1000, (rules?.getCrawlDelay('RadarInnovacji') || 0) * 1000);
    if (delay > 60000) throw new Error('Crawl-delay wymaga osobnej konfiguracji konektora.');
    await new Promise((resolve) => setTimeout(resolve, Math.max(0, delay - (Date.now() - last))));
    last = Date.now();
    return publicFetch(url.href, origin);
  };
}
