import { randomUUID } from 'node:crypto';
import { additionalSources } from './additional-sources.js';
const presets = [
  [
    'NCBR — sukcesy beneficjentów',
    'https://www.gov.pl/web/ncbr/wyszukiwarka-sukcesow-beneficjentow',
    'ncbr',
    true,
  ],
  ['Interreg — projekty', 'https://interreg.gov.pl/lista-projektow/', 'pending', false],
  [
    'UPRP — patenty',
    'https://ewyszukiwarka.pue.uprp.gov.pl/search/simple-search',
    'pending',
    false,
  ],
  ['EPO — rejestr', 'https://register.epo.org/regviewer', 'pending', false],
  ['Polska Bibliografia Naukowa', 'https://pbn.nauka.gov.pl/core/#/home', 'pending', false],
  ['Polska Platforma Medyczna', 'https://ppm.edu.pl/index.seam', 'pending', false],
  ['PAN — czasopisma', 'https://www.czasopisma.pan.pl/dlibra', 'pending', false],
  ['BazTol', 'https://baztol.library.put.poznan.pl/baztol_czytelnik/baztol', 'pending', false],
  ['CORDIS', 'https://cordis.europa.eu/', 'pending', false],
];
export async function seedSources(db) {
  const sources = [
    ...presets.map(([name, url, connector, enabled]) => ({
      name,
      url,
      connector,
      enabled,
      config: {},
    })),
    ...additionalSources,
  ];
  await db.transaction(async (tx) => {
    await tx.query('SELECT pg_advisory_xact_lock(713245)');
    for (const source of sources) {
      await tx.query(
        `INSERT INTO research_sources(id,name,url,connector,enabled,config)
       SELECT $1,$2,$3,$4,$5,$6 WHERE NOT EXISTS(SELECT 1 FROM removed_source_urls WHERE url=$3)
       ON CONFLICT(url) DO NOTHING`,
        [
          randomUUID(),
          source.name,
          source.url,
          source.connector,
          source.enabled,
          JSON.stringify(source.config),
        ],
      );
    }
  });
}
