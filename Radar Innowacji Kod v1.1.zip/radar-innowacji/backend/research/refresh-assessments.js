import { assessTrl } from './trl.js';
import { randomUUID } from 'node:crypto';
// Existing cards are upgraded immediately, without inventing missing source text.
export async function refreshAssessments(db) {
  return db.transaction(async (tx) => {
    await tx.query('SELECT pg_advisory_xact_lock(713246)');
    const rows = (
      await tx.query(
        "SELECT * FROM innovations WHERE assessment->>'trlVersion' IS DISTINCT FROM '5' ORDER BY id FOR UPDATE",
      )
    ).rows;
    for (const row of rows) {
      const evidence = (
        await tx.query(
          'SELECT title,excerpt FROM evidence WHERE innovation_id=$1 ORDER BY fetched_at DESC',
          [row.id],
        )
      ).rows;
      const text = [
        row.description,
        row.problem,
        row.application,
        row.assessment?.stageEvidence,
        row.assessment?.trlEvidence,
        ...evidence.map((e) => e.excerpt),
      ]
        .filter(Boolean)
        .join('\n');
      const trl = assessTrl({ title: row.title, intro: row.description, text }, row.category);
      await tx.query('INSERT INTO innovation_history(id,innovation_id,snapshot) VALUES($1,$2,$3)', [
        randomUUID(),
        row.id,
        JSON.stringify(row),
      ]);
      await tx.query(
        'UPDATE innovations SET assessment=assessment || $2::jsonb,changed_at=now() WHERE id=$1',
        [row.id, JSON.stringify({ ...trl, trlInput: 'stored_excerpt' })],
      );
    }
    if (rows.length)
      await tx.query(
        "UPDATE research_sources SET next_run_at=now(),config=jsonb_set(config,'{cursor}','0'::jsonb) WHERE enabled",
      );
    return rows.length;
  });
}
