CREATE TABLE IF NOT EXISTS organizations (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL UNIQUE, name text NOT NULL,
 verified boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS users (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, login text NOT NULL UNIQUE, email text NOT NULL UNIQUE,
 password_hash text NOT NULL, name text NOT NULL, account_type text NOT NULL CHECK(account_type IN ('private','company')),
 role text NOT NULL DEFAULT 'user' CHECK(role IN ('user','moderator','admin')),
 city text NOT NULL, region text NOT NULL, affiliation text NOT NULL,
 email_verified boolean NOT NULL DEFAULT false, contact_consent boolean NOT NULL DEFAULT false,
 example boolean NOT NULL DEFAULT false, avatar_id uuid, mfa_secret text, mfa_last_step bigint,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS memberships (
 user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 organization_id uuid NOT NULL REFERENCES organizations ON DELETE CASCADE,
 tenant_id uuid NOT NULL REFERENCES organizations(tenant_id),
 PRIMARY KEY(user_id,organization_id)
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash text PRIMARY KEY, user_id uuid REFERENCES users ON DELETE CASCADE,
 csrf_hash text NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS auth_tokens (
 token_hash text PRIMARY KEY, user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 kind text NOT NULL CHECK(kind IN ('verify','reset')), expires_at timestamptz NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS registration_uploads (
 token_hash text PRIMARY KEY, user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 expires_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS innovations (
 id uuid PRIMARY KEY, tenant_id uuid NOT NULL, owner_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 title text NOT NULL, description text NOT NULL, category text NOT NULL, stage text NOT NULL, art text NOT NULL DEFAULT 'tech',
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','published','rejected','archived')),
 similar_id uuid REFERENCES innovations ON DELETE SET NULL, rejection_reason text,
 created_at timestamptz NOT NULL DEFAULT now(), published_at timestamptz
);
CREATE TABLE IF NOT EXISTS ratings (
 innovation_id uuid NOT NULL REFERENCES innovations ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE, category smallint NOT NULL CHECK(category BETWEEN 0 AND 3),
 value numeric(2,1) NOT NULL CHECK(value BETWEEN 0.5 AND 5 AND value*2=trunc(value*2)),
 updated_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(innovation_id,user_id,category)
);
CREATE TABLE IF NOT EXISTS favorites (
 user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 innovation_id uuid NOT NULL REFERENCES innovations ON DELETE CASCADE, PRIMARY KEY(user_id,innovation_id)
);
CREATE TABLE IF NOT EXISTS conversations (
 id uuid PRIMARY KEY, pair_key text NOT NULL UNIQUE, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS conversation_members (
 conversation_id uuid NOT NULL REFERENCES conversations ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE, PRIMARY KEY(conversation_id,user_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id uuid PRIMARY KEY, conversation_id uuid NOT NULL REFERENCES conversations ON DELETE CASCADE,
 sender_id uuid REFERENCES users ON DELETE SET NULL, body text NOT NULL CHECK(length(body) BETWEEN 1 AND 2000),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reports (
 id uuid PRIMARY KEY, reporter_id uuid REFERENCES users ON DELETE SET NULL,
 kind text NOT NULL CHECK(kind IN ('idea','message')), innovation_id uuid REFERENCES innovations ON DELETE SET NULL,
 message_id uuid REFERENCES messages ON DELETE SET NULL, target_user_id uuid REFERENCES users ON DELETE SET NULL,
 reason text NOT NULL, status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved')),
 created_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz
);
CREATE TABLE IF NOT EXISTS sanctions (
 id uuid PRIMARY KEY, user_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 kind text NOT NULL CHECK(kind IN ('post','mute')), reason text NOT NULL,
 expires_at timestamptz, revoked_at timestamptz, created_by uuid REFERENCES users ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(kind <> 'mute' OR expires_at IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS attachments (
 id uuid PRIMARY KEY, owner_id uuid NOT NULL REFERENCES users ON DELETE CASCADE,
 innovation_id uuid REFERENCES innovations ON DELETE CASCADE,
 purpose text NOT NULL CHECK(purpose IN ('idea','avatar')),
 original_name text NOT NULL, mime text NOT NULL, size integer NOT NULL CHECK(size>0),
 scan_status text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS moderation_log (
 id uuid PRIMARY KEY, actor_id uuid REFERENCES users ON DELETE SET NULL,
 action text NOT NULL, target_id uuid, details jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS innovations_public_idx ON innovations(status,published_at DESC);
CREATE INDEX IF NOT EXISTS innovations_owner_idx ON innovations(owner_id);
CREATE INDEX IF NOT EXISTS messages_thread_idx ON messages(conversation_id,created_at);
CREATE INDEX IF NOT EXISTS sanctions_user_idx ON sanctions(user_id,kind);
CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status,kind,created_at);
CREATE INDEX IF NOT EXISTS tokens_expiry_idx ON auth_tokens(expires_at);
