import test from 'node:test';
import assert from 'node:assert/strict';
import { assessTrl } from '../backend/research/trl.js';
import { classify } from '../backend/research/classify.js';
const record = (text) => ({ title: 'Technologia pomiarowa', intro: 'Czujnik jakości', text });
test('technology category always requires TRL even without technology keywords', () => {
  const a = classify({
    title: 'ABC',
    intro: 'Nowe rozwiązanie',
    text: 'Brak szczegółowych danych',
    creator: 'Firma',
  }).assessment;
  assert.equal(a.trlKind, 'unknown');
  assert.equal(a.trl, null);
});
test('TRL recognizes explicit Arabic, Roman and Polish declarations', () => {
  for (const text of [
    'Rozwiązanie osiągnęło TRL 7.',
    'Poziom gotowości technologicznej: VII.',
    'Aktualny TRL wynosi 7.',
  ]) {
    const a = assessTrl(record(text));
    assert.equal(a.trl, 7, text);
    assert.equal(a.trlKind, 'source');
  }
});
test('TRL never treats goals, ranges, negatives, conflicting values or funding as achieved maturity', () => {
  for (const text of [
    'Docelowo TRL 9.',
    'Wymagany TRL 7.',
    'Nie osiągnięto TRL 8.',
    'TRL 7–9.',
    'TRL 10.',
    'TRL 7.5.',
    'TRL 4. TRL 8.',
    'Pozyskano patent oraz 10 milionów złotych dotacji.',
    'Nie przetestowano urządzenia w warunkach laboratoryjnych.',
    'Prototyp zostanie przetestowany w warunkach operacyjnych.',
  ])
    assert.equal(assessTrl(record(text)).trl, null, text);
});
test('TRL estimates all nine levels with the source sentence attached', () => {
  const descriptions = [
    'Zaobserwowano podstawowe zjawiska fizyczne.',
    'Sformułowano koncepcję technologii pomiarowej.',
    'Potwierdzono koncepcję eksperymentalnie.',
    'Prototyp przetestowano w warunkach laboratoryjnych.',
    'Komponent zweryfikowano w warunkach reprezentatywnych.',
    'Prototyp przetestowano w warunkach zbliżonych do rzeczywistych.',
    'Prototyp zademonstrowano w warunkach operacyjnych.',
    'System ukończono i pomyślnie przeszedł testy kwalifikacyjne.',
    'System jest stosowany w warunkach operacyjnych.',
  ];
  descriptions.forEach((text, i) => {
    const a = assessTrl(record(text));
    assert.equal(a.trl, i + 1, text);
    assert.equal(a.trlKind, 'estimate');
    assert.equal(a.trlEvidence, text);
  });
});

test('possible usefulness in daily work is not proven operational deployment', () => {
  assert.equal(
    assessTrl(
      record(
        'Rozwiązanie jest szczególnie przydatne dla działów analitycznych, które potrzebują przeszukiwać dane w codziennej pracy.',
      ),
    ).trl,
    null,
  );
});
