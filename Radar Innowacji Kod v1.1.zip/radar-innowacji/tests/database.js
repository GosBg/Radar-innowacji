import pg from 'pg';
import { randomUUID } from 'node:crypto';
export async function testDatabase() {
  if (!process.env.TEST_DATABASE_URL)
    throw new Error('Uruchom npm test — testy wymagają izolowanego PostgreSQL.');
  const name = 'test_' + randomUUID().replaceAll('-', '');
  const admin = new pg.Client({ connectionString: process.env.TEST_DATABASE_URL });
  await admin.connect();
  await admin.query(`CREATE DATABASE ${name}`);
  const url = new URL(process.env.TEST_DATABASE_URL);
  url.pathname = '/' + name;
  return {
    url: url.href,
    close: async () => {
      await admin.query(`DROP DATABASE ${name} WITH (FORCE)`);
      await admin.end();
    },
  };
}
