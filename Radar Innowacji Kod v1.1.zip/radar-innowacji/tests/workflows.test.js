import test from 'node:test';
import assert from 'node:assert/strict';
import {
  containsProfanity,
  findSimilarInnovation,
  publishInnovation,
  removeInnovation,
} from '../frontend/domain/moderation.js';
import { validateAvatar, validateIdea, validateProfile } from '../frontend/domain/validation.js';

test('similarity flags overlap, ignores pending and does not match substrings', () => {
  const idea = {
    id: 'one',
    title: 'Sensor wody',
    description: 'Rehabilitacja pacjenta',
    status: 'published',
  };
  assert.equal(findSimilarInnovation(idea, [idea]), 'one');
  assert.equal(findSimilarInnovation(idea, [{ ...idea, status: 'pending' }]), null);
  assert.equal(
    findSimilarInnovation({ title: 'Sensory', description: 'Elektrownia' }, [idea]),
    null,
  );
});

test('profanity check supports Unicode words and letter variants', () => {
  assert.equal(containsProfanity('To jest kurwa test'), true);
  assert.equal(containsProfanity('KURWĄ'), true);
  assert.equal(containsProfanity('Kulturalny opis rozwiązania'), false);
});

test('republishing an archived innovation preserves its first publication date', () => {
  const item = publishInnovation({ created: 5, publishedAt: null }, 10);
  assert.equal(item.publishedAt, 10);
  assert.equal(publishInnovation({ ...item, status: 'archived' }, 20).publishedAt, 10);
  assert.equal(item.created, 5);
});

test('deletion removes stale favorites, scores and duplicate references', () => {
  const state = {
    items: [{ id: 'one' }, { id: 'two', similar: 'one' }],
    ratings: { one: { alice: [4] } },
    favorites: { alice: ['one', 'two'], guest: ['one'] },
  };
  const result = removeInnovation(state, 'one');
  assert.equal(result.items[0].similar, null);
  assert.deepEqual(result.favorites, { alice: ['two'], guest: [] });
  assert.deepEqual(result.ratings, {});
  assert.equal(state.items.length, 2);
});

test('profile, idea and file validation rejects whitespace and invalid uploads', () => {
  assert.ok(
    validateProfile({
      type: 'private',
      name: '  ',
      city: 'X',
      affiliation: 'Student',
      region: 'Podkarpackie',
    }),
  );
  assert.ok(
    validateIdea({
      title: '        ',
      description: ' '.repeat(40),
      category: 'Zdrowie',
      stage: 'Pomysł',
    }),
  );
  assert.ok(validateAvatar({ type: 'text/html', size: 10 }));
  assert.ok(validateAvatar({ type: 'image/png', size: 5 * 1024 * 1024 + 1 }));
  assert.equal(validateAvatar({ type: 'image/jpeg', size: 10 }), '');
});
