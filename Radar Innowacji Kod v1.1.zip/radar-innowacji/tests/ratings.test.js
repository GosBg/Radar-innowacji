import test from 'node:test';
import assert from 'node:assert/strict';
import { summarizeRatings, isRating, getRecommendation } from '../frontend/domain/ratings.js';

const idea = { id: 'idea', ratings: [0, 0, 0, 0], votes: 0 };

test('unrated innovation has no average or invented recommendation', () => {
  const summary = summarizeRatings(idea);
  assert.equal(summary.overall, null);
  assert.deepEqual(summary.categories, [null, null, null, null]);
  assert.equal(getRecommendation(summary), null);
});

test('partial ballots count real votes rather than treating missing categories as zero', () => {
  const summary = summarizeRatings(idea, {
    idea: { alice: [5, null, null, null], bob: [3, 4, null, null] },
  });
  assert.deepEqual(summary.categories, [4, 4, null, null]);
  assert.equal(summary.overall, 4);
  assert.equal(summary.voters, 2);
});

test('changing a vote replaces it; different profiles remain independent', () => {
  const votes = { idea: { alice: [5], bob: [3] } };
  votes.idea.alice[0] = 4;
  assert.equal(summarizeRatings(idea, votes).overall, 3.5);
  assert.equal(summarizeRatings(idea, votes).voters, 2);
});

test('seed aggregate and new votes have the correct weighting', () => {
  const summary = summarizeRatings(
    { ...idea, ratings: [4, 4, 4, 4], votes: 2 },
    { idea: { alice: [5] } },
  );
  assert.equal(summary.overall, 37 / 9);
  assert.equal(summary.categories[0], 13 / 3);
});

test('only half-star values from 0.5 through 5 are valid', () => {
  for (const value of [0, -1, 5.5, 2.25, NaN, null, '4']) assert.equal(isRating(value), false);
  for (const value of [0.5, 1, 2.5, 5]) assert.equal(isRating(value), true);
});
