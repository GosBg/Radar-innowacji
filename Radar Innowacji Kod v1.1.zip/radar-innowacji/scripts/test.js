import EmbeddedPostgres from './local-postgres.js';
import { mkdtemp, rm } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import path from 'node:path';
import os from 'node:os';
const root = await mkdtemp(path.join(os.tmpdir(), 'radar-pg-tests-'));
const password = randomBytes(24).toString('hex');
const port = Number(process.env.TEST_PG_PORT || 55433);
const postgres = new EmbeddedPostgres({
  databaseDir: path.join(root, 'db'),
  user: 'radar',
  password,
  port,
  persistent: true,
  authMethod: 'scram-sha-256',
  initdbFlags: ['--encoding=UTF8', '--locale=C'],
  postgresFlags: ['-h', '127.0.0.1'],
  onLog: () => {},
  onError: () => {},
});
let code = 1;
try {
  await postgres.initialise();
  await postgres.start();
  const child = spawn(process.execPath, ['--test', 'tests/*.test.js'], {
    stdio: 'inherit',
    windowsHide: true,
    env: {
      ...process.env,
      TEST_DATABASE_URL: `postgresql://radar:${password}@127.0.0.1:${port}/postgres`,
    },
  });
  code = await new Promise((resolve) => child.once('exit', resolve));
} finally {
  await postgres.stop();
  if (
    path.dirname(root) === path.resolve(os.tmpdir()) &&
    path.basename(root).startsWith('radar-pg-tests-')
  )
    await rm(root, { recursive: true, force: true });
}
process.exitCode = code || 0;
