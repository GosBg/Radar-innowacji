import EmbeddedPostgres from 'embedded-postgres';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { access } from 'node:fs/promises';
import path from 'node:path';
const run = promisify(execFile);

// pg_ctl performs a clean checkpoint on Windows. The package's default
// taskkill-based shutdown can hang under restricted Windows process access.
export default class LocalPostgres extends EmbeddedPostgres {
  constructor(options) {
    super(options);
    this.directory = path.resolve(options.databaseDir);
  }
  async stop() {
    if (process.platform !== 'win32') return super.stop();
    if (this.stopping) return this.stopping;
    this.stopping = (async () => {
      if (
        await access(path.join(this.directory, 'postmaster.pid'))
          .then(() => true)
          .catch(() => false)
      ) {
        const { pg_ctl } = await import('@embedded-postgres/windows-x64');
        await run(pg_ctl, ['stop', '-D', this.directory, '-m', 'fast', '-w', '-t', '15'], {
          windowsHide: true,
        });
      }
    })();
    return this.stopping;
  }
}
