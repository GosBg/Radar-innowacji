import test from 'node:test';
import assert from 'node:assert/strict';
import { testDatabase } from './database.js';
import { connectDatabase } from '../backend/db/connection.js';
import { seedSources } from '../backend/research/sources.js';
import { seedCatalog } from '../backend/research/seed-catalog.js';
test('fresh PostgreSQL starts with public catalog and keeps deletions across restarts', async () => {
  const isolated = await testDatabase();
  let db;
  try {
    db = await connectDatabase({ databaseUrl: isolated.url });
    await seedSources(db);
    await seedCatalog(db);
    const count = (await db.query('select count(*)::int n from innovations')).rows[0].n;
    assert.equal(count, 312);
    assert.equal((await db.query('select count(*)::int n from users')).rows[0].n, 0);
    const first = (await db.query('select id from innovations limit 1')).rows[0].id;
    await db.query('delete from innovations where id=$1', [first]);
    await seedCatalog(db);
    assert.equal((await db.query('select count(*)::int n from innovations')).rows[0].n, 311);
  } finally {
    await db?.close();
    await isolated.close();
  }
});
