import { testDatabase } from './database.js';
import { storeRecord } from '../backend/research/pipeline.js';
import { randomUUID } from 'node:crypto';
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { configuration } from '../backend/config.js';
import { encryption } from '../backend/lib/crypto.js';
import { connectDatabase } from '../backend/db/connection.js';
import { seed } from '../backend/db/seed.js';
import { createApp } from '../backend/app.js';
import { durationSeconds } from '../backend/lib/policy.js';
import { unzipSync } from 'fflate';
import sharp from 'sharp';
import { TOTP, Secret } from 'otpauth';
let app, db, config, folder, examples, admin, privateUser, company, other, isolated;
const origin = 'http://localhost:3000';
async function client() {
  const agent = request.agent(app);
  let csrf = (await agent.get('/api/v1/auth/session')).body.csrf;
  return {
    get: (p) => agent.get('/api/v1' + p),
    send: async (p, body = {}, method = 'post') => {
      const response = await agent[method]('/api/v1' + p)
        .set('Origin', origin)
        .set('X-CSRF-Token', csrf)
        .send(body);
      if (response.body.csrf) csrf = response.body.csrf;
      return response;
    },
    agent,
    csrf: () => csrf,
  };
}
before(async () => {
  folder = await mkdtemp(path.join(os.tmpdir(), 'radar-test-'));
  isolated = await testDatabase();
  config = configuration({
    databaseUrl: isolated.url,
    dataDir: folder,
    examples: true,
    testing: true,
    production: false,
  });
  const crypto = await encryption(config);
  db = await connectDatabase(config);
  await seed(db, config, crypto);
  app = createApp({ db, config, crypto });
  admin = await client();
  assert.equal(
    (await admin.send('/auth/login', { login: 'admin', password: 'admin' })).status,
    200,
  );
  examples = (await admin.get('/auth/examples')).body;
  const privates = examples.filter((u) => u.type === 'private' && u.role !== 'admin');
  privateUser = await client();
  privateUser.id = privates[0].id;
  await privateUser.send('/auth/example', { id: privateUser.id });
  other = await client();
  other.id = privates[1].id;
  await other.send('/auth/example', { id: other.id });
  company = await client();
  company.id = examples.find((u) => u.type === 'company').id;
  await company.send('/auth/example', { id: company.id });
});
after(async () => {
  await db?.close();
  await isolated?.close();
  if (folder) await rm(folder, { recursive: true, force: true });
});
test('anonymous cannot impersonate admin; CSRF and account access are enforced', async () => {
  const anon = await client();
  assert.equal(
    (await anon.send('/auth/example', { id: examples.find((u) => u.role === 'admin').id })).status,
    403,
  );
  assert.equal((await anon.get('/admin/users')).status, 401);
  assert.equal((await privateUser.get('/admin/users')).status, 403);
  assert.equal((await admin.agent.post('/api/v1/auth/logout').send({})).status, 403);
  assert.equal((await privateUser.send('/auth/profile', { role: 'admin' }, 'patch')).status, 400);
  const catalog = await anon.get('/ideas');
  assert.equal(catalog.status, 200);
  assert(!JSON.stringify(catalog.body).includes('password_hash'));
  assert(!JSON.stringify(catalog.body).includes('@'));
});
test('email verification and password reset tokens are one-use', async () => {
  const c = await client(),
    body = {
      login: 'newuser',
      email: 'new@example.invalid',
      password: 'long-password-123',
      name: 'Nowy Użytkownik',
      city: 'Bydgoszcz',
      region: 'Kujawsko-pomorskie',
      affiliation: 'student',
      type: 'private',
    };
  const registered = await c.send('/auth/register', body);
  assert.equal(registered.status, 201, JSON.stringify(registered.body));
  assert.equal(
    (await c.send('/auth/login', { login: body.login, password: body.password })).status,
    403,
  );
  const token = new URL(registered.body.developmentLink).searchParams.get('token');
  assert.equal((await c.send('/auth/token', { kind: 'verify', token })).status, 200);
  assert.equal((await c.send('/auth/token', { kind: 'verify', token })).status, 400);
  assert.equal(
    (await c.send('/auth/login', { login: body.login, password: body.password })).status,
    200,
  );
  const reset = await c.send('/auth/forgot', { email: body.email });
  const resetToken = new URL(reset.body.developmentLink).searchParams.get('token');
  assert.equal(
    (
      await c.send('/auth/token', {
        kind: 'reset',
        token: resetToken,
        password: 'different-password-123',
      })
    ).status,
    200,
  );
  assert.equal((await c.get('/admin/users')).status, 401);
});
test('registration avatar grant is single-use and cannot grant posting access', async () => {
  const c = await client();
  const registration = await c.send('/auth/register', {
    login: 'avatar-user',
    email: 'avatar@example.invalid',
    password: 'a-long-test-password',
    name: 'Zdjęcie Testowe',
    type: 'private',
    city: 'Toruń',
    region: 'Kujawsko-pomorskie',
    affiliation: 'student',
  });
  assert.equal(registration.status, 201);
  const png = await sharp({ create: { width: 16, height: 16, channels: 3, background: '#187c68' } })
    .png()
    .toBuffer();
  const post = (purpose) =>
    c.agent
      .post(`/api/v1/files/upload/${purpose}`)
      .set('Origin', origin)
      .set('X-CSRF-Token', c.csrf())
      .set('X-Registration-Token', registration.body.avatarTicket)
      .attach('file', png, 'avatar.png');
  assert.equal((await post('idea')).status, 400);
  const file = await post('avatar');
  assert.equal(file.status, 201, JSON.stringify(file.body));
  assert.equal((await post('avatar')).status, 403);
  assert.equal((await c.get(`/files/${file.body.id}?inline=1`)).status, 200);
  assert.equal((await c.send('/ideas', {})).status, 404);
});
test('admin MFA rejects missing and replayed codes', async () => {
  const crypto = await encryption(config),
    secret = new Secret(),
    totp = new TOTP({ secret });
  await db.query("UPDATE users SET mfa_secret=$1,mfa_last_step=NULL WHERE role='admin'", [
    crypto.seal(Buffer.from(secret.base32)).toString('base64'),
  ]);
  const c = await client();
  assert.equal((await c.send('/auth/login', { login: 'admin', password: 'admin' })).status, 401);
  const otp = totp.generate();
  assert.equal(
    (await c.send('/auth/login', { login: 'admin', password: 'admin', otp })).status,
    200,
  );
  assert.equal(
    (await c.send('/auth/login', { login: 'admin', password: 'admin', otp })).status,
    401,
  );
  await db.query("UPDATE users SET mfa_secret=NULL,mfa_last_step=NULL WHERE role='admin'");
});
let ideaId, source, record;
test('automatic ingestion keeps sources and preserves identity, favorites and ratings on update', async () => {
  source = { id: randomUUID() };
  await db.query(
    "INSERT INTO research_sources(id,name,url,connector) VALUES($1,'Źródło testowe','https://example.org/list','html')",
    [source.id],
  );
  record = {
    url: 'https://example.org/solution',
    title: 'Czujnik do pomiaru jakości wody',
    text: 'Opracowano prototyp czujnika. Rozwiązanie mierzy jakość wody w instalacjach przemysłowych. '.repeat(
      5,
    ),
    intro: 'Czujnik mierzy jakość wody.',
    creator: 'Instytut Testowy',
    problem: 'Kontrola jakości wody',
    application: 'Przemysł',
    date: null,
  };
  assert.equal(await storeRecord(db, source, record), true);
  const first = (await privateUser.get('/ideas')).body.items[0];
  ideaId = first.id;
  assert.equal(first.stage, 'Prototyp');
  assert.equal(first.sources[0].url, record.url);
  assert.equal(first.assessment.trl, null);
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/rating`, { category: 0, value: 4.2 }, 'put')).status,
    400,
  );
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/rating`, { category: 0, value: 4.5 }, 'put')).status,
    200,
  );
  await privateUser.send(`/ideas/${ideaId}/favorite`, { active: true }, 'put');
  assert.equal(await storeRecord(db, source, record), false);
  assert.equal(
    await storeRecord(db, source, {
      ...record,
      text: record.text + ' Przeprowadzono testy w laboratorium.',
    }),
    true,
  );
  const after = (await privateUser.get(`/ideas/${ideaId}`)).body;
  assert.equal(after.id, first.id);
  assert.equal(after.summary.overall, 4.5);
  assert.equal(after.history.length, 1);
  assert((await privateUser.get('/state')).body.favorites.includes(ideaId));
  assert.equal((await privateUser.send('/ideas', record)).status, 404);
  assert.equal((await company.send('/conversations', { recipient: privateUser.id })).status, 404);
  assert.equal((await company.get(`/ideas/${ideaId}/contact`)).status, 404);
  assert.equal(
    (
      await privateUser.get(
        '/ideas?filters=' + encodeURIComponent(JSON.stringify({ query: 'Kontrola jakości' })),
      )
    ).body.total,
    1,
  );
});
test('comments accept one reply level, reject cross-card replies, profanity and unauthorized deletion', async () => {
  const c = await privateUser.send(`/ideas/${ideaId}/comments`, {
    body: 'Czy rozwiązanie było testowane w terenie?',
  });
  assert.equal(c.status, 201, JSON.stringify(c.body));
  const reply = await company.send(`/ideas/${ideaId}/comments`, {
    body: 'W źródle opisano testy laboratoryjne.',
    parentId: c.body.id,
  });
  assert.equal(reply.status, 201);
  assert.equal(
    (
      await company.send(`/ideas/${ideaId}/comments`, {
        body: 'Niedozwolone zagnieżdżenie',
        parentId: reply.body.id,
      })
    ).status,
    400,
  );
  assert.equal((await other.send(`/comments/${c.body.id}`, {}, 'delete')).status, 403);
  assert.equal((await other.send(`/ideas/${ideaId}/comments`, { body: 'Kurwa test' })).status, 400);
  await other.send('/reports', {
    kind: 'comment',
    targetId: c.body.id,
    reason: 'Proszę o weryfikację tej treści.',
  });
  const reports = (await admin.get('/admin/reports?kind=comment')).body.items;
  assert.equal(reports.length, 1);
  const context = (await admin.get(`/admin/reports/${reports[0].id}/context`)).body;
  assert.equal(context.reportedCommentId, c.body.id);
  assert.equal(context.comments.length, 2);
  assert.equal((await privateUser.get(`/admin/reports/${reports[0].id}/context`)).status, 403);
  await admin.send(`/users/${privateUser.id}/sanctions`, {}, 'post');
  assert.equal(
    (
      await admin.send(`/admin/users/${privateUser.id}/sanctions`, {
        kind: 'mute',
        reason: 'Naruszenie zasad dyskusji',
        days: 365,
        hours: 1,
        seconds: 0,
        permanent: false,
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await admin.send(`/admin/users/${privateUser.id}/sanctions`, {
        kind: 'mute',
        reason: 'Naruszenie zasad dyskusji',
        days: 0,
        hours: 1,
        seconds: 0,
        permanent: false,
      })
    ).status,
    200,
  );
  const muted = await privateUser.send(`/ideas/${ideaId}/comments`, {
    body: 'Próba podczas wyciszenia',
  });
  assert.equal(muted.status, 403);
  assert.equal(muted.body.details.kind, 'mute');
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/favorite`, { active: true }, 'put')).status,
    200,
  );
  await db.query("UPDATE sanctions SET expires_at=now()-interval '1 second' WHERE user_id=$1", [
    privateUser.id,
  ]);
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/comments`, { body: 'Po wygaśnięciu wyciszenia' }))
      .status,
    201,
  );
  await admin.send(`/admin/users/${other.id}/role`, { role: 'moderator' }, 'patch');
  assert.equal((await other.send(`/comments/${reply.body.id}`, {}, 'delete')).status, 200);
  assert.equal((await other.get('/admin/sources')).status, 403);
});
test('only admin manages sources; unsafe URLs and unsupported activation are rejected', async () => {
  assert.equal((await privateUser.get('/admin/sources')).status, 403);
  const body = {
    name: 'Nowe źródło',
    url: 'https://example.org/news',
    connector: 'html',
    enabled: false,
    interval_hours: 24,
    config: { linkSelector: 'article a', contentSelector: 'article' },
  };
  const r = await admin.send('/admin/sources', body);
  assert.equal(r.status, 201);
  assert.equal((await admin.send(`/admin/sources/${r.body.id}/run`)).status, 400);
  assert.equal(
    (
      await admin.send('/admin/sources', {
        ...body,
        url: 'https://example.net',
        connector: 'pending',
        enabled: true,
      })
    ).status,
    400,
  );
  const unsafe = await admin.send('/admin/sources', { ...body, url: 'http://127.0.0.1' });
  assert.notEqual(unsafe.status, 201);
});
test('deleting a reader account never deletes discovered innovations', async () => {
  assert.equal((await admin.send(`/admin/users/${company.id}`, {}, 'delete')).status, 200);
  assert.equal((await privateUser.get(`/ideas/${ideaId}`)).status, 200);
});
test('deleted cards are not silently recreated by the importer', async () => {
  assert.equal((await admin.send(`/ideas/${ideaId}`, {}, 'delete')).status, 200);
  assert.equal(
    await storeRecord(db, source, { ...record, text: record.text + ' Aktualizacja źródła.' }),
    false,
  );
  assert.equal((await privateUser.get('/ideas')).body.total, 0);
});
test('PostgreSQL stores full Unicode, including publication symbols and emoji', async () => {
  const c = await db.query("SELECT 'Zażółć gęślą jaźń 🧪 '::text AS value");
  assert.equal(c.rows[0].value, 'Zażółć gęślą jaźń 🧪 ');
});
test('explicit public origin passes CSRF while unrelated origins remain blocked', async () => {
  const service = (await import('../backend/middleware/session.js')).sessionService(db, {
    ...config,
    publicOrigin: 'https://radar.example.org',
  });
  const req = {
    method: 'POST',
    session: { csrf_hash: (await import('../backend/lib/crypto.js')).digest('test-csrf') },
    get: (name) => (name === 'origin' ? 'https://radar.example.org' : 'test-csrf'),
  };
  let failure;
  service.csrf(req, {}, (e) => (failure = e));
  assert.equal(failure, undefined);
  service.csrf(
    { ...req, get: (name) => (name === 'origin' ? 'https://evil.example.org' : 'test-csrf') },
    {},
    (e) => (failure = e),
  );
  assert.equal(failure.status, 403);
});

test('bulk source deletion is admin-only, atomic, permanent and preserves evidence', async () => {
  const { seedSources } = await import('../backend/research/sources.js');
  await seedSources(db);
  const source = (await db.query("SELECT * FROM research_sources WHERE connector='ncbr' LIMIT 1"))
    .rows[0];
  const extra = (await db.query("SELECT * FROM research_sources WHERE connector='pending' LIMIT 1"))
    .rows[0];
  const record = {
    url: source.url + '/deletion-test',
    title: 'Test zachowania dowodów',
    text: 'Technologia została wdrożona w zakładzie. '.repeat(10),
    intro: 'Test dowodów',
    creator: 'Test',
    problem: '',
    application: '',
    date: null,
  };
  await storeRecord(db, source, record);
  const evidence = (await db.query('SELECT * FROM evidence WHERE url=$1', [record.url])).rows[0];
  assert.equal((await privateUser.send('/admin/sources/delete', { ids: [source.id] })).status, 403);
  assert.equal((await admin.send('/admin/sources/delete', { ids: [] })).status, 400);
  assert.equal(
    (await admin.send('/admin/sources/delete', { ids: [source.id, randomUUID()] })).status,
    409,
  );
  assert.equal(
    (await db.query('SELECT id FROM research_sources WHERE id=$1', [source.id])).rows.length,
    1,
  );
  const result = await admin.send('/admin/sources/delete', { ids: [source.id, extra.id] });
  assert.equal(result.status, 200);
  assert.equal(result.body.deleted, 2);
  const card = await privateUser.get('/ideas/' + evidence.innovation_id);
  assert.equal(card.status, 200);
  assert.ok(JSON.stringify(card.body).includes(record.url));
  assert.ok(JSON.stringify(card.body).includes(source.name));
  assert.equal(await storeRecord(db, source, { ...record, url: record.url + '/new' }), false);
  await seedSources(db);
  assert.equal(
    (
      await db.query('SELECT id FROM research_sources WHERE url=ANY($1::text[])', [
        [source.url, extra.url],
      ])
    ).rows.length,
    0,
  );
  assert.equal(
    (
      await db.query(
        "SELECT id FROM moderation_log WHERE action='source.delete' AND target_id=$1",
        [source.id],
      )
    ).rows.length,
    1,
  );
});

test('existing technological cards receive mandatory TRL status and refresh is idempotent', async () => {
  const { refreshAssessments } = await import('../backend/research/refresh-assessments.js');
  await db.query(
    "UPDATE innovations SET category='Technologiczny',assessment=jsonb_build_object('trlKind','not_applicable')",
  );
  const count = await refreshAssessments(db);
  assert.ok(count > 0);
  assert.equal(
    (
      await db.query(
        "SELECT id FROM innovations WHERE category='Technologiczny' AND assessment->>'trlKind'='not_applicable'",
      )
    ).rows.length,
    0,
  );
  assert.equal(await refreshAssessments(db), 0);
});

test('catalog recovery is idempotent and preserves existing moderation decisions', async () => {
  const { recoverCatalog } = await import('../backend/research/recover-catalog.js');
  const source = (await db.query('SELECT * FROM research_sources LIMIT 1')).rows[0];
  const template = (await db.query('SELECT * FROM innovations LIMIT 1')).rows[0];
  const id = randomUUID(),
    url = 'https://example.org/recovery-new';
  const snapshot = {
    research_sources: [source],
    innovations: [{ ...template, id, owner_id: null, similar_id: null, status: 'published' }],
    evidence: [
      {
        id: randomUUID(),
        source_id: source.id,
        innovation_id: id,
        url,
        title: 'Recovery',
        excerpt: 'Evidence',
        content_hash: 'test',
        source_date: null,
        fetched_at: new Date().toISOString(),
        publisher_name: source.name,
        source_record: null,
      },
    ],
  };
  assert.equal((await recoverCatalog(db, snapshot)).restored, 1);
  const imported = (await db.query('SELECT innovation_id FROM evidence WHERE url=$1', [url]))
    .rows[0];
  await db.query("UPDATE innovations SET status='archived' WHERE id=$1", [imported.innovation_id]);
  assert.equal((await recoverCatalog(db, snapshot)).restored, 0);
  assert.equal(
    (await db.query('SELECT status FROM innovations WHERE id=$1', [imported.innovation_id])).rows[0]
      .status,
    'archived',
  );
});
