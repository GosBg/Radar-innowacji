import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { resolveRuntime } from '../scripts/runtime-directory.js';
test('different project copies reuse one persistent database; missing data never silently resets', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'radar-runtime-'));
  try {
    const first = path.join(root, 'v1'),
      second = path.join(root, 'v2'),
      legacy = path.join(first, '.runtime');
    await mkdir(legacy, { recursive: true });
    await writeFile(path.join(legacy, 'postgres-password'), 'test-only');
    const env = { RADAR_HOME: path.join(root, 'local') };
    assert.equal(await resolveRuntime(first, env), legacy);
    assert.equal(await resolveRuntime(second, env), legacy);
    assert.equal(
      await resolveRuntime(second, { ...env, DATA_DIR: 'explicit' }),
      path.join(second, 'explicit'),
    );
    await rm(path.join(legacy, 'postgres-password'));
    await assert.rejects(resolveRuntime(second, env), /niedostępna/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
