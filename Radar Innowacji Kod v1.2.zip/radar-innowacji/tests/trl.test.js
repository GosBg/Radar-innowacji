import test from 'node:test';
import assert from 'node:assert/strict';
import { assessTrl } from '../backend/research/trl.js';
import { classify } from '../backend/research/classify.js';
const record = (text) => ({ title: 'Technologia pomiarowa', intro: 'Czujnik jakości', text });
test('technology category always requires TRL even without technology keywords', () => {
  const a = classify({
    title: 'ABC',
    intro: 'Nowe rozwiązanie',
    text: 'Brak szczegółowych danych',
    creator: 'Firma',
  }).assessment;
  assert.equal(a.trlKind, 'unknown');
  assert.equal(a.trl, null);
});
test('TRL recognizes explicit Arabic, Roman and Polish declarations', () => {
  for (const text of [
    'Rozwiązanie osiągnęło TRL 7.',
    'Poziom gotowości technologicznej: VII.',
    'Aktualny TRL wynosi 7.',
  ]) {
    const a = assessTrl(record(text));
    assert.equal(a.trl, 7, text);
    assert.equal(a.trlKind, 'source');
  }
});
test('TRL never treats goals, ranges, negatives, conflicting values or funding as achieved maturity', () => {
  for (const text of [
    'Docelowo TRL 9.',
    'Wymagany TRL 7.',
    'Nie osiągnięto TRL 8.',
    'TRL 7–9.',
    'TRL 10.',
    'TRL 7.5.',
    'TRL 4. TRL 8.',
    'Pozyskano patent oraz 10 milionów złotych dotacji.',
    'Nie przetestowano urządzenia w warunkach laboratoryjnych.',
    'Prototyp zostanie przetestowany w warunkach operacyjnych.',
  ])
    assert.equal(assessTrl(record(text)).trl, null, text);
});
test('TRL estimates all nine levels with the source sentence attached', () => {
  const descriptions = [
    'Zaobserwowano podstawowe zjawiska fizyczne.',
    'Sformułowano koncepcję technologii pomiarowej.',
    'Potwierdzono koncepcję eksperymentalnie.',
    'Prototyp przetestowano w warunkach laboratoryjnych.',
    'Komponent zweryfikowano w warunkach reprezentatywnych.',
    'Prototyp przetestowano w warunkach zbliżonych do rzeczywistych.',
    'Prototyp zademonstrowano w warunkach operacyjnych.',
    'System ukończono i pomyślnie przeszedł testy kwalifikacyjne.',
    'System jest stosowany w warunkach operacyjnych.',
  ];
  descriptions.forEach((text, i) => {
    const a = assessTrl(record(text));
    assert.equal(a.trl, i + 1, text);
    assert.equal(a.trlKind, 'estimate');
    assert.equal(a.trlEvidence, text);
  });
});

test('possible usefulness in daily work is not proven operational deployment', () => {
  assert.equal(
    assessTrl(
      record(
        'Rozwiązanie jest szczególnie przydatne dla działów analitycznych, które potrzebują przeszukiwać dane w codziennej pracy.',
      ),
    ).trl,
    null,
  );
});

test('real source wording provides a justified lower bound without pretending an exact TRL', () => {
  const a = assessTrl(
    record(
      'Opracowana technologia czujnika odkształceń może zostać wykorzystana w wielu gałęziach przemysłu.',
    ),
  );
  assert.equal(a.trl, null);
  assert.equal(a.trlMin, 2);
  assert.equal(a.trlKind, 'lower_bound');
  const b = assessTrl(record('Demonstracja działania robota'));
  assert.equal(b.trl, null);
  assert.equal(b.trlMin, 3);
  assert.equal(assessTrl(record('Planujemy opracowanie działającego prototypu.')).trlMin, null);
});
test('current TRL is retained when a separate clause describes a future target', () => {
  assert.equal(assessTrl(record('Obecnie TRL 6, a docelowo TRL 9.')).trl, 6);
});

test('actual NCBR descriptions recognize production, operational demonstrations and in-vitro validation', () => {
  assert.equal(
    assessTrl(record('Do produkcji wdrożono następujące zintegrowane moduły optoelektroniczne.'))
      .trl,
    8,
  );
  assert.equal(
    assessTrl(
      record(
        'Przeprowadzono demonstrację proponowanego rozwiązania na istniejących budynkach, w warunkach eksploatacyjnych.',
      ),
    ).trl,
    7,
  );
  assert.equal(
    assessTrl(record('Testowane nanokompozyty kolejno poddano testom biologicznym in vitro.')).trl,
    4,
  );
  assert.equal(assessTrl(record('W przyszłości do produkcji wdrożono nowe moduły.')).trl, null);
});
