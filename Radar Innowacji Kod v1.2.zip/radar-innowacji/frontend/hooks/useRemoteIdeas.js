import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import { useRadar } from '../app/RadarContext.jsx';
export default function useRemoteIdeas({ scope = '', filters = {}, favorites = false } = {}) {
  const { ready, revision, mergeIdeas, profile } = useRadar();
  const [page, setPage] = useState(1),
    [data, setData] = useState({ items: [], total: null, limit: 12 }),
    [error, setError] = useState(''),
    [loading, setLoading] = useState(true);
  const serialized = JSON.stringify(filters);
  useEffect(() => {
    setPage(1);
  }, [serialized, scope, favorites, profile?.id]);
  useEffect(() => {
    if (!ready) return;
    let stopped = false,
      timer,
      active;
    let initial = true;
    async function fetchPage() {
      if (stopped || active) return;
      const controller = new AbortController();
      active = controller;
      if (initial) setLoading(true);
      const deadline = setTimeout(() => controller.abort(), 15000);
      try {
        const params = new URLSearchParams({
          scope,
          filters: serialized,
          favorites: String(favorites),
          page: String(page),
        });
        const result = await api(`/ideas?${params}`, { signal: controller.signal });
        if (stopped) return;
        const last = Math.max(1, Math.ceil(result.total / result.limit));
        if (page > last) {
          setPage(last);
          return;
        }
        setData(result);
        mergeIdeas(result.items);
        setError('');
      } catch (e) {
        if (!stopped)
          setError(
            e.name === 'AbortError'
              ? 'Serwer odpowiada zbyt długo. Ponawiam pobieranie…'
              : e.message + ' — ponowię automatycznie.',
          );
      } finally {
        clearTimeout(deadline);
        active = null;
        if (!stopped) {
          initial = false;
          setLoading(false);
          timer = setTimeout(fetchPage, document.hidden ? 30000 : 5000);
        }
      }
    }
    const wake = () => {
      clearTimeout(timer);
      if (!document.hidden) fetchPage();
    };
    timer = setTimeout(fetchPage, 150);
    window.addEventListener('online', wake);
    window.addEventListener('focus', wake);
    document.addEventListener('visibilitychange', wake);
    return () => {
      stopped = true;
      clearTimeout(timer);
      active?.abort();
      window.removeEventListener('online', wake);
      window.removeEventListener('focus', wake);
      document.removeEventListener('visibilitychange', wake);
    };
  }, [ready, revision, serialized, scope, favorites, page, profile?.id, mergeIdeas]);
  return { ...data, page, setPage, error, loading };
}
