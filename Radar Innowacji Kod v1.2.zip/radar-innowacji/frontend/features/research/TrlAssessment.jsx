import React from 'react';
const labels = [
  'Obserwacja podstawowych zasad',
  'Koncepcja technologiczna',
  'Eksperymentalne potwierdzenie koncepcji',
  'Walidacja laboratoryjna',
  'Walidacja w warunkach reprezentatywnych',
  'Demonstracja prototypu w warunkach reprezentatywnych',
  'Demonstracja prototypu w warunkach operacyjnych',
  'Kompletny i zakwalifikowany system',
  'Rozwiązanie sprawdzone w eksploatacji',
];
export default function TrlAssessment({ assessment = {}, category }) {
  const a = assessment;
  const level = Number.isInteger(a.trl) && a.trl >= 1 && a.trl <= 9 ? a.trl : null;
  const required = category === 'Technologiczny';
  return (
    <>
      <strong>
        {level
          ? `TRL ${level}/9 · ${a.trlKind === 'estimate' ? 'Oszacowanie' : 'Deklaracja źródła'}`
          : a.trlKind === 'lower_bound' && a.trlMin
            ? `Co najmniej TRL ${a.trlMin} · dolna granica oszacowania`
            : required || a.trlKind === 'unknown'
              ? 'TRL wymaga ustalenia'
              : 'TRL nie dotyczy'}
      </strong>
      {level && (
        <>
          <p>{labels[level - 1]}</p>
          <div
            className="trl-scale"
            role="img"
            aria-label={`Poziom dojrzałości technologicznej ${level} z 9`}
          >
            {labels.map((label, index) => (
              <span
                key={label}
                className={index < level ? 'reached' : ''}
                title={`TRL ${index + 1}: ${label}`}
                aria-hidden="true"
              >
                {index + 1}
              </span>
            ))}
          </div>
        </>
      )}
      <p className="muted">
        {required && a.trlKind === 'not_applicable'
          ? 'Karta technologiczna wymaga oceny TRL. Trwa aktualizacja analizy źródła.'
          : a.trlNote}
      </p>
      {a.trlEvidence && <blockquote>{a.trlEvidence}</blockquote>}
      {a.trlInput === 'stored_excerpt' && (
        <small>
          Analiza dostępnych fragmentów; pełna treść zostanie sprawdzona przy ponownym pobraniu.
        </small>
      )}
      <details>
        <summary>Co oznacza skala TRL?</summary>
        <ol>
          {labels.map((label, i) => (
            <li key={label}>
              TRL {i + 1}: {label}
            </li>
          ))}
        </ol>
        <p>
          Brak danych nie oznacza TRL 1. Finansowanie, patent i oceny użytkowników nie wyznaczają
          poziomu TRL.
        </p>
        <a
          href="https://www.ukri.org/councils/stfc/guidance-for-applicants/check-if-youre-eligible-for-funding/eligibility-of-technology-readiness-levels-trl/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Definicje poziomów — UKRI ↗
        </a>
      </details>
    </>
  );
}
