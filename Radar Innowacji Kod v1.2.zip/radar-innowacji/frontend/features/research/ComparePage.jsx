import React from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../../components/ui/Button.jsx';
export default function ComparePage() {
  const { compareIds, state, toggleCompare, navigation } = useRadar();
  const items = compareIds.map((id) => state.items.find((i) => i.id === id)).filter(Boolean);
  const rows = [
    ['Obszar', (i) => i.category],
    ['Problem', (i) => i.problem || 'Nie ustalono'],
    ['Zastosowanie', (i) => i.application || 'Nie ustalono'],
    ['Twórca', (i) => i.author],
    ['Rodzaj podmiotu', (i) => i.creatorType],
    ['Etap', (i) => i.stage],
    [
      'TRL',
      (i) =>
        i.assessment?.trl
          ? `TRL ${i.assessment.trl} (${i.assessment.trlKind === 'source' ? 'źródło' : 'oszacowanie'})`
          : i.assessment?.trlMin
            ? `Co najmniej TRL ${i.assessment.trlMin}`
            : i.assessment?.trlNote || 'Nie ustalono',
    ],
    ['Podstawa oceny', (i) => i.assessment?.stageEvidence || 'Brak jednoznacznego dowodu etapu'],
    [
      'Ostatnio sprawdzono',
      (i) => (i.checkedAt ? new Date(i.checkedAt).toLocaleString('pl') : '—'),
    ],
    [
      'Opinia użytkowników',
      (i) =>
        i.summary?.overall
          ? `${i.summary.overall.toFixed(1)} / 5 (${i.summary.voters} osób)`
          : 'Brak ocen',
    ],
  ];
  return (
    <main className="simple-page" id="main-content">
      <div className="eyebrow dark">ODKRYWAJ • PORÓWNUJ • WDRAŻAJ</div>
      <h1>Porównaj rozwiązania</h1>
      <p>
        Zaznacz od 2 do 4 kart w katalogu. Etap rozwoju i gwiazdki użytkowników mają różne
        znaczenie.
      </p>
      {items.length < 2 ? (
        <Button onClick={() => navigation.go('discover')}>Wybierz rozwiązania w katalogu</Button>
      ) : (
        <div className="comparison-scroll">
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Kryterium</th>
                {items.map((i) => (
                  <th key={i.id}>
                    <button onClick={() => navigation.showIdea(i.id)}>{i.title}</button>
                    <button className="muted" onClick={() => toggleCompare(i.id)}>
                      Usuń z porównania
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(([label, value]) => (
                <tr key={label}>
                  <th>{label}</th>
                  {items.map((i) => (
                    <td key={i.id}>{value(i)}</td>
                  ))}
                </tr>
              ))}
              <tr>
                <th>Źródła</th>
                {items.map((i) => (
                  <td key={i.id}>
                    {i.sources?.map((s) => (
                      <p key={s.url}>
                        <a href={s.url} target="_blank" rel="noopener noreferrer">
                          {s.name} ↗
                        </a>
                      </p>
                    ))}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
