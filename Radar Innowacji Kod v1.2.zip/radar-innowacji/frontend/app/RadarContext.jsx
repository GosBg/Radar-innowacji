import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import useToast from '../hooks/useToast.js';
import useNavigation from '../hooks/useNavigation.js';
import { api } from '../api/client.js';
const RadarContext = createContext(null);
const empty = {
  items: [],
  profiles: [],
  conversations: [],
  favorites: [],
  reports: [],
  sanctions: [],
  ratings: {},
};
export function RadarProvider({ children }) {
  const [state, setState] = useState(empty),
    [profile, setProfile] = useState(null),
    [ready, setReady] = useState(false),
    [examples, setExamples] = useState(false),
    [revision, setRevision] = useState(0),
    [storageError, setError] = useState('');
  const [dialog, setDialog] = useState(() =>
      new URLSearchParams(location.search).has('auth') ? { type: 'token' } : null,
    ),
    [compareIds, setCompareIds] = useState(() => {
      try {
        const ids = JSON.parse(sessionStorage.getItem('radar-compare') || '[]');
        return Array.isArray(ids)
          ? ids.filter((x) => typeof x === 'string' && /^[a-f0-9-]{36}$/.test(x)).slice(0, 4)
          : [];
      } catch {
        return [];
      }
    });
  const toast = useToast(),
    navigation = useNavigation();
  const mergeIdeas = useCallback(
    (items) =>
      setState((s) => ({
        ...s,
        items: [...s.items.filter((i) => !items.some((n) => n.id === i.id)), ...items],
      })),
    [],
  );
  const refresh = useCallback(async () => {
    const data = await api('/state');
    setState((s) => ({ ...s, ...data }));
    setRevision((r) => r + 1);
  }, []);
  async function bootstrap() {
    try {
      const session = await api('/auth/session');
      setProfile(session.user);
      setExamples(session.examples);
      await refresh();
      setError('');
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    } finally {
      setReady(true);
    }
  }
  useEffect(() => {
    let stopped = false,
      timer;
    async function attempt() {
      const ok = await bootstrap();
      if (!ok && !stopped) timer = setTimeout(attempt, 5000);
    }
    attempt();
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    const timer = setInterval(() => refresh().catch(() => {}), 30000);
    return () => clearInterval(timer);
  }, [profile?.id, ready, refresh]);
  useEffect(() => {
    if (!navigation.ideaId || !ready) return;
    api(`/ideas/${navigation.ideaId}`)
      .then((item) => mergeIdeas([item]))
      .catch((e) => toast.notify(e.message));
  }, [navigation.ideaId, ready, revision, mergeIdeas]);
  useEffect(() => {
    try {
      sessionStorage.setItem('radar-compare', JSON.stringify(compareIds));
    } catch {}
  }, [compareIds]);
  useEffect(() => {
    if (!ready || !compareIds.length) return;
    Promise.all(compareIds.map((id) => api(`/ideas/${id}`).catch(() => null))).then((rows) =>
      mergeIdeas(rows.filter(Boolean)),
    );
  }, [compareIds, ready, profile?.id, mergeIdeas]);
  function handleError(error) {
    if (error.details?.kind) setDialog({ type: 'sanction', ...error.details });
    else toast.notify(error.message);
  }
  async function authenticate(path, body) {
    const data = await api(`/auth/${path}`, { method: 'POST', body });
    setProfile(data.user);
    setState(empty);
    await refresh();
    setDialog(null);
    return data;
  }
  const mutations = async (path, method, body) => {
    const data = await api(path, { method, body });
    await refresh();
    return data;
  };
  const innovations = {
    toggleFavorite: async (id) => {
      if (!profile) return setDialog({ type: 'login' });
      try {
        await mutations(`/ideas/${id}/favorite`, 'PUT', { active: !state.favorites.includes(id) });
      } catch (e) {
        handleError(e);
      }
    },
    rateIdea: async (id, category, value) => {
      try {
        mergeIdeas([await mutations(`/ideas/${id}/rating`, 'PUT', { category, value })]);
      } catch (e) {
        handleError(e);
      }
    },
    deleteIdea: async (id) => {
      await mutations(`/ideas/${id}`, 'DELETE');
      setState((s) => ({ ...s, items: s.items.filter((i) => i.id !== id) }));
      navigation.closeIdea();
    },
    moderate: async (id, action, reason = '') =>
      mutations(`/ideas/${id}/moderation`, 'PATCH', { action, reason }),
  };
  return (
    <RadarContext.Provider
      value={{
        state,
        profile,
        ready,
        examples,
        revision,
        storageError,
        ...toast,
        navigation,
        dialog,
        setDialog,
        closeDialog: () => setDialog(null),
        compareIds,
        toggleCompare: (id) =>
          setCompareIds((ids) =>
            ids.includes(id)
              ? ids.filter((x) => x !== id)
              : ids.length < 4
                ? [...ids, id]
                : (toast.notify('Możesz porównać maksymalnie 4 rozwiązania.'), ids),
          ),
        innovations,

        favorites: state.favorites,
        refresh,
        mergeIdeas,
        authenticate,
        bootstrap,
        handleError,
        saveProfile: async (body) => {
          const user = await api('/auth/profile', { method: 'PATCH', body });
          setProfile(user);
          await refresh();
        },
        logout: async () => {
          await authenticate('logout');
          navigation.go('discover');
        },
      }}
    >
      {children}
    </RadarContext.Provider>
  );
}
export function useRadar() {
  const value = useContext(RadarContext);
  if (!value) throw new Error('Brak RadarProvider.');
  return value;
}
