import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import { requireUser, checkSanction, audit } from '../lib/policy.js';
import { visibleIdea } from './ideas.js';
import { containsProfanity } from '../../frontend/domain/moderation.js';
const pageInput = (value) =>
  z.coerce
    .number()
    .int()
    .min(1)
    .max(10000)
    .parse(value || 1);
export function communityRoutes({ db }) {
  const router = Router();
  router.get(
    '/state',
    route(async (req, res) => {
      const favorites = req.user
        ? (
            await db.query('SELECT innovation_id FROM favorites WHERE user_id=$1', [req.user.id])
          ).rows.map((r) => r.innovation_id)
        : [];
      const catalog = (
        await db.query(
          "SELECT count(*) FILTER(WHERE status='published')::int AS published, count(*) FILTER(WHERE status='pending')::int AS pending FROM innovations WHERE owner_id IS NULL",
        )
      ).rows[0];
      res.json({
        profiles: [],
        favorites,
        reports: [],
        sanctions: [],
        catalog: {
          published: catalog.published,
          ...(req.user?.role === 'admin' || req.user?.role === 'moderator'
            ? { pending: catalog.pending }
            : {}),
        },
      });
    }),
  );
  router.get(
    '/ideas/:id/comments',
    route(async (req, res) => {
      await visibleIdea(db, req, req.params.id);
      const page = pageInput(req.query.page);
      const items = (
        await db.query(
          "SELECT c.id,c.parent_id,c.user_id,c.body,c.hidden,c.created_at,COALESCE(u.name,'Usunięte konto') AS author FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.innovation_id=$1 ORDER BY c.created_at,c.id LIMIT 50 OFFSET $2",
          [req.params.id, (page - 1) * 50],
        )
      ).rows.map((c) => ({ ...c, body: c.hidden ? 'Komentarz ukryty przez moderację.' : c.body }));
      res.json({
        items,
        page,
        total: (
          await db.query('SELECT count(*)::int AS total FROM comments WHERE innovation_id=$1', [
            req.params.id,
          ])
        ).rows[0].total,
      });
    }),
  );
  router.post(
    '/ideas/:id/comments',
    route(async (req, res) => {
      const user = requireUser(req);
      ensure(user.email_verified, 403, 'Potwierdź adres e-mail.');
      const idea = await visibleIdea(db, req, req.params.id);
      ensure(idea.status === 'published', 403, 'Dyskusja dotyczy publicznych kart.');
      await checkSanction(db, user.id, 'mute');
      const input = z
        .object({
          body: z.string().trim().min(1).max(2000),
          parentId: z.string().uuid().nullable().default(null),
        })
        .parse(req.body);
      ensure(!containsProfanity(input.body), 400, 'Wykryto wulgaryzm! Popraw komentarz.');
      if (input.parentId) {
        const parent = (await db.query('SELECT * FROM comments WHERE id=$1', [input.parentId]))
          .rows[0];
        ensure(
          parent && parent.innovation_id === idea.id && !parent.parent_id && !parent.hidden,
          400,
          'Odpowiedź musi odnosić się do dostępnego komentarza głównego tej innowacji.',
        );
      }
      const id = randomUUID();
      await db.query(
        'INSERT INTO comments(id,innovation_id,user_id,parent_id,body) VALUES($1,$2,$3,$4,$5)',
        [id, idea.id, user.id, input.parentId, input.body],
      );
      res.status(201).json({ id });
    }),
  );
  router.delete(
    '/comments/:id',
    route(async (req, res) => {
      const user = requireUser(req),
        id = z.string().uuid().parse(req.params.id);
      const row = (await db.query('SELECT * FROM comments WHERE id=$1', [id])).rows[0];
      ensure(row, 404, 'Brak komentarza.');
      ensure(
        row.user_id === user.id || ['admin', 'moderator'].includes(user.role),
        403,
        'Brak uprawnień.',
      );
      await db.query("UPDATE comments SET hidden=true,body='[usunięto]' WHERE id=$1", [id]);
      await audit(db, user, 'comment.hide', id);
      res.json({ ok: true });
    }),
  );
  router.get(
    '/reports',
    route(async (req, res) => {
      const user = requireUser(req),
        kind = z.enum(['idea', 'comment']).parse(req.query.kind || 'idea'),
        page = pageInput(req.query.page);
      res.json({
        items: (
          await db.query(
            'SELECT id,kind,reason,status,created_at,innovation_id,comment_id FROM reports WHERE reporter_id=$1 AND kind=$2 ORDER BY created_at DESC LIMIT 25 OFFSET $3',
            [user.id, kind, (page - 1) * 25],
          )
        ).rows,
        total: (
          await db.query(
            'SELECT count(*)::int AS total FROM reports WHERE reporter_id=$1 AND kind=$2',
            [user.id, kind],
          )
        ).rows[0].total,
        page,
      });
    }),
  );
  router.post(
    '/reports',
    route(async (req, res) => {
      const user = requireUser(req),
        input = z
          .object({
            kind: z.enum(['idea', 'comment']),
            targetId: z.string().uuid(),
            reason: z.string().trim().min(5).max(2000),
          })
          .parse(req.body);
      let idea,
        comment = null,
        owner = null;
      if (input.kind === 'idea') idea = (await visibleIdea(db, req, input.targetId)).id;
      else {
        const row = (
          await db.query('SELECT * FROM comments WHERE id=$1 AND hidden=false', [input.targetId])
        ).rows[0];
        ensure(row, 404, 'Brak komentarza.');
        await visibleIdea(db, req, row.innovation_id);
        idea = row.innovation_id;
        comment = row.id;
        owner = row.user_id;
      }
      const duplicate = (
        await db.query(
          "SELECT 1 FROM reports WHERE reporter_id=$1 AND kind=$2 AND status='open' AND ((comment_id=$3) OR ($3::uuid IS NULL AND innovation_id=$4))",
          [user.id, input.kind, comment, idea],
        )
      ).rows.length;
      ensure(!duplicate, 409, 'Zgłoszenie już oczekuje na rozpatrzenie.');
      await db.query(
        'INSERT INTO reports(id,reporter_id,kind,innovation_id,comment_id,target_user_id,reason) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [randomUUID(), user.id, input.kind, idea, comment, owner, input.reason],
      );
      res.status(201).json({ ok: true });
    }),
  );
  return router;
}
