-- Research data is independent of registered accounts. Legacy tables remain inert
-- for a non-destructive upgrade; the old submission and messaging APIs are removed.
ALTER TABLE innovations ALTER COLUMN owner_id DROP NOT NULL;
ALTER TABLE innovations DROP CONSTRAINT IF EXISTS innovations_owner_id_fkey;
ALTER TABLE innovations ADD CONSTRAINT innovations_owner_id_fkey FOREIGN KEY(owner_id) REFERENCES users ON DELETE SET NULL;
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS creator text NOT NULL DEFAULT 'Nie ustalono';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS creator_type text NOT NULL DEFAULT 'Nie ustalono';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS region text NOT NULL DEFAULT '';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS problem text NOT NULL DEFAULT '';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS application text NOT NULL DEFAULT '';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS recipient text NOT NULL DEFAULT 'Nie ustalono';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS assessment jsonb NOT NULL DEFAULT '{}';
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS checked_at timestamptz;
ALTER TABLE innovations ADD COLUMN IF NOT EXISTS changed_at timestamptz NOT NULL DEFAULT now();
CREATE TABLE IF NOT EXISTS research_sources (
 id uuid PRIMARY KEY, name text NOT NULL, url text NOT NULL UNIQUE,
 connector text NOT NULL CHECK(connector IN ('ncbr','html','rss','pending')),
 enabled boolean NOT NULL DEFAULT false, config jsonb NOT NULL DEFAULT '{}',
 interval_hours integer NOT NULL DEFAULT 24 CHECK(interval_hours BETWEEN 1 AND 720),
 next_run_at timestamptz NOT NULL DEFAULT now(), last_success_at timestamptz,
 last_error text, failures integer NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS source_runs (
 id uuid PRIMARY KEY, source_id uuid NOT NULL REFERENCES research_sources ON DELETE CASCADE,
 started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz,
 status text NOT NULL DEFAULT 'running', discovered integer NOT NULL DEFAULT 0,
 updated integer NOT NULL DEFAULT 0, error text
);
CREATE TABLE IF NOT EXISTS evidence (
 id uuid PRIMARY KEY, source_id uuid NOT NULL REFERENCES research_sources,
 innovation_id uuid NOT NULL REFERENCES innovations ON DELETE CASCADE,
 url text NOT NULL UNIQUE, title text NOT NULL, excerpt text NOT NULL,
 content_hash text NOT NULL, source_date timestamptz, fetched_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS innovation_history (
 id uuid PRIMARY KEY, innovation_id uuid NOT NULL REFERENCES innovations ON DELETE CASCADE,
 snapshot jsonb NOT NULL, changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS comments (
 id uuid PRIMARY KEY, innovation_id uuid NOT NULL REFERENCES innovations ON DELETE CASCADE,
 user_id uuid REFERENCES users ON DELETE SET NULL, parent_id uuid REFERENCES comments ON DELETE CASCADE,
 body text NOT NULL CHECK(length(body) BETWEEN 1 AND 2000), hidden boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE reports DROP CONSTRAINT IF EXISTS reports_kind_check;
ALTER TABLE reports ADD CONSTRAINT reports_kind_check CHECK(kind IN ('idea','message','comment'));
ALTER TABLE reports ADD COLUMN IF NOT EXISTS comment_id uuid REFERENCES comments ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS comments_idea_idx ON comments(innovation_id,created_at);
CREATE INDEX IF NOT EXISTS evidence_idea_idx ON evidence(innovation_id);
CREATE INDEX IF NOT EXISTS sources_due_idx ON research_sources(next_run_at) WHERE enabled;

CREATE TABLE IF NOT EXISTS ignored_source_urls (
 url text PRIMARY KEY, removed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE research_sources ADD COLUMN IF NOT EXISTS requested_at timestamptz;
CREATE TABLE IF NOT EXISTS worker_status (id text PRIMARY KEY, heartbeat_at timestamptz NOT NULL);

-- Preserve published evidence when a fetching configuration is removed.
CREATE TABLE IF NOT EXISTS removed_source_urls (url text PRIMARY KEY, removed_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE evidence ADD COLUMN IF NOT EXISTS publisher_name text NOT NULL DEFAULT '';
UPDATE evidence e SET publisher_name=s.name FROM research_sources s WHERE s.id=e.source_id AND e.publisher_name='';
ALTER TABLE evidence ALTER COLUMN source_id DROP NOT NULL;
ALTER TABLE evidence DROP CONSTRAINT IF EXISTS evidence_source_id_fkey;
ALTER TABLE evidence ADD CONSTRAINT evidence_source_id_fkey FOREIGN KEY(source_id) REFERENCES research_sources ON DELETE SET NULL;

ALTER TABLE evidence ADD COLUMN IF NOT EXISTS source_record jsonb;

CREATE TABLE IF NOT EXISTS catalog_bootstrap(id text PRIMARY KEY, imported_at timestamptz NOT NULL DEFAULT now());
