import { readFile } from 'node:fs/promises';
import pg from 'pg';
export async function connectDatabase(config) {
  if (!config.databaseUrl) throw new Error('Brak DATABASE_URL. Lokalnie uruchom npm run dev.');
  const engine = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });
  const query = (sql, parameters = []) => engine.query(sql, parameters);
  async function transaction(work) {
    const client = await engine.connect();
    try {
      await client.query('BEGIN');
      const result = await work(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
  await transaction(async (tx) => {
    await tx.query('SELECT pg_advisory_xact_lock(713243)');
    // Finish a bounded worker batch before schema changes take table locks.
    await tx.query('SELECT pg_advisory_xact_lock(713244)');
    await tx.query(await readFile(new URL('./schema.sql', import.meta.url), 'utf8'));
    await tx.query(await readFile(new URL('./research.sql', import.meta.url), 'utf8'));
  });
  return { query, transaction, close: () => engine.end(), engine: 'PostgreSQL' };
}
