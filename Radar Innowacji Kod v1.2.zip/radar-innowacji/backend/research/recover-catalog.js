import { randomUUID } from 'node:crypto';
// Merge only public research cards; never copy accounts, credentials or private submissions.
export async function recoverCatalog(db, snapshot) {
  return db.transaction(async (tx) => {
    await tx.query('SELECT pg_advisory_xact_lock(713244)');
    const sources = (await tx.query('SELECT id,url FROM research_sources')).rows;
    const sourceIds = new Map(
      snapshot.research_sources.map((s) => [s.id, sources.find((n) => n.url === s.url)?.id]),
    );
    const ignored = new Set(
      (await tx.query('SELECT url FROM ignored_source_urls')).rows.map((r) => r.url),
    );
    let restored = 0,
      skipped = 0;
    for (const old of snapshot.innovations) {
      if (old.owner_id || old.status !== 'published') {
        skipped++;
        continue;
      }
      const evidence = snapshot.evidence.filter((e) => e.innovation_id === old.id);
      // A deliberately deleted innovation or source must not return during recovery.
      if (evidence.some((e) => ignored.has(e.url))) {
        skipped++;
        continue;
      }
      const available = evidence.filter((e) => sourceIds.get(e.source_id));
      if (!available.length) {
        skipped++;
        continue;
      }
      const existing = await tx.query(
        'SELECT innovation_id FROM evidence WHERE url=ANY($1::text[]) LIMIT 1',
        [available.map((e) => e.url)],
      );
      if (existing.rows.length) {
        skipped++;
        continue;
      }
      const id = randomUUID();
      const row = { ...old, id, owner_id: null, similar_id: null };
      await tx.query(
        'INSERT INTO innovations SELECT (jsonb_populate_record(NULL::innovations,$1::jsonb)).*',
        [JSON.stringify(row)],
      );
      for (const e of available)
        await tx.query(
          'INSERT INTO evidence SELECT (jsonb_populate_record(NULL::evidence,$1::jsonb)).* ON CONFLICT(url) DO NOTHING',
          [
            JSON.stringify({
              ...e,
              id: randomUUID(),
              innovation_id: id,
              source_id: sourceIds.get(e.source_id),
            }),
          ],
        );
      restored++;
    }
    return { restored, skipped };
  });
}
