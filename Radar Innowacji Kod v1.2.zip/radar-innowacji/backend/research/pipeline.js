import { findSimilarInnovation } from '../../frontend/domain/moderation.js';
import { randomUUID, createHash } from 'node:crypto';
import { sourceFetcher } from './fetch.js';
import { discover, extract } from './connectors.js';
import { classify, CLASSIFIER_VERSION } from './classify.js';
const tenant = '00000000-0000-4000-8000-000000000001';
export async function storeRecord(db, source, record) {
  const hash = createHash('sha256')
    .update(CLASSIFIER_VERSION + record.text + record.title + record.intro)
    .digest('hex');
  return db.transaction(async (tx) => {
    // Serialize each short write with deletion; never recreate a removed source.
    const currentSource = (
      await tx.query('SELECT id,name FROM research_sources WHERE id=$1 FOR KEY SHARE', [source.id])
    ).rows[0];
    if (!currentSource) return false;

    if (
      (await tx.query('SELECT 1 FROM ignored_source_urls WHERE url=$1', [record.url])).rows.length
    )
      return false;
    const old = (await tx.query('SELECT * FROM evidence WHERE url=$1 FOR UPDATE', [record.url]))
      .rows[0];
    if (old?.content_hash === hash) {
      await tx.query('UPDATE evidence SET fetched_at=now() WHERE id=$1', [old.id]);
      await tx.query('UPDATE innovations SET checked_at=now() WHERE id=$1', [old.innovation_id]);
      return false;
    }
    const result = classify(record);
    let id = old?.innovation_id;
    if (!id && record.creator !== 'Nie ustalono')
      id = (
        await tx.query(
          'SELECT id FROM innovations WHERE lower(title)=lower($1) AND creator=$2 AND owner_id IS NULL LIMIT 1',
          [record.title, record.creator],
        )
      ).rows[0]?.id;
    if (!id) {
      id = randomUUID();
      await tx.query(
        'INSERT INTO innovations(id,tenant_id,title,description,category,stage,status,published_at,creator) VALUES($1,$2,$3,$4,$5,$6,$8,now(),$7)',
        [
          id,
          tenant,
          record.title,
          record.intro.slice(0, 900),
          result.category,
          result.stage,
          record.creator,
          source.config?.reviewRequired ? 'pending' : 'published',
        ],
      );
    } else {
      await tx.query(
        'INSERT INTO innovation_history(id,innovation_id,snapshot) SELECT $1,id,to_jsonb(i) FROM innovations i WHERE id=$2',
        [randomUUID(), id],
      );
    }
    await tx.query(
      'UPDATE innovations SET title=$2,description=$3,category=$4,stage=$5,creator=$6,creator_type=$7,problem=$8,application=$9,assessment=$10,checked_at=now(),changed_at=now() WHERE id=$1',
      [
        id,
        record.title,
        record.intro.slice(0, 900),
        result.category,
        result.stage,
        record.creator,
        result.creatorType,
        record.problem.slice(0, 1200),
        record.application.slice(0, 1200),
        JSON.stringify(result.assessment),
      ],
    );
    const candidates = (
      await tx.query(
        "SELECT id,title,description,status FROM innovations WHERE id<>$1 AND status='published' ORDER BY changed_at DESC LIMIT 2000",
        [id],
      )
    ).rows;
    const similar = findSimilarInnovation(
      { title: record.title, description: record.intro },
      candidates,
    );
    await tx.query('UPDATE innovations SET similar_id=$2 WHERE id=$1', [id, similar]);
    await tx.query(
      'INSERT INTO evidence(id,source_id,innovation_id,url,title,excerpt,content_hash,source_date,publisher_name,source_record) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(url) DO UPDATE SET source_record=EXCLUDED.source_record,source_id=EXCLUDED.source_id,publisher_name=EXCLUDED.publisher_name,title=EXCLUDED.title,excerpt=EXCLUDED.excerpt,content_hash=EXCLUDED.content_hash,source_date=EXCLUDED.source_date,fetched_at=now()',
      [
        randomUUID(),
        source.id,
        id,
        record.url,
        record.title,
        record.intro.slice(0, 500),
        hash,
        record.date,
        currentSource.name,
        JSON.stringify(record),
      ],
    );
    return true;
  });
}
export async function runDue(db) {
  // Transaction-level advisory lock survives no crashes and serializes workers.
  // The transaction is deliberately held for the bounded source batch.
  return db.transaction(async (lease) => {
    if (!(await lease.query('SELECT pg_try_advisory_xact_lock(713244) AS locked')).rows[0].locked)
      return;
    const source = (
      await lease.query(
        "SELECT * FROM research_sources WHERE enabled AND connector<>'pending' AND next_run_at<=now() ORDER BY next_run_at LIMIT 1",
      )
    ).rows[0];
    if (!source) return;
    const run = randomUUID();
    await db.query(
      "UPDATE source_runs SET status='interrupted',finished_at=now(),error='Worker przerwał poprzedni cykl; wznowiono.' WHERE source_id=$1 AND status='running'",
      [source.id],
    );
    await db.query('INSERT INTO source_runs(id,source_id) VALUES($1,$2)', [run, source.id]);
    let updated = 0,
      count = 0;
    try {
      const fetchPage = await sourceFetcher(source);
      const found = await discover(source, fetchPage);
      if (!found.length) throw new Error('Brak linków — możliwa zmiana struktury źródła.');
      const known = (
        await db.query('SELECT url FROM evidence WHERE source_id=$1 ORDER BY fetched_at', [
          source.id,
        ])
      ).rows.map((r) => r.url);
      // Persisted cursor processes the complete discovered list in bounded batches.
      // Each completed full cycle is followed by the configured 24-hour interval.
      const all = [...new Set([...found, ...known])];
      const cursor = Number(source.config.cursor || 0) % all.length;
      const links = all.slice(cursor, cursor + 20);
      const errors = [];
      const mapHtml = source.config.format === 'gov-map' ? await fetchPage(source.url) : null;
      for (const url of links) {
        try {
          const record = extract(mapHtml || (await fetchPage(url)), url, source);
          if (await storeRecord(db, source, record)) updated++;
          count++;
        } catch (e) {
          errors.push(`${url}: ${e.message}`);
        }
      }
      const done = cursor + 20 >= all.length;
      const message = errors.length ? errors.join('\n').slice(0, 2000) : null;
      await lease.query(
        "UPDATE research_sources SET last_success_at=CASE WHEN $5 THEN now() ELSE last_success_at END,last_error=$4,failures=0,next_run_at=CASE WHEN requested_at IS DISTINCT FROM $6::timestamptz THEN now() ELSE now()+CASE WHEN $3 THEN interval_hours*interval '1 hour' ELSE interval '1 minute' END END,config=jsonb_set(config,'{cursor}',$2::jsonb) WHERE id=$1",
        [
          source.id,
          JSON.stringify(done ? 0 : cursor + 20),
          done,
          message,
          count > 0,
          source.requested_at,
        ],
      );
      await db.query(
        'UPDATE source_runs SET status=$5,finished_at=now(),discovered=$2,updated=$3,error=$4 WHERE id=$1',
        [run, count, updated, message, errors.length ? 'partial' : 'success'],
      );
    } catch (e) {
      await lease.query(
        "UPDATE research_sources SET last_error=$2,failures=failures+1,next_run_at=now()+(LEAST(360,5*power(2,LEAST(failures,6))) * interval '1 minute') WHERE id=$1",
        [source.id, e.message.slice(0, 1000)],
      );
      await db.query(
        "UPDATE source_runs SET status='error',finished_at=now(),discovered=$2,updated=$3,error=$4 WHERE id=$1",
        [run, count, updated, e.message.slice(0, 1000)],
      );
    }
  });
}
