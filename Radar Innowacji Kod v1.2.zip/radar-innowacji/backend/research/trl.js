import { trlRules } from './trl-rules.js';
import { minimumTrl } from './trl-minimum.js';
const technology =
  /technolog|prototyp|urządzeni|czujnik|robot|oprogramowan|aplikacj|algorytm|materiał|platforma cyfrow|system informatycz/i;
// Conservative clause filtering: planned, negated and hypothetical results are not evidence.
const uncertain =
  /planuj|docelow|zamierz|będzie|będą|zostanie|zostaną|osiągnie|w przyszłości|wymagany (?:poziom )?TRL|docelowy poziom|co najmniej|celem jest|zakłada się|planowan|powinien|powinna|ma osiągnąć|może osiągnąć|\bnie (?:osiąg|wdroż|przetest|potwierdz|wykaz|zweryfik|opracow|zademonstrow|zosta|jest|przeprowadz)|brak (?:test|potwierdz|dowod)|\bnie udało/i;
const roman = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9 };
export function assessTrl(record, category = record.category) {
  const text = [record.title, record.intro, record.text].filter(Boolean).join('\n');
  const applicable = category === 'Technologiczny' || technology.test(text);
  const eligible = text
    .split(/(?<=[.!?;])\s+|\n|,\s+(?:ale|a|natomiast)\s+/)
    .filter((s) => !uncertain.test(s));
  const declarations = [];
  for (const sentence of eligible) {
    // Do not turn ranges, targets or scale descriptions into a single declared level.
    if (
      /od\s+(?:TRL\s*)?[1-9].*do\s+(?:TRL\s*)?[1-9]|skala|poziomy|poziomach|zakres TRL|wzrost.*TRL/i.test(
        sentence,
      )
    )
      continue;
    const matches = [
      ...sentence.matchAll(
        /\b(?:TRL|poziom gotowości technologicznej)\s*(?:na poziomie|poziom|level|wynosi|[:=–-])?\s*(IX|VIII|VII|VI|IV|V|III|II|I|[1-9])(?![\d.,]\d)\b(?:\s*[–-]\s*(?:TRL\s*)?(IX|VIII|VII|VI|IV|V|III|II|I|[1-9])\b)?/gi,
      ),
    ];
    for (const m of matches)
      if (!m[2]) declarations.push({ value: roman[m[1].toUpperCase()] || +m[1], sentence });
  }
  const levels = [...new Set(declarations.map((d) => d.value))];
  if (levels.length === 1)
    return result(
      levels[0],
      'source',
      declarations[0].sentence,
      'Poziom zadeklarowany w źródle; nie jest niezależnym audytem.',
    );
  if (levels.length > 1)
    return result(
      null,
      'unknown',
      declarations.map((d) => d.sentence).join(' '),
      'Źródło wymienia różne poziomy TRL. Wymagana weryfikacja, który dotyczy aktualnej wersji rozwiązania.',
    );
  if (applicable)
    for (const [value, pattern] of trlRules) {
      const evidence = eligible.find((s) => pattern.test(s));
      if (evidence)
        return result(
          value,
          'estimate',
          evidence,
          'Oszacowanie na podstawie opisu osiągniętego etapu; wymaga potwierdzenia eksperta.',
        );
    }
  const minimum = applicable ? minimumTrl(eligible) : null;
  if (minimum) return { ...minimum, trlVersion: 7 };
  return result(
    null,
    applicable ? 'unknown' : 'not_applicable',
    '',
    applicable
      ? 'TRL wymaga ustalenia: źródło nie zawiera wystarczających dowodów osiągniętego poziomu. Potrzebne są wyniki testów i opis środowiska walidacji.'
      : 'TRL nie dotyczy opisanego rozwiązania nietechnologicznego. Sprawdź etap i rezultaty wdrożenia.',
  );
}
function result(trl, trlKind, evidence, trlNote) {
  return {
    trl,
    trlMin: null,
    trlKind,
    trlEvidence: evidence.slice(0, 600),
    trlNote,
    trlVersion: 7,
  };
}
