export function minimumTrl(sentences) {
  for (const s of sentences) {
    if (
      /(?:zbudowano|opracowano|wykonano|powstał).*(?:działający|funkcjonalny) prototyp|demonstracja działania (?:robota|urządzenia|prototypu)|prototyp.*(?:potwierdzono|wykazano).*badani/i.test(
        s,
      )
    )
      return {
        trl: null,
        trlMin: 3,
        trlKind: 'lower_bound',
        trlEvidence: s.slice(0, 600),
        trlNote:
          'Opis wskazuje demonstrację działania lub funkcjonalny prototyp. Co najmniej TRL 3; bez informacji o środowisku testów nie można ustalić wyższego poziomu.',
      };
  }
  for (const s of sentences) {
    if (
      /(?:opracowan[ayeo]|opracowano|opracował[ao]?|zaprojektowano|stworzono)\s+(?:(?:now[ąaey]|zintegrowan[ąaey]|innowacyjn[ąaey])\s+){0,2}(?:technologi|czujnik|urządzeni|algorytm|oprogramowan|robot|moduł)|(?:technologia|czujnik|urządzenie|algorytm|oprogramowanie)\s+(?:został[ao]?\s+)?(?:opracowan|zaprojektowan)/i.test(
        s,
      )
    )
      return {
        trl: null,
        trlMin: 2,
        trlKind: 'lower_bound',
        trlEvidence: s.slice(0, 600),
        trlNote:
          'Potwierdzono opracowanie rozwiązania, więc istnieje koncepcja technologiczna (co najmniej TRL 2). Nie ma dostatecznych dowodów, by określić pełny poziom testów lub wdrożenia.',
      };
  }
  return null;
}
