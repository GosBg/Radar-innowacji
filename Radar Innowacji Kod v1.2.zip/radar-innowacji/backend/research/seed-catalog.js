import { readFile } from 'node:fs/promises';
import { recoverCatalog } from './recover-catalog.js';
export async function seedCatalog(db) {
  if ((await db.query("SELECT 1 FROM catalog_bootstrap WHERE id='public-v1'")).rows.length) return;
  const data = JSON.parse(await readFile(new URL('../data/catalog.json', import.meta.url), 'utf8'));
  const result = await recoverCatalog(db, data);
  await db.query("INSERT INTO catalog_bootstrap(id) VALUES('public-v1') ON CONFLICT DO NOTHING");
  return result;
}
