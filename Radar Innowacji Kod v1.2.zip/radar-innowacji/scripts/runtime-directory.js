import path from 'node:path';
import os from 'node:os';
import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
export async function resolveRuntime(projectRoot, env = process.env) {
  if (env.DATA_DIR) return path.resolve(projectRoot, env.DATA_DIR);
  // Documents is stable even when Windows virtualizes LOCALAPPDATA for a sandbox.
  const home = env.RADAR_HOME || path.join(os.homedir(), 'Documents', 'Codex', 'RadarInnowacji');
  const pointer = path.join(home, 'runtime.json');
  let saved;
  try {
    saved = JSON.parse(await readFile(pointer, 'utf8'));
  } catch (e) {
    if (e.code !== 'ENOENT')
      throw new Error('Nie można odczytać stałej lokalizacji bazy. Sprawdź ' + pointer);
  }
  if (saved?.directory) {
    await access(path.join(saved.directory, 'postgres-password')).catch(() => {
      throw new Error(
        'Zapisana baza jest niedostępna: ' +
          saved.directory +
          '. Nie utworzono pustej bazy zastępczej.',
      );
    });
    return saved.directory;
  }
  const legacy = path.join(projectRoot, '.runtime');
  const exists = await access(path.join(legacy, 'postgres-password'))
    .then(() => true)
    .catch(() => false);
  const directory = exists ? legacy : path.join(home, 'data');
  await mkdir(home, { recursive: true });
  await mkdir(directory, { recursive: true });
  await writeFile(pointer, JSON.stringify({ directory }, null, 2), { flag: 'wx' }).catch(
    async (e) => {
      if (e.code !== 'EEXIST') throw e;
    },
  );
  const chosen = JSON.parse(await readFile(pointer, 'utf8'));
  return chosen.directory;
}
