import pg from 'pg';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { recoverCatalog } from '../backend/research/recover-catalog.js';
const directory = process.env.DATA_DIR;
if (!directory || !process.argv[2])
  throw new Error('Podaj DATA_DIR istniejącej bazy i ścieżkę migawki katalogu.');
const pool = new pg.Pool({
  host: '127.0.0.1',
  port: Number(process.env.LOCAL_PG_PORT || 55432),
  user: 'radar',
  database: 'radar',
  password: (await readFile(path.join(directory, 'postgres-password'), 'utf8')).trim(),
});
const db = {
  query: (...args) => pool.query(...args),
  transaction: async (fn) => {
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      const r = await fn(c);
      await c.query('COMMIT');
      return r;
    } catch (e) {
      await c.query('ROLLBACK');
      throw e;
    } finally {
      c.release();
    }
  },
};
try {
  const backup = {};
  for (const table of ['innovations', 'evidence', 'research_sources'])
    backup[table] = (await db.query('SELECT * FROM ' + table)).rows;
  await writeFile(
    path.join(directory, 'catalog-before-recovery-' + Date.now() + '.json'),
    JSON.stringify(backup),
    { flag: 'wx' },
  );
  console.log(await recoverCatalog(db, JSON.parse(await readFile(process.argv[2], 'utf8'))));
} finally {
  await pool.end();
}
