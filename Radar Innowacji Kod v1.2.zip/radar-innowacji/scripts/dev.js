import 'dotenv/config';
import { fileURLToPath } from 'node:url';
import { resolveRuntime } from './runtime-directory.js';
import { mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import EmbeddedPostgres from './local-postgres.js';

// This starts native PostgreSQL, not an emulation or an in-browser database.
if (!process.env.PORT) {
  const occupied = await new Promise((resolve) => {
    const socket = net.connect(3000, '127.0.0.1');
    socket.once('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.once('error', () => resolve(false));
  });
  if (occupied) {
    process.env.PORT = '3001';
    process.env.APP_ORIGIN = 'http://localhost:3001';
    console.log('Port 3000 jest zajęty — nowa wersja uruchamia się na http://localhost:3001');
  }
}
let postgres;
const children = [];
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const runtime = await resolveRuntime(projectRoot);
process.env.DATA_DIR = runtime;
console.log(`Stała lokalizacja danych: ${runtime}`);
await mkdir(runtime, { recursive: true });
if (!process.env.DATABASE_URL) {
  const passwordFile = path.join(runtime, 'postgres-password');
  let password = await readFile(passwordFile, 'utf8').catch(() => '');
  if (!password) {
    password = randomBytes(32).toString('hex');
    await writeFile(passwordFile, password, { mode: 0o600 });
  }
  const port = Number(process.env.LOCAL_PG_PORT || 55432);
  const databaseDir = path.join(runtime, 'postgres-native');
  postgres = new EmbeddedPostgres({
    databaseDir,
    user: 'radar',
    password,
    port,
    persistent: true,
    authMethod: 'scram-sha-256',
    initdbFlags: ['--encoding=UTF8', '--locale=C'],
    postgresFlags: ['-h', '127.0.0.1'],
    onLog: (message) => {
      if (/FATAL|ERROR|PANIC/.test(message)) console.error(message);
    },
    onError: console.error,
  });
  if (
    !(await access(path.join(databaseDir, 'PG_VERSION'))
      .then(() => true)
      .catch(() => false))
  )
    await postgres.initialise();
  await postgres.start();
  const client = postgres.getPgClient();
  await client.connect();
  if (!(await client.query("SELECT 1 FROM pg_database WHERE datname='radar'")).rows.length)
    await client.query(
      "CREATE DATABASE radar TEMPLATE template0 ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C'",
    );
  await client.end();
  process.env.DATABASE_URL = `postgresql://radar:${password}@127.0.0.1:${port}/radar`;
  console.log(`PostgreSQL uruchomiony lokalnie na porcie ${port}.`);
}
let stopping = false;
async function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  for (const child of children) child.kill();
  await new Promise((resolve) => setTimeout(resolve, 1200));
  await postgres?.stop();
  process.exit(code);
}
function launch(entry, onReady) {
  const child = spawn(process.execPath, [entry], {
    stdio: ['inherit', 'inherit', 'inherit', 'ipc'],
    env: process.env,
    windowsHide: true,
  });
  children.push(child);
  if (onReady)
    child.once('message', (message) => {
      if (message === 'ready' && !stopping) onReady();
    });
  child.on('exit', (code) => {
    if (!stopping) stop(code || 0);
  });
}
// Finish server migrations before the worker can acquire its batch lease.
launch('backend/server.js', () => launch('backend/worker.js'));
process.on('SIGINT', () => stop());
process.on('SIGTERM', () => stop());
