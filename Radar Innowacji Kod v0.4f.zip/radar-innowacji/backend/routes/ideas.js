import { Router } from 'express';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import { requireUser, requireRole, audit } from '../lib/policy.js';
import { ideaSelect, projectIdeas } from '../services/projections.js';
import { times } from '../../frontend/data/constants.js';

const filtersSchema = z.object({
  query: z.string().max(200).default(''),
  category: z.string().max(80).default('Wszystkie'),
  author: z.string().max(80).default('all'),
  stage: z.string().max(80).default(''),
  source: z.string().max(120).default(''),
  region: z.string().max(80).default(''),
  age: z.number().int().min(0).max(13).default(13),
  days: z
    .tuple([
      z.union([z.literal(''), z.coerce.number().min(0).max(730)]),
      z.union([z.literal(''), z.coerce.number().min(0).max(730)]),
    ])
    .default(['', '']),
  bounds: z
    .array(
      z.tuple([
        z.union([z.literal(''), z.coerce.number().min(0.5).max(5)]),
        z.union([z.literal(''), z.coerce.number().min(0.5).max(5)]),
      ]),
    )
    .length(4)
    .default([
      ['', ''],
      ['', ''],
      ['', ''],
      ['', ''],
    ]),
  sort: z.enum(['new', 'rating']).default('new'),
  period: z.enum(['all', '1', '7', '30', '365']).default('all'),
  ranking: z.enum(['publication', 'votes']).default('publication'),
});
export async function visibleIdea(db, req, id) {
  z.string().uuid().parse(id);
  const row = (await db.query(`${ideaSelect} WHERE i.id=$1`, [id])).rows[0];
  ensure(row, 404, 'Nie znaleziono innowacji.');
  ensure(
    row.status === 'published' ||
      row.owner_id === req.user?.id ||
      req.user?.role === 'admin' ||
      (req.user?.role === 'moderator' && row.status === 'pending'),
    403,
    'Ta innowacja nie jest publiczna.',
  );
  return row;
}
export function ideaRoutes({ db }) {
  const router = Router();
  router.get(
    '/',
    route(async (req, res) => {
      let raw = {};
      try {
        raw = JSON.parse(req.query.filters || '{}');
      } catch {
        ensure(false, 400, 'Nieprawidłowe filtry.');
      }
      const f = filtersSchema.parse(raw),
        page = z.coerce
          .number()
          .int()
          .min(1)
          .max(10000)
          .parse(req.query.page || 1),
        limit = 12;
      const values = [],
        where = ["i.status='published' AND i.owner_id IS NULL"];
      const arg = (value) => {
        values.push(value);
        return `$${values.length}`;
      };
      if (req.query.scope === 'moderation') {
        requireRole(req, 'admin', 'moderator');
        where[0] = 'i.owner_id IS NULL';
      } else {
        if (req.query.favorites === 'true') {
          requireUser(req);
          where.push(
            `EXISTS(SELECT 1 FROM favorites v WHERE v.innovation_id=i.id AND v.user_id=${arg(req.user.id)})`,
          );
        }
        if (f.query)
          where.push(
            `(i.title ILIKE ${arg('%' + f.query + '%')} OR i.description ILIKE $${values.length} OR i.creator ILIKE $${values.length} OR i.problem ILIKE $${values.length} OR i.application ILIKE $${values.length})`,
          );
        if (f.category !== 'Wszystkie') where.push(`i.category=${arg(f.category)}`);
        if (f.author !== 'all') where.push(`i.creator_type=${arg(f.author)}`);
        if (f.stage) where.push(`i.stage=${arg(f.stage)}`);
        if (f.source)
          where.push(
            `EXISTS(SELECT 1 FROM evidence e JOIN research_sources s ON s.id=e.source_id WHERE e.innovation_id=i.id AND s.name ILIKE ${arg('%' + f.source + '%')})`,
          );
        if (f.region) where.push(`i.region=${arg(f.region)}`);
        const lower = f.days[0] === '' ? 0 : +f.days[0],
          upper = f.days[1] === '' ? Math.max(times[f.age][1], 1 / 24) : +f.days[1];
        ensure(lower <= upper, 400, 'Nieprawidłowy przedział dni.');
        where.push(
          `i.published_at BETWEEN now()-(${arg(upper)}::float * interval '1 day') AND now()-(${arg(lower)}::float * interval '1 day')`,
        );
        if (f.period !== 'all' && f.ranking === 'publication')
          where.push(`i.published_at>=now()-(${arg(+f.period)}::float * interval '1 day')`);
        if (f.period !== 'all' && f.ranking === 'votes')
          where.push(
            `EXISTS(SELECT 1 FROM ratings WHERE innovation_id=i.id AND updated_at>=now()-(${arg(+f.period)}::float * interval '1 day'))`,
          );
        f.bounds.forEach(([min, max], index) => {
          ensure(min === '' || max === '' || +min <= +max, 400, 'Nieprawidłowy zakres ocen.');
          if (min !== '' || max !== '')
            where.push(
              `(SELECT avg(value) FROM ratings WHERE innovation_id=i.id AND category=${index}) BETWEEN ${arg(min === '' ? 0.5 : +min)} AND ${arg(max === '' ? 5 : +max)}`,
            );
        });
      }
      const count = await db.query(
        `SELECT count(*)::int AS total FROM innovations i WHERE ${where.join(' AND ')}`,
        values,
      );
      let score = '(SELECT avg(value) FROM ratings WHERE innovation_id=i.id)';
      if (f.ranking === 'votes' && f.period !== 'all')
        score = `(SELECT avg(value) FROM ratings WHERE innovation_id=i.id AND updated_at>=now()-(${arg(+f.period)}::float * interval '1 day'))`;
      const order =
        f.sort === 'rating'
          ? `${score} DESC NULLS LAST,i.published_at DESC NULLS LAST`
          : 'i.created_at DESC';
      const rows = await db.query(
        `${ideaSelect} WHERE ${where.join(' AND ')} ORDER BY ${order},i.id LIMIT ${limit} OFFSET ${arg((page - 1) * limit)}`,
        values,
      );
      res.json({
        items: await projectIdeas(db, rows.rows, req.user?.id),
        total: count.rows[0].total,
        page,
        limit,
      });
    }),
  );
  router.get(
    '/:id',
    route(async (req, res) =>
      res.json(
        (await projectIdeas(db, [await visibleIdea(db, req, req.params.id)], req.user?.id))[0],
      ),
    ),
  );
  router.patch(
    '/:id/moderation',
    route(async (req, res) => {
      const user = requireRole(req, 'admin', 'moderator');
      const input = z
        .object({
          action: z.enum(['approve', 'reject', 'archive']),
          reason: z.string().trim().max(2000).default(''),
        })
        .parse(req.body);
      if (input.action === 'archive') requireRole(req, 'admin');
      const row = await visibleIdea(db, req, req.params.id);

      if (input.action === 'reject')
        ensure(input.reason.length >= 5, 400, 'Podaj powód odrzucenia.');
      await db.query(
        "UPDATE innovations SET status=$2,published_at=CASE WHEN $2='published' THEN COALESCE(published_at,now()) ELSE published_at END,rejection_reason=$3 WHERE id=$1",
        [
          row.id,
          { approve: 'published', reject: 'rejected', archive: 'archived' }[input.action],
          input.reason || null,
        ],
      );
      await audit(db, user, `idea.${input.action}`, row.id, { reason: input.reason });
      res.json({ ok: true });
    }),
  );
  router.delete(
    '/:id',
    route(async (req, res) => {
      const user = requireUser(req),
        row = await visibleIdea(db, req, req.params.id);
      ensure(user.role === 'admin', 403, 'Tylko autor lub administrator może usunąć innowację.');
      await db.transaction(async (tx) => {
        await tx.query(
          'INSERT INTO ignored_source_urls(url) SELECT url FROM evidence WHERE innovation_id=$1 ON CONFLICT DO NOTHING',
          [row.id],
        );
        await tx.query('DELETE FROM innovations WHERE id=$1', [row.id]);
      });
      await audit(db, user, 'idea.delete', row.id);
      res.json({ ok: true });
    }),
  );
  router.put(
    '/:id/rating',
    route(async (req, res) => {
      const user = requireUser(req),
        row = await visibleIdea(db, req, req.params.id);
      ensure(row.status === 'published', 403, 'Ocena wymaga publikacji.');
      const { category, value } = z
        .object({
          category: z.number().int().min(0).max(3),
          value: z.number().min(0.5).max(5).multipleOf(0.5),
        })
        .parse(req.body);
      await db.query(
        'INSERT INTO ratings(innovation_id,user_id,category,value) VALUES($1,$2,$3,$4) ON CONFLICT(innovation_id,user_id,category) DO UPDATE SET value=EXCLUDED.value,updated_at=now()',
        [row.id, user.id, category, value],
      );
      res.json((await projectIdeas(db, [row], user.id))[0]);
    }),
  );
  router.put(
    '/:id/favorite',
    route(async (req, res) => {
      const user = requireUser(req),
        row = await visibleIdea(db, req, req.params.id);
      ensure(row.status === 'published', 403, 'Zapisz opublikowany pomysł.');
      const { active } = z.object({ active: z.boolean() }).parse(req.body);
      if (active)
        await db.query('INSERT INTO favorites VALUES($1,$2) ON CONFLICT DO NOTHING', [
          user.id,
          row.id,
        ]);
      else
        await db.query('DELETE FROM favorites WHERE user_id=$1 AND innovation_id=$2', [
          user.id,
          row.id,
        ]);
      res.json({ ok: true });
    }),
  );
  return router;
}
