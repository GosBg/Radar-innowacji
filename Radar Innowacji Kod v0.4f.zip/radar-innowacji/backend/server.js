import express from 'express';
import path from 'node:path';
import { configuration } from './config.js';
import { encryption } from './lib/crypto.js';
import { connectDatabase } from './db/connection.js';
import { seed } from './db/seed.js';
import { createApp } from './app.js';
import { applyRetention } from './services/retention.js';

const config = configuration(),
  crypto = await encryption(config),
  db = await connectDatabase(config);
await seed(db, config, crypto);
if (
  config.production &&
  (await db.query('SELECT 1 FROM users WHERE example=true LIMIT 1')).rows.length
)
  throw new Error('Baza przykładowa nie może być bazą produkcyjną. Użyj oddzielnej pustej bazy.');
const app = createApp({ db, config, crypto });
let vite;
if (!config.production) {
  const { createServer } = await import('vite');
  vite = await createServer({
    server: {
      middlewareMode: true,
      hmr: { port: Number(process.env.HMR_PORT || 24679) },
      fs: {
        strict: true,
        allow: [path.resolve('frontend'), path.resolve('node_modules'), path.resolve('index.html')],
        deny: [
          '**/.env',
          '**/.env.*',
          '**/*.{crt,pem,key}',
          '**/.git/**',
          '**/.runtime/**',
          '**/backend/**',
          '**/tests/**',
          `${config.dataDir.replaceAll('\\', '/')}/**`,
        ],
      },
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve('dist')));
  app.get('/{*path}', (req, res) => res.sendFile(path.resolve('dist/index.html')));
}
await applyRetention(db, config);
const timer = setInterval(() => applyRetention(db, config).catch(console.error), 3600000);
timer.unref();
const server = app.listen(config.port, config.host, (error) => {
  if (error) {
    console.error('Nie można uruchomić serwera:', error.message);
    process.exit(1);
  }
  console.log(
    `Radar innowacji BETA: ${config.origin}\nBaza: ${db.engine}\n${config.examples ? 'Profil przykładowy administratora: admin / admin' : ''}`,
  );
});
async function shutdown() {
  clearInterval(timer);
  server.close();
  await vite?.close();
  await db.close();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
