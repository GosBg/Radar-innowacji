import { timingSafeEqual } from 'node:crypto';
import { token, digest } from '../lib/crypto.js';
import { ensure } from '../lib/errors.js';

export function sessionService(db, config) {
  const cookieName = config.production ? '__Host-radar' : 'radar_session';
  const options = {
    httpOnly: true,
    secure: config.production,
    sameSite: 'strict',
    path: '/',
    maxAge: config.sessionHours * 3600000,
  };
  const csrfFor = (sessionToken) => digest(`radar-csrf:${sessionToken}`);
  async function create(res, userId = null, previous = null) {
    if (previous) await db.query('DELETE FROM sessions WHERE token_hash=$1', [previous]);
    const sessionToken = token(),
      csrf = csrfFor(sessionToken);
    await db.query(
      'INSERT INTO sessions(token_hash,user_id,csrf_hash,expires_at) VALUES($1,$2,$3,$4)',
      [digest(sessionToken), userId, digest(csrf), new Date(Date.now() + options.maxAge)],
    );
    res.cookie(cookieName, sessionToken, options);
    // Login rotates the session. Ordinary tab openings share the same CSRF secret.
    return csrf;
  }
  return {
    create,
    async current(req, res) {
      if (!req.session) return create(res);
      const csrf = csrfFor(req.cookies[cookieName]);
      await db.query('UPDATE sessions SET csrf_hash=$2 WHERE token_hash=$1', [
        req.session.token_hash,
        digest(csrf),
      ]);
      return csrf;
    },
    cookieName,
    options,
    load: async (req, res, next) => {
      try {
        const cookie = req.cookies[cookieName];
        if (cookie) {
          const result = await db.query(
            'SELECT s.*,row_to_json(u) AS account FROM sessions s LEFT JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()',
            [digest(cookie)],
          );
          req.session = result.rows[0];
          req.user = req.session?.account || null;
        }
        next();
      } catch (error) {
        next(error);
      }
    },
    csrf: (req, res, next) => {
      try {
        if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
        const origin = req.get('origin');
        ensure(origin === config.origin, 403, 'Nieprawidłowe pochodzenie żądania.');
        const provided = req.get('x-csrf-token');
        ensure(
          req.session && typeof provided === 'string' && provided.length < 200,
          403,
          'Odśwież sesję i spróbuj ponownie.',
        );
        const expected = Buffer.from(req.session.csrf_hash),
          actual = Buffer.from(digest(provided));
        ensure(
          expected.length === actual.length && timingSafeEqual(expected, actual),
          403,
          'Nieprawidłowy token CSRF.',
        );
        next();
      } catch (error) {
        next(error);
      }
    },
  };
}
