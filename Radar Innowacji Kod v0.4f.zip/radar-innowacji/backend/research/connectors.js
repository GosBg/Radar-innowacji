import { load } from 'cheerio';
import { sourceFetcher } from './fetch.js';
const clean = (value) => value.replace(/\s+/g, ' ').trim();
export async function discover(source, fetchPage) {
  const html = await fetchPage(source.url);
  if (source.connector === 'rss') {
    const $ = load(html, { xmlMode: true });
    return [
      ...new Set(
        $('item, entry')
          .map((_, e) => $(e).find('link').first().attr('href') || $(e).find('link').first().text())
          .get(),
      ),
    ];
  }
  const $ = load(html);
  const selector =
    source.connector === 'ncbr' ? 'main a' : source.config.linkSelector || 'article a';
  return [
    ...new Set(
      $(selector)
        .filter(
          (_, e) => source.connector !== 'ncbr' || clean($(e).text()) === 'Dowiedz się więcej',
        )
        .map((_, e) => {
          try {
            const u = new URL($(e).attr('href'), source.url);
            u.hash = '';
            return u.origin === new URL(source.url).origin ? u.href : null;
          } catch {
            return null;
          }
        })
        .get()
        .filter(Boolean),
    ),
  ].slice(0, 2000);
}
export function extract(html, url, source) {
  const $ = load(html);
  $('script,style,nav,footer,form').remove();
  const area = $(source.config.contentSelector || 'article').first();
  const title = clean(area.find('h1,h2').first().text() || $('main h1').first().text());
  const lines = area
    .find('h2,h3,p,li')
    .map((_, e) => clean($(e).text()))
    .get()
    .filter(Boolean);
  const text = lines.join('\n').slice(0, 60000);
  if (title.length < 3 || text.length < 200)
    throw new Error('Za mało danych do utworzenia karty. Sprawdź selektory.');
  const after = (pattern) => {
    const i = lines.findIndex((x) => pattern.test(x));
    return i >= 0 ? lines[i + 1] || '' : '';
  };
  const dateValue =
    $('meta[property="article:published_time"]').attr('content') ||
    $('time[datetime]').first().attr('datetime');
  const date =
    dateValue && !isNaN(Date.parse(dateValue)) ? new Date(dateValue).toISOString() : null;
  return {
    url,
    title,
    text,
    creator: after(/Nazwa Beneficjenta/i) || 'Nie ustalono',
    problem: after(/Jaki problem rozwiązuje/i),
    application: after(/Kto korzysta|Kto skorzysta/i),
    date,
    intro:
      (clean($('.intro').text()) !== title ? clean($('.intro').text()) : '') ||
      after(/Jaki problem rozwiązuje/i) ||
      lines.find(
        (x) => x.length > 120 && /rozwiązan|technolog|projekt|system|opracowan/i.test(x),
      ) ||
      text.slice(0, 400),
  };
}
export async function testSource(source) {
  const fetchPage = await sourceFetcher(source);
  const links = await discover(source, fetchPage);
  if (!links.length)
    throw new Error('Nie znaleziono odnośników. Sprawdź konektor i selektor linków.');
  const record = extract(await fetchPage(links[0]), links[0], source);
  return {
    links: links.length,
    sample: { title: record.title, url: record.url, creator: record.creator },
  };
}
