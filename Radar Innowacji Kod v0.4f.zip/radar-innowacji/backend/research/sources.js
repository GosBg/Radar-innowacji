import { randomUUID } from 'node:crypto';
const presets = [
  [
    'NCBR — sukcesy beneficjentów',
    'https://www.gov.pl/web/ncbr/wyszukiwarka-sukcesow-beneficjentow',
    'ncbr',
    true,
  ],
  ['Interreg — projekty', 'https://interreg.gov.pl/lista-projektow/', 'pending', false],
  [
    'UPRP — patenty',
    'https://ewyszukiwarka.pue.uprp.gov.pl/search/simple-search',
    'pending',
    false,
  ],
  ['EPO — rejestr', 'https://register.epo.org/regviewer', 'pending', false],
  ['Polska Bibliografia Naukowa', 'https://pbn.nauka.gov.pl/core/#/home', 'pending', false],
  ['Polska Platforma Medyczna', 'https://ppm.edu.pl/index.seam', 'pending', false],
  ['PAN — czasopisma', 'https://www.czasopisma.pan.pl/dlibra', 'pending', false],
  ['BazTol', 'https://baztol.library.put.poznan.pl/baztol_czytelnik/baztol', 'pending', false],
  ['CORDIS', 'https://cordis.europa.eu/', 'pending', false],
];
export async function seedSources(db) {
  for (const [name, url, connector, enabled] of presets)
    await db.query(
      'INSERT INTO research_sources(id,name,url,connector,enabled) VALUES($1,$2,$3,$4,$5) ON CONFLICT(url) DO NOTHING',
      [randomUUID(), name, url, connector, enabled],
    );
}
