import React from 'react';
const date = (value) => (value ? new Date(value).toLocaleString('pl') : 'Nie ustalono');
export default function EvidencePanel({ idea }) {
  const a = idea.assessment || {};
  return (
    <section className="evidence-panel">
      <dl className="evidence-grid">
        <div>
          <dt>Twórca / beneficjent według źródła</dt>
          <dd>{idea.author}</dd>
        </div>
        <div>
          <dt>Rodzaj podmiotu</dt>
          <dd>{idea.creatorType}</dd>
        </div>
        <div>
          <dt>Etap rozwoju</dt>
          <dd>{idea.stage}</dd>
        </div>
        <div>
          <dt>TRL</dt>
          <dd>
            {a.trl || '—'} · {a.trlNote}
          </dd>
        </div>
      </dl>
      <h3>Problem i zastosowanie</h3>
      <p>{idea.problem || 'Brak wyodrębnionego opisu problemu w źródle.'}</p>
      <p>{idea.application || 'Zastosowania wymagają potwierdzenia u twórcy.'}</p>
      <h3>Podstawa klasyfikacji</h3>
      <p>
        <b>{a.method}</b> · {a.confidence}
      </p>
      {a.stageEvidence && <blockquote>{a.stageEvidence}</blockquote>}
      <p className="muted">{a.caveat}</p>
      <p className="muted">{a.ip}</p>
      <h3>Źródła i aktualność</h3>
      {idea.sources?.map((s) => (
        <div className="source-evidence" key={s.url}>
          <a href={s.url} target="_blank" rel="noopener noreferrer">
            {s.name} — {s.title} ↗
          </a>
          <p>{s.excerpt}</p>
          <small>
            Data źródła: {date(s.source_date)} · Odczyt: {date(s.fetched_at)}
          </small>
        </div>
      ))}
      <p className="muted">
        Odkryto: {date(idea.created)} · Ostatnia zmiana: {date(idea.changedAt)}. Data odczytu nie
        oznacza nowego wdrożenia.
      </p>
      <h3>Co dalej z rozwiązaniem?</h3>
      <p>{a.nextStep}</p>
      {!!idea.history?.length && (
        <details>
          <summary>Historia aktualizacji ({idea.history.length})</summary>
          <ul>
            {idea.history.map((h, i) => (
              <li key={i}>
                {date(h.changed_at)} — poprzedni etap: {h.stage}
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}
