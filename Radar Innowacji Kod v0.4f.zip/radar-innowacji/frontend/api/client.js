let csrf = '';
export class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}
export async function api(path, { method = 'GET', body, headers = {}, ...options } = {}) {
  const multipart = body instanceof FormData;
  const response = await fetch(`/api/v1${path}`, {
    ...options,
    method,
    credentials: 'same-origin',
    headers: {
      ...headers,
      ...(!multipart && body ? { 'Content-Type': 'application/json' } : {}),
      ...(method !== 'GET' ? { 'X-CSRF-Token': csrf } : {}),
    },
    body: body ? (multipart ? body : JSON.stringify(body)) : undefined,
  });
  const data = await response
    .json()
    .catch(() => ({ message: 'Serwer zwrócił nieprawidłową odpowiedź.' }));
  if (!response.ok)
    throw new ApiError(
      data.message || data.error || 'Operacja nie powiodła się.',
      response.status,
      data.details,
    );
  if (data.csrf) csrf = data.csrf;
  return data;
}
export async function upload(file, purpose = 'idea', registrationTicket) {
  const body = new FormData();
  body.append('file', file);
  return api(`/files/upload/${purpose}`, {
    method: 'POST',
    body,
    headers: registrationTicket ? { 'X-Registration-Token': registrationTicket } : {},
  });
}
