import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App.jsx';
import { RadarProvider } from './app/RadarContext.jsx';
import './styles/index.css';
import './styles/research.css';

createRoot(document.getElementById('root')).render(
  <RadarProvider>
    <App />
  </RadarProvider>,
);
