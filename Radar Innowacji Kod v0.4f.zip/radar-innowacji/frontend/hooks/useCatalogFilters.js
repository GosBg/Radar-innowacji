import { useState } from 'react';
import { createFilters, validateFilters } from '../domain/catalog.js';

export default function useCatalogFilters() {
  const [filters, setFilters] = useState(createFilters);
  const update = (key) => (value) =>
    setFilters((current) => ({
      ...current,
      [key]: typeof value === 'function' ? value(current[key]) : value,
    }));
  return {
    ...filters,
    values: filters,
    validationError: validateFilters(filters),
    setQuery: update('query'),
    setStage: update('stage'),
    setSource: update('source'),
    setCategory: update('category'),
    setAuthor: update('author'),
    setRegion: update('region'),
    setAge: update('age'),
    setDays: update('days'),
    setBounds: update('bounds'),
    setSort: update('sort'),
    setRanking: update('ranking'),
    setPeriod: (period) => setFilters((current) => ({ ...current, period, sort: 'rating' })),
    reset: () => setFilters(createFilters()),
  };
}
