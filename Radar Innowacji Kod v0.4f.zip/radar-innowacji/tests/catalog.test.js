import test from 'node:test';
import assert from 'node:assert/strict';
import { createFilters, filterInnovations, validateFilters } from '../frontend/domain/catalog.js';
import { DAY_MS } from '../frontend/data/constants.js';

const now = 1800000000000;
const make = (id, days, extra = {}) => ({
  id,
  created: now - days * DAY_MS,
  title: 'Sensor wody',
  description: 'Rehabilitacja i środowisko',
  author: 'Twórca',
  type: 'private',
  region: 'Podkarpackie',
  category: 'Zdrowie',
  status: 'published',
  ratings: [4, 4, 4, 4],
  votes: 1,
  ...extra,
});
const items = [
  make('fresh', 0.01),
  make('old', 4),
  make('pending', 0, { status: 'pending' }),
  make('archived', 0, { status: 'archived' }),
];

test('catalog never includes pending or archived innovations', () => {
  assert.deepEqual(
    filterInnovations(items, createFilters(), { now }).map((item) => item.id),
    ['fresh', 'old'],
  );
});

test('time filter, author, region, category and favorites compose', () => {
  const filters = {
    ...createFilters(),
    days: ['3', '5'],
    author: 'private',
    region: 'Podkarpackie',
    category: 'Zdrowie',
  };
  assert.deepEqual(
    filterInnovations(items, filters, { now, onlyFavorites: true, favorites: ['old'] }).map(
      (item) => item.id,
    ),
    ['old'],
  );
});

test('first time slider stop returns recent entries rather than an empty exact instant', () => {
  assert.equal(filterInnovations(items, { ...createFilters(), age: 0 }, { now }).length, 1);
});

test('invalid date or rating ranges produce a clear validation error', () => {
  assert.ok(validateFilters({ ...createFilters(), days: ['5', '1'] }));
  assert.ok(validateFilters({ ...createFilters(), days: ['-1', '5'] }));
  assert.ok(validateFilters({ ...createFilters(), bounds: [['4', '2']] }));
});

test('unrated entries do not match a minimum rating even when it is zero', () => {
  const unrated = make('unrated', 0, { votes: 0, ratings: [0, 0, 0, 0] });
  assert.equal(
    filterInnovations([unrated], { ...createFilters(), bounds: [['0', '']] }, { now }).length,
    0,
  );
});

test('TOP filters publication period and ranks the resulting innovations', () => {
  const top = make('top', 0.2, { ratings: [5, 5, 5, 5] });
  assert.deepEqual(
    filterInnovations(
      [...items, top],
      { ...createFilters(), period: '1', sort: 'rating' },
      { now },
    ).map((item) => item.id),
    ['top', 'fresh'],
  );
});
