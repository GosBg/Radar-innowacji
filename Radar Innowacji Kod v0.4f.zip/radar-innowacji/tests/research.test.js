import test from 'node:test';
import assert from 'node:assert/strict';
import { classify } from '../backend/research/classify.js';
import { extract } from '../backend/research/connectors.js';
import { validateUrl } from '../backend/research/fetch.js';
test('future and negative statements do not prove implementation or prototype', () => {
  const base = {
    title: 'Czujnik przemysłowy',
    intro: 'Nowe rozwiązanie',
    creator: 'Firma Testowa',
  };
  assert.equal(
    classify({
      ...base,
      text: 'Planujemy: zostanie wdrożono rozwiązanie. Nie opracowano prototypu.',
    }).stage,
    'Nie ustalono',
  );
  assert.equal(classify({ ...base, text: 'Opracowano prototyp czujnika.' }).stage, 'Prototyp');
  assert.equal(
    classify({ ...base, text: 'Rozwiązanie jest stosowane w fabryce.' }).stage,
    'W praktyce',
  );
  assert.equal(classify({ ...base, text: 'Brak danych.' }).assessment.trl, null);
});
test('education is recognized from the solution description, not the publisher', () => {
  const result = classify({
    title: 'Z Pythonem w przyszłość',
    intro: 'Bezpłatny kurs programowania.',
    text: 'Utworzono kurs online.',
    creator: 'Wyższa Szkoła Informatyki',
  });
  assert.equal(result.category, 'Edukacyjny');
  assert.equal(result.creatorType, 'Uczelnia');
  assert.equal(result.assessment.trl, null);
});
test('article title wins over portal headings and short solution names remain valid', () => {
  const html =
    '<header><h1>Portal instytucji</h1></header><main><article><h2>ABC</h2><p>Nazwa Beneficjenta</p><p>Instytut ABC</p><p>' +
    'Opis rozwiązania i jego zastosowań. '.repeat(20) +
    '</p></article></main>';
  const record = extract(html, 'https://example.org/abc', { config: {} });
  assert.equal(record.title, 'ABC');
  assert.equal(record.creator, 'Instytut ABC');
});
test('source URLs reject local IPs, credentials, alternate ports and non-HTTPS', () => {
  for (const url of [
    'http://example.org',
    'https://127.0.0.1',
    'https://[::1]',
    'https://user:pass@example.org',
    'https://example.org:8080',
    'https://localhost',
  ])
    assert.throws(() => validateUrl(url));
  assert.equal(validateUrl('https://example.org/path#anchor').href, 'https://example.org/path');
});
