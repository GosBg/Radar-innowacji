// TRL describes technological maturity, independently of the application domain.
export function assessTrl(record) {
  const sentences = (record.title + '\n' + record.text).split(/(?<=[.!?])\s+|\n/);
  const eligible = sentences.filter(
    (s) =>
      !/planuj|docelow|zamierz|będzie|zostanie|osiągnie|\bnie osiąg|\bnie wdroż|\bnie przetest/i.test(
        s,
      ),
  );
  for (const s of eligible) {
    const match = s.match(
      /\bTRL\s*(?:na poziomie|poziom|level|[:=-])?\s*([1-9])(?:\s*[–-]\s*([1-9]))?\b/i,
    );
    if (match && !match[2] && !/\bnie osiąg|docelow|planuj/i.test(s))
      return {
        trl: +match[1],
        trlKind: 'source',
        trlEvidence: s.slice(0, 600),
        trlNote: 'Poziom zadeklarowany w źródle; nie jest niezależnym audytem.',
      };
  }
  const technological =
    /technolog|prototyp|urządzeni|czujnik|robot|oprogramowan|aplikacj|algorytm|materiał|platforma cyfrow/i.test(
      record.title + ' ' + record.intro,
    );
  if (technological) {
    const rules = [
      [9, /system (?:jest|został) (?:stosowany|wdrożony) w warunkach operacyjnych/i],
      [7, /prototyp.*(?:przetestowano|zademonstrowano).*warunkach operacyjnych/i],
      [
        6,
        /prototyp.*(?:przetestowano|zademonstrowano).*warunkach (?:zbliżonych do rzeczywistych|reprezentatywnych)/i,
      ],
      [4, /(?:przetestowano|zweryfikowano|potwierdzono).*warunkach laboratoryjnych/i],
      [3, /(?:potwierdzono|wykazano).*koncepcj.*eksperymentaln/i],
    ];
    for (const [value, pattern] of rules) {
      const s = eligible.find((x) => pattern.test(x));
      if (s)
        return {
          trl: value,
          trlKind: 'estimate',
          trlEvidence: s.slice(0, 600),
          trlNote: 'Szacunek regułowy na podstawie opisanego testu. Wymaga weryfikacji eksperta.',
        };
    }
  }
  return {
    trl: null,
    trlKind: technological ? 'unknown' : 'not_applicable',
    trlEvidence: '',
    trlNote: technological
      ? 'Nie ustalono — źródło nie opisuje wystarczająco warunków walidacji technologii.'
      : 'Nie zastosowano TRL: opis nie wskazuje rozwiązania technologicznego. Oceniaj etap i rezultaty wdrożenia.',
  };
}
