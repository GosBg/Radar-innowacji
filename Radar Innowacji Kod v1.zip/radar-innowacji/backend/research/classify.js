import { assessTrl } from './trl.js';
// Conservative, deterministic baseline. Source text is data, never executable instructions.
export const CLASSIFIER_VERSION = 3;
export function classify(record) {
  const text = record.title + '\n' + record.text;
  const category =
    /edukac|kształcen|naucz|kompetencj|uczni|szkoł|studia doktoranckie|kurs|zajęcia/i.test(
      record.title + ' ' + record.intro,
    )
      ? 'Edukacyjny'
      : /administrac|samorząd|urząd|e-usług/i.test(record.title)
        ? 'Administracyjny'
        : 'Technologiczny';
  const sentences = text.split(/(?<=[.!?])\s+|\n/);
  const stageRules = [
    ['W praktyce', /został[aoey]? wdrożon|wdrożono|jest wykorzystywan|jest stosowan/i],
    ['Pilotaż', /przeprowadzono pilotaż|pilotażow[ae] wdrożeni/i],
    ['Testy', /przetestowano|przeprowadzono testy/i],
    ['Prototyp', /opracowano prototyp|demonstrator|zbudowano prototyp/i],
  ];
  let stage = 'Nie ustalono',
    stageEvidence = '';
  for (const [label, pattern] of stageRules) {
    const sentence = sentences.find(
      (s) =>
        pattern.test(s) &&
        !/planuj|zamierz|będzie|zostanie|nie opracowano|nie wdrożono|nie został/i.test(s),
    );
    if (sentence) {
      stage = label;
      stageEvidence = sentence.slice(0, 500);
      break;
    }
  }
  const creatorType = /uniwersytet|politechnika|uczelnia|wyższa szkoła|szkoła nauk|akademia/i.test(
    record.creator,
  )
    ? 'Uczelnia'
    : /instytut|centrum.*bad/i.test(record.creator)
      ? 'Instytut badawczy'
      : /sp\.|s\.a\.|spółka/i.test(record.creator)
        ? 'Firma'
        : /urząd|gmina|miasto/i.test(record.creator)
          ? 'Administracja'
          : 'Nie ustalono';
  return {
    category,
    stage,
    creatorType,
    assessment: {
      method: 'Reguły językowe v3',
      version: CLASSIFIER_VERSION,
      confidence: 'Wymaga potwierdzenia w źródle',
      stageEvidence,
      ...assessTrl(record),
      ip: 'Nie ustalono właściciela ani statusu ochrony IP. Polski beneficjent nie dowodzi polskiego IP.',
      nextStep:
        stage === 'W praktyce'
          ? 'Sugestia: sprawdź warunki zastosowania i wyniki wdrożenia u twórcy.'
          : 'Sugestia: potwierdź aktualny etap i dostępność demonstracji u podmiotu wskazanego w źródle.',
      caveat:
        'Klasyfikacja automatyczna opisu źródłowego. Nie dowodzi nowości patentowej ani braku podobnych rozwiązań.',
    },
  };
}
