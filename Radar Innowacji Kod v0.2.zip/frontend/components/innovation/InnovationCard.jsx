import React from 'react';
import { MapPin, Star } from 'lucide-react';
import InnovationArt from './InnovationArt.jsx';
import FavoriteButton from './FavoriteButton.jsx';
import Avatar from '../ui/Avatar.jsx';
import { formatRating } from '../../domain/ratings.js';

export default function InnovationCard({
  innovation,
  author,
  summary,
  favorite,
  onFavorite,
  onOpen,
}) {
  return (
    <article className="card">
      <button
        type="button"
        className="card-visual"
        aria-label={`Otwórz: ${innovation.title}`}
        onClick={onOpen}
      >
        <InnovationArt kind={innovation.art} />
        <span className="stage">{innovation.stage}</span>
      </button>
      <FavoriteButton selected={favorite} onToggle={onFavorite} />
      <div className="card-body">
        <div className="card-category">{innovation.category}</div>
        <button type="button" className="card-title" onClick={onOpen}>
          {innovation.title}
        </button>
        <p>{innovation.description}</p>
        <div className="author-row">
          <Avatar profile={author || { name: innovation.author, type: innovation.type }} />
          <div>
            <b>{innovation.author}</b>
            <small>
              <MapPin size={12} />
              {innovation.city}
            </small>
          </div>
        </div>
        <div className="card-bottom">
          <span className="score">
            <Star size={16} fill="currentColor" />
            <b>{formatRating(summary.overall)}</b>
            <small>({summary.voters} głosujących)</small>
          </span>
          <button type="button" onClick={onOpen}>
            Zobacz pomysł
          </button>
        </div>
      </div>
    </article>
  );
}
