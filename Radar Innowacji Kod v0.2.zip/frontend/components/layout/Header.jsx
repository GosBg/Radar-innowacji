import React, { useState } from 'react';
import { Radar, Menu, Heart, Mail, Plus } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import Avatar from '../ui/Avatar.jsx';
import Button from '../ui/Button.jsx';

const links = [
  { page: 'discover', label: 'Odkrywaj' },
  { page: 'favorites', label: 'Ulubione', icon: Heart },
  { page: 'messages', label: 'Wiadomości', icon: Mail },
  { page: 'future', label: 'Innowacje' },
];

export default function Header() {
  const { navigation, profile, favorites, setDialog, requestSubmission } = useRadar();
  const [menuOpen, setMenuOpen] = useState(false);
  const go = (page) => {
    navigation.go(page);
    setMenuOpen(false);
  };
  const openProfile = () => {
    setDialog({ type: profile ? 'profile' : 'login' });
    setMenuOpen(false);
  };
  return (
    <>
      <div className="demo-bar">
        HACKNATION 2026 <span>Demo lokalne · profile i rozmowy działają w tej przeglądarce</span>
      </div>
      <a className="skip-link" href="#main-content">
        Przejdź do treści
      </a>
      <header className="topbar">
        <button
          className="brand"
          onClick={() => go('discover')}
          aria-label="Radar innowacji — strona główna"
        >
          <span className="brand-icon">
            <Radar size={28} />
          </span>
          <span>
            radar<span className="brand-light">innowacji</span>
            <small>OD POMYSŁU DO MOŻLIWOŚCI</small>
          </span>
        </button>
        <Button
          variant="icon"
          className="mobile-menu"
          aria-label="Menu"
          aria-expanded={menuOpen}
          aria-controls="main-navigation"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <Menu />
        </Button>
        <nav id="main-navigation" aria-label="Główna nawigacja" className={menuOpen ? 'open' : ''}>
          {links.map(({ page, label, icon: Icon }) => (
            <button
              key={page}
              className={navigation.page === page ? 'active' : ''}
              aria-current={navigation.page === page ? 'page' : undefined}
              onClick={() => go(page)}
            >
              {Icon && <Icon size={17} />}
              {label}
              {page === 'favorites' && favorites.length > 0 && (
                <span className="count">{favorites.length}</span>
              )}
            </button>
          ))}
          <button className="mobile-profile" onClick={openProfile}>
            <Avatar profile={profile} />
            {profile ? 'Mój profil' : 'Wybierz profil demo'}
          </button>
        </nav>
        <div className="account">
          <button className="login" onClick={openProfile}>
            {profile ? (
              <>
                <Avatar profile={profile} />
                {profile.name.split(' ')[0]}
              </>
            ) : (
              'Profil demo'
            )}
          </button>
          <Button className="small" onClick={requestSubmission}>
            <Plus size={18} />
            Zgłoś pomysł
          </Button>
        </div>
      </header>
    </>
  );
}
