import React, { createContext, useContext, useState } from 'react';
import useDemoStorage from '../hooks/useDemoStorage.js';
import useToast from '../hooks/useToast.js';
import useNavigation from '../hooks/useNavigation.js';
import useInnovationActions from '../hooks/useInnovationActions.js';
import useProfileActions from '../hooks/useProfileActions.js';
import useConversationActions from '../hooks/useConversationActions.js';

const RadarContext = createContext(null);

export function RadarProvider({ children }) {
  const { state, update, storageError } = useDemoStorage();
  const toast = useToast();
  const navigation = useNavigation();
  const [dialog, setDialog] = useState(null);
  const [conversationId, setConversationId] = useState(null);
  const profile =
    state.profiles.find((candidate) => candidate.id === state.activeProfileId) ?? null;
  const dependencies = { state, update, profile, notify: toast.notify };
  const innovations = useInnovationActions(dependencies);
  const profiles = useProfileActions(dependencies);
  const conversations = useConversationActions(dependencies);

  function requestSubmission() {
    setDialog({ type: profile ? 'submit' : 'profile', create: true, next: 'submit' });
  }

  function openConversation(recipientId) {
    if (!profile) {
      setDialog({ type: 'login' });
      return;
    }
    const id = conversations.startConversation(recipientId);
    if (!id) {
      toast.notify('Rozmowę z innym autorem rozpoczyna firma lub instytucja.');
      return;
    }
    setConversationId(id);
    navigation.go('messages');
  }

  return (
    <RadarContext.Provider
      value={{
        state,
        profile,
        storageError,
        ...toast,
        navigation,
        dialog,
        setDialog,
        closeDialog: () => setDialog(null),
        conversationId,
        setConversationId,
        innovations,
        profiles,
        conversations,
        requestSubmission,
        openConversation,
        favorites: state.favorites[profile?.id ?? 'guest'] || [],
      }}
    >
      {children}
    </RadarContext.Provider>
  );
}

export function useRadar() {
  const context = useContext(RadarContext);
  if (!context) throw new Error('useRadar requires RadarProvider.');
  return context;
}
