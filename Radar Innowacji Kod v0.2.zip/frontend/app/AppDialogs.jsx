import React from 'react';
import { useRadar } from './RadarContext.jsx';
import ProfileDialog from '../features/profiles/ProfileDialog.jsx';
import LoginDialog from '../features/profiles/LoginDialog.jsx';
import SubmitIdeaDialog from '../features/innovations/SubmitIdeaDialog.jsx';
import IdeaDetailDialog from '../features/innovations/IdeaDetailDialog.jsx';
import DeleteIdeaDialog from '../features/moderation/DeleteIdeaDialog.jsx';
import HowItWorksDialog from '../features/help/HowItWorksDialog.jsx';

/** Exactly one modal at a time, so focus and Escape have a single owner. */
export default function AppDialogs() {
  const { dialog, closeDialog, setDialog, navigation } = useRadar();
  switch (dialog?.type) {
    case 'profile':
      return (
        <ProfileDialog
          key={dialog.create ? 'create' : 'edit'}
          create={dialog.create}
          onClose={closeDialog}
          onSaved={() => (dialog.next === 'submit' ? setDialog({ type: 'submit' }) : closeDialog())}
        />
      );
    case 'login':
      return <LoginDialog onClose={closeDialog} />;
    case 'submit':
      return <SubmitIdeaDialog onClose={closeDialog} />;
    case 'delete':
      return <DeleteIdeaDialog ideaId={dialog.ideaId} onClose={closeDialog} />;
    case 'how':
      return <HowItWorksDialog onClose={closeDialog} />;
    default:
      return navigation.ideaId ? (
        <IdeaDetailDialog ideaId={navigation.ideaId} onClose={navigation.closeIdea} />
      ) : null;
  }
}
