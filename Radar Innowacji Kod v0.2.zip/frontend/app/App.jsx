import React from 'react';
import { useRadar } from './RadarContext.jsx';
import Header from '../components/layout/Header.jsx';
import Footer from '../components/layout/Footer.jsx';
import Toast from '../components/ui/Toast.jsx';
import CatalogPage from '../features/catalog/CatalogPage.jsx';
import ModerationPage from '../features/moderation/ModerationPage.jsx';
import MessagesPage from '../features/messages/MessagesPage.jsx';
import MySubmissionsPage from '../features/innovations/MySubmissionsPage.jsx';
import DevelopmentPage from '../features/development/DevelopmentPage.jsx';
import AppDialogs from './AppDialogs.jsx';

function CurrentPage({ page }) {
  switch (page) {
    case 'favorites':
      return <CatalogPage key="favorites" onlyFavorites />;
    case 'messages':
      return <MessagesPage />;
    case 'mine':
      return <MySubmissionsPage />;
    case 'admin':
      return <ModerationPage />;
    case 'future':
      return <DevelopmentPage />;
    default:
      return <CatalogPage key="discover" />;
  }
}

export default function App() {
  const { navigation, storageError, toast, dismissToast } = useRadar();
  return (
    <>
      <Header />
      {storageError && (
        <div className="storage-error" role="alert">
          {storageError}
        </div>
      )}
      <CurrentPage page={navigation.page} />
      <Footer />
      <AppDialogs />
      <Toast message={toast} onDismiss={dismissToast} />
    </>
  );
}
