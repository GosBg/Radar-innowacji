import { criteria } from '../data/constants.js';

export function isRating(value) {
  return Number.isFinite(value) && value >= 0.5 && value <= 5 && Number.isInteger(value * 2);
}

/** One replaceable vote per profile, innovation and criterion. Empty is not zero. */
export function summarizeRatings(innovation, votes = {}) {
  const totals = criteria.map((_, index) => ({
    sum: (innovation.ratings[index] || 0) * innovation.votes,
    count: innovation.votes,
  }));
  const ballots = Object.values(votes[innovation.id] || {});
  for (const ballot of ballots) {
    ballot.forEach((value, index) => {
      if (isRating(value) && totals[index]) {
        totals[index].sum += value;
        totals[index].count += 1;
      }
    });
  }
  const sum = totals.reduce((total, category) => total + category.sum, 0);
  const count = totals.reduce((total, category) => total + category.count, 0);
  return {
    categories: totals.map(({ sum, count }) => (count ? sum / count : null)),
    overall: count ? sum / count : null,
    voters: innovation.votes + ballots.filter((ballot) => ballot.some(isRating)).length,
  };
}

export function formatRating(value) {
  return value == null
    ? 'Brak ocen'
    : value.toLocaleString('pl-PL', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
}

export function getRecommendation(summary) {
  const rated = summary.categories
    .map((value, index) => ({ value, index }))
    .filter((item) => item.value != null);
  if (!rated.length) return null;
  const best = Math.max(...rated.map((item) => item.value));
  return rated
    .filter((item) => item.value === best)
    .map((item) => criteria[item.index])
    .join(' / ');
}
