import { categories, stages, regions } from '../data/constants.js';

export function validateIdea({ title, description, category, stage }) {
  if (title.trim().length < 8 || title.length > 110) return 'Nazwa musi mieć od 8 do 110 znaków.';
  if (description.trim().length < 30 || description.length > 5000)
    return 'Opis musi mieć od 30 do 5000 znaków.';
  if (!categories.includes(category) || !stages.includes(stage))
    return 'Wybierz poprawny obszar i etap rozwoju.';
  return '';
}

export function validateProfile(profile) {
  if (!['private', 'company'].includes(profile.type)) return 'Wybierz rodzaj profilu.';
  if (profile.name.trim().length < 2 || profile.name.length > 90)
    return 'Podaj nazwę o długości od 2 do 90 znaków.';
  if (!profile.city.trim() || profile.city.length > 80)
    return 'Podaj miejscowość (maksymalnie 80 znaków).';
  if (!profile.affiliation.trim() || profile.affiliation.length > 100)
    return 'Uzupełnij status lub organizację.';
  if (!regions.includes(profile.region)) return 'Wybierz województwo z listy.';
  return '';
}

export function validateAvatar(file) {
  if (!['image/png', 'image/jpeg'].includes(file.type)) return 'Wybierz zdjęcie PNG lub JPG.';
  if (file.size > 1024 * 1024) return 'Zdjęcie może mieć maksymalnie 1 MB.';
  return '';
}
