import React from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import Avatar from '../../components/ui/Avatar.jsx';

export default function LoginDialog({ onClose }) {
  const { state, profiles, profile, setDialog } = useRadar();
  return (
    <Modal title="Wybierz profil demonstracyjny" onClose={onClose}>
      <p>
        Przełączaj role, aby przetestować zgłoszenia, indywidualne oceny i dwustronne rozmowy na tym
        urządzeniu.
      </p>
      <p className="notice">
        To nie jest logowanie do prawdziwego konta. Profile demo nie mają haseł i są dostępne
        każdemu użytkownikowi tej przeglądarki.
      </p>
      <div className="profile-list">
        {state.profiles.map((candidate) => (
          <button
            key={candidate.id}
            className="profile-option"
            aria-pressed={candidate.id === profile?.id}
            onClick={() => {
              profiles.switchProfile(candidate.id);
              onClose();
            }}
          >
            <Avatar profile={candidate} />
            <span>
              <b>{candidate.name}</b>
              <small>
                {candidate.type === 'company' ? 'Firma / instytucja' : 'Osoba prywatna'}
              </small>
            </span>
            {candidate.id === profile?.id && <span className="tag">Aktywny</span>}
          </button>
        ))}
      </div>
      <Button full onClick={() => setDialog({ type: 'profile', create: true })}>
        Utwórz nowy profil demo
      </Button>
    </Modal>
  );
}
