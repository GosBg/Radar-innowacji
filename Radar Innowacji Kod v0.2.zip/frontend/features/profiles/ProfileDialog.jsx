import React, { useState } from 'react';
import { User, Building2, LogOut } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { regions } from '../../data/constants.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import AvatarUpload from './AvatarUpload.jsx';

const emptyProfile = {
  name: '',
  city: '',
  region: 'Podkarpackie',
  affiliation: '',
  avatar: '',
  type: 'private',
};

export default function ProfileDialog({ create = false, onClose, onSaved }) {
  const { profile, profiles, setDialog, navigation } = useRadar();
  const [draft, setDraft] = useState(() =>
    !create && profile ? { ...profile } : { ...emptyProfile },
  );
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const change = (key) => (event) =>
    setDraft((current) => ({ ...current, [key]: event.target.value }));
  function submit(event) {
    event.preventDefault();
    const error = profiles.saveProfile(draft);
    setError(error);
    if (!error) onSaved();
  }
  return (
    <Modal title={draft.id ? 'Twój profil' : 'Dołącz do świata innowacji'} onClose={onClose}>
      <p>
        Profil demonstracyjny jest dostępny tylko w tej przeglądarce. Zmiany zapiszą się po
        zatwierdzeniu formularza.
      </p>
      <form onSubmit={submit}>
        <div className="account-types">
          {[
            ['private', User, 'Osoba prywatna', 'Zgłaszaj pomysły i odpowiadaj'],
            ['company', Building2, 'Firma / instytucja', 'Zgłaszaj i nawiązuj kontakty'],
          ].map(([type, Icon, label, description]) => (
            <button
              type="button"
              key={type}
              className={draft.type === type ? 'chosen' : ''}
              aria-pressed={draft.type === type}
              onClick={() => setDraft((current) => ({ ...current, type }))}
            >
              <Icon />
              <b>{label}</b>
              <small>{description}</small>
            </button>
          ))}
        </div>
        <label>
          {draft.type === 'private' ? 'Imię i nazwisko' : 'Nazwa firmy / instytucji'}
          <input
            name="name"
            value={draft.name}
            onChange={change('name')}
            required
            minLength={2}
            maxLength={90}
          />
        </label>
        <div className="two-fields">
          <label>
            Miejscowość
            <input
              name="city"
              value={draft.city}
              onChange={change('city')}
              required
              maxLength={80}
            />
          </label>
          <label>
            Województwo
            <select name="region" value={draft.region} onChange={change('region')}>
              {regions.map((region) => (
                <option key={region}>{region}</option>
              ))}
            </select>
          </label>
        </div>
        <label>
          {draft.type === 'private'
            ? 'Status / afiliacja (np. student, uczeń, pracownik)'
            : 'Reprezentowana organizacja'}
          <input
            name="affiliation"
            value={draft.affiliation}
            onChange={change('affiliation')}
            required
            maxLength={100}
          />
        </label>
        <AvatarUpload
          name={draft.name}
          value={draft.avatar}
          onChange={(avatar) => setDraft((current) => ({ ...current, avatar }))}
          onBusy={setUploading}
        />
        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}
        <Button type="submit" full disabled={uploading}>
          {uploading ? 'Wczytywanie zdjęcia…' : 'Zapisz profil demo'}
        </Button>
      </form>
      {profile && (
        <>
          <Button variant="outline" full onClick={() => setDialog({ type: 'login' })}>
            Przełącz profil demo
          </Button>
          <Button
            variant="outline"
            full
            onClick={() => {
              profiles.logout();
              onClose();
              navigation.go('discover');
            }}
          >
            <LogOut size={17} />
            Wyloguj profil demo
          </Button>
        </>
      )}
    </Modal>
  );
}
