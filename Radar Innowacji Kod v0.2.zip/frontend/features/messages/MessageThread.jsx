import React, { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import Button from '../../components/ui/Button.jsx';

export default function MessageThread({ conversation, partner, profileId, onSend }) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const log = useRef(null);
  useEffect(() => {
    log.current.scrollTop = log.current.scrollHeight;
  }, [conversation.messages.length]);
  function submit(event) {
    event.preventDefault();
    if (!onSend(conversation.id, text)) {
      setError('Wpisz wiadomość od 1 do 2000 znaków.');
      return;
    }
    setText('');
    setError('');
  }
  return (
    <section>
      <h3>{partner?.name || 'Profil niedostępny'}</h3>
      <div
        className="chat-body"
        ref={log}
        role="log"
        aria-label="Historia rozmowy"
        aria-live="polite"
      >
        <p className="muted">
          Rozmowa lokalna. Przełącz profil demo na rozmówcę, aby odpowiedzieć. Dane nie opuszczają
          tej przeglądarki.
        </p>
        {conversation.messages.map((message) => (
          <div
            className={`bubble${message.senderId === profileId ? ' bubble--outgoing' : ' bubble--incoming'}`}
            key={message.id}
          >
            <span className="message-author">
              {message.senderId === profileId ? 'Ty' : partner?.name}
            </span>
            {message.text}
            <small>
              {new Date(message.created).toLocaleString('pl', {
                day: 'numeric',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </small>
          </div>
        ))}
      </div>
      <form className="message-form" onSubmit={submit}>
        <input
          aria-label="Wiadomość"
          placeholder="Napisz wiadomość…"
          maxLength={2000}
          value={text}
          onChange={(event) => setText(event.target.value)}
        />
        <Button type="submit" aria-label="Wyślij wiadomość lokalnie" disabled={!text.trim()}>
          <Send size={19} />
        </Button>
      </form>
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
