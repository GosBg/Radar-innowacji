import React from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';

export default function DeleteIdeaDialog({ ideaId, onClose }) {
  const { state, innovations } = useRadar();
  const idea = state.items.find((item) => item.id === ideaId);
  return (
    <Modal title="Usunąć innowację?" onClose={onClose}>
      <p>
        Usunięcie „{idea?.title}” z demonstracji jest nieodwracalne. Możesz zamiast tego skorzystać
        z archiwizacji.
      </p>
      <Button
        variant="danger"
        full
        onClick={() => {
          innovations.deleteIdea(ideaId);
          onClose();
        }}
      >
        Usuń innowację
      </Button>
      <Button variant="outline" full onClick={onClose}>
        Anuluj
      </Button>
    </Modal>
  );
}
