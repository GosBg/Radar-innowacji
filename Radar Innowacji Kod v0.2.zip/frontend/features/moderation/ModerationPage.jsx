import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { statusLabels } from '../../data/constants.js';
import Button from '../../components/ui/Button.jsx';
import EmptyState from '../../components/ui/EmptyState.jsx';

export default function ModerationPage() {
  const { state, innovations, navigation, setDialog } = useRadar();
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <div className="eyebrow dark">PANEL DEMONSTRACYJNY</div>
      <h1>Moderacja innowacji</h1>
      <p>Symulacja pracy administratora. Wersja produkcyjna wymaga autoryzacji na serwerze.</p>
      {!state.items.length && (
        <EmptyState
          title="Brak zgłoszeń"
          description="Nowe pomysły pojawią się tutaj po wysłaniu formularza."
        />
      )}
      {state.items.map((idea) => (
        <div className="manage-row" key={idea.id}>
          <div>
            <h3>{idea.title}</h3>
            <span className="tag">{statusLabels[idea.status]}</span>
            {idea.similar && state.items.some((item) => item.id === idea.similar) && (
              <div className="duplicate">
                <AlertTriangle />
                Ryzyko dublowania treści
                <a
                  href={`?idea=${encodeURIComponent(idea.similar)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  ZOBACZ
                </a>
              </div>
            )}
          </div>
          <div className="row-actions">
            <Button variant="outline" onClick={() => navigation.showIdea(idea.id)}>
              Zobacz
            </Button>
            {idea.status !== 'published' && (
              <Button className="small" onClick={() => innovations.publish(idea.id)}>
                {idea.status === 'archived' ? 'Przywróć' : 'Akceptuj'}
              </Button>
            )}
            {idea.status === 'published' && (
              <Button variant="outline" onClick={() => innovations.archive(idea.id)}>
                Archiwizuj
              </Button>
            )}
            <Button
              variant="danger-text"
              onClick={() => setDialog({ type: 'delete', ideaId: idea.id })}
            >
              Usuń
            </Button>
          </div>
        </div>
      ))}
    </main>
  );
}
