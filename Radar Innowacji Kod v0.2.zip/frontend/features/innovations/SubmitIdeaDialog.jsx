import React, { useState } from 'react';
import { ShieldCheck, X } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { categories, stages } from '../../data/constants.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';

export default function SubmitIdeaDialog({ onClose }) {
  const { innovations, navigation } = useRadar();
  const [draft, setDraft] = useState({
    title: '',
    description: '',
    category: categories[0],
    stage: stages[0],
  });
  const [error, setError] = useState('');
  const change = (key) => (event) =>
    setDraft((current) => ({ ...current, [key]: event.target.value }));
  const profanity = error === 'Wykryto wulgaryzm!';
  // Swap modal content instead of stacking two focus traps; the controlled draft survives.
  if (profanity)
    return (
      <Modal title={error} onClose={() => setError('')}>
        <div className="error-symbol">
          <X size={44} />
        </div>
        <p>Popraw treść zgłoszenia i spróbuj ponownie.</p>
        <Button full onClick={() => setError('')}>
          Wróć do poprawiania
        </Button>
      </Modal>
    );

  return (
    <Modal title="Twój pomysł zasługuje na radar" onClose={onClose}>
      <p>Opowiedz, jaki problem rozwiązujesz. Po weryfikacji pomysł pojawi się w katalogu.</p>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          const error = innovations.submitIdea(draft);
          setError(error);
          if (!error) {
            onClose();
            navigation.go('mine');
          }
        }}
      >
        <label>
          Nazwa innowacji
          <input
            value={draft.title}
            onChange={change('title')}
            required
            minLength={8}
            maxLength={110}
            placeholder="Krótka, konkretna nazwa Twojego pomysłu"
          />
        </label>
        <label>
          Problem i proponowane rozwiązanie
          <textarea
            value={draft.description}
            onChange={change('description')}
            required
            minLength={30}
            maxLength={5000}
            rows={6}
            placeholder="Komu pomoże Twój pomysł? Jak działa? Co go wyróżnia?"
          />
        </label>
        <div className="two-fields">
          <label>
            Obszar
            <select value={draft.category} onChange={change('category')}>
              {categories.map((category) => (
                <option key={category}>{category}</option>
              ))}
            </select>
          </label>
          <label>
            Etap rozwoju
            <select value={draft.stage} onChange={change('stage')}>
              {stages.map((stage) => (
                <option key={stage}>{stage}</option>
              ))}
            </select>
          </label>
        </div>
        <p className="notice">
          <ShieldCheck size={19} />
          Sprawdzimy podobieństwo słów do istniejących zgłoszeń. O publikacji decyduje moderator.
        </p>
        {error && (
          <p className="field-error" role="alert">
            {error}
          </p>
        )}
        <Button type="submit" full>
          Wyślij do moderacji
        </Button>
      </form>
    </Modal>
  );
}
