import React from 'react';
import { Lightbulb } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { statusLabels } from '../../data/constants.js';
import EmptyState from '../../components/ui/EmptyState.jsx';
import Button from '../../components/ui/Button.jsx';

export default function MySubmissionsPage() {
  const { state, profile, navigation, requestSubmission, setDialog } = useRadar();
  const items = state.items.filter((idea) => idea.owner === profile?.id);
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <h1>Moje zgłoszenia</h1>
      <p>Śledź drogę swojego pomysłu do publikacji.</p>
      {!profile ? (
        <EmptyState
          title="Wybierz swój profil"
          description="Zgłoszenia są przypisane do ich twórcy."
        >
          <Button onClick={() => setDialog({ type: 'login' })}>Wybierz profil demo</Button>
        </EmptyState>
      ) : !items.length ? (
        <EmptyState title="Twój pierwszy pomysł jest przed Tobą" icon={Lightbulb}>
          <Button onClick={requestSubmission}>Zgłoś pomysł</Button>
        </EmptyState>
      ) : (
        items.map((idea) => (
          <div className="manage-row" key={idea.id}>
            <div>
              <h3>{idea.title}</h3>
              <span className="tag">{statusLabels[idea.status]}</span>
            </div>
            <Button variant="outline" onClick={() => navigation.showIdea(idea.id)}>
              Szczegóły
            </Button>
          </div>
        ))
      )}
    </main>
  );
}
