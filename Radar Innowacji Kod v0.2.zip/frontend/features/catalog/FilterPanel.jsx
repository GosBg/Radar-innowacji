import React from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { times, regions, criteria } from '../../data/constants.js';
export default function FilterPanel({ model, expanded }) {
  const {
    age,
    setAge,
    days,
    setDays,
    author,
    setAuthor,
    region,
    setRegion,
    bounds,
    setBounds,
    period,
    setPeriod,
    reset,
    validationError,
  } = model;
  const filters = expanded;
  return (
    <aside id="catalog-filters" className={filters ? 'filters shown' : 'filters'}>
      <div className="filter-title">
        <h3>
          <SlidersHorizontal size={18} /> Dopasuj wyniki
        </h3>
        <button onClick={reset}>Wyczyść</button>
      </div>
      <fieldset>
        <legend>Data publikacji</legend>
        {validationError && (
          <p className="field-error" role="alert">
            {validationError}
          </p>
        )}
        <div className="range-label">
          <span>Od teraz</span>
          <b>
            {days.some((value) => value !== '')
              ? `${days[0] || 0}–${days[1] || times[age][1]} dni`
              : age === 0
                ? 'Ostatnia godzina'
                : times[age][0]}
          </b>
        </div>
        <input
          aria-label="Maksymalny wiek publikacji"
          type="range"
          min="0"
          max="13"
          value={age}
          onChange={(e) => {
            setAge(+e.target.value);
            setDays(['', '']);
          }}
        />
        <div className="two-fields">
          {['Od (dni)', 'Do (dni)'].map((l, j) => (
            <label key={l}>
              {l}
              <input
                type="number"
                min="0"
                max="730"
                step="0.01"
                placeholder={j ? '730' : '0'}
                value={days[j]}
                onChange={(e) => setDays((a) => a.map((v, k) => (k === j ? e.target.value : v)))}
              />
            </label>
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend>Autor innowacji</legend>
        {[
          ['all', 'Wszyscy twórcy'],
          ['private', 'Osoba prywatna'],
          ['company', 'Firma / instytucja'],
        ].map(([v, l]) => (
          <label className="radio" key={v}>
            <input
              type="radio"
              name="author"
              checked={author === v}
              onChange={() => setAuthor(v)}
            />
            {l}
          </label>
        ))}
      </fieldset>
      <fieldset>
        <legend>Lokalizacja</legend>
        <label>
          Województwo
          <select value={region} onChange={(e) => setRegion(e.target.value)}>
            <option value="">Cała Polska</option>
            {regions.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </label>
      </fieldset>
      <fieldset>
        <legend>Ocena potencjału</legend>
        <p className="muted">Zakres 0–5 dla każdej kategorii.</p>
        {criteria.map((c, j) => (
          <div className="rating-filter" key={c}>
            {c}
            <div className="two-fields">
              {[0, 1].map((k) => (
                <select
                  key={k}
                  aria-label={`${c} ${k ? 'do' : 'od'}`}
                  value={bounds[j][k]}
                  onChange={(e) =>
                    setBounds((a) =>
                      a.map((v, n) =>
                        n === j ? v.map((x, t) => (t === k ? e.target.value : x)) : v,
                      ),
                    )
                  }
                >
                  <option value="">{k ? 'Do: dowolnie' : 'Od: dowolnie'}</option>
                  {Array.from({ length: 11 }, (_, i) => (
                    <option value={i / 2} key={i}>
                      {i / 2} ★
                    </option>
                  ))}
                </select>
              ))}
            </div>
          </div>
        ))}
      </fieldset>
      <fieldset>
        <legend>TOP w okresie</legend>
        <select
          aria-label="Okres rankingu"
          value={period}
          onChange={(e) => {
            setPeriod(e.target.value);
          }}
        >
          {[
            ['all', 'Cały czas'],
            ['1', 'Dzisiaj (24 h)'],
            ['7', 'Ostatni tydzień'],
            ['30', 'Ostatni miesiąc'],
            ['365', 'Ostatni rok'],
          ].map(([v, l]) => (
            <option value={v} key={v}>
              {l}
            </option>
          ))}
        </select>
        <p className="muted">
          Ranking pomysłów opublikowanych w wybranym okresie, według średniej ocen.
        </p>
      </fieldset>
    </aside>
  );
}
