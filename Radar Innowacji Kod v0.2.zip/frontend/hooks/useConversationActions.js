import { canStartConversation, getConversation, canSendMessage } from '../domain/conversations.js';

export default function useConversationActions({ state, update, profile }) {
  return {
    startConversation(recipientId) {
      const recipient = state.profiles.find((value) => value.id === recipientId);
      if (!canStartConversation(profile, recipient)) return null;
      const existing = getConversation(state.conversations, profile.id, recipientId);
      if (existing) return existing.id;
      const conversation = {
        id: crypto.randomUUID(),
        participants: [profile.id, recipientId],
        messages: [],
      };
      update((current) => ({
        ...current,
        conversations: [...current.conversations, conversation],
      }));
      return conversation.id;
    },
    sendMessage(conversationId, text) {
      const trimmed = text.trim();
      const thread = state.conversations.find((value) => value.id === conversationId);
      if (!trimmed || trimmed.length > 2000 || !canSendMessage(thread, profile?.id)) return false;
      const message = {
        id: crypto.randomUUID(),
        senderId: profile.id,
        text: trimmed,
        created: Date.now(),
      };
      update((current) => ({
        ...current,
        conversations: current.conversations.map((conversation) =>
          conversation.id === conversationId
            ? { ...conversation, messages: [...conversation.messages, message] }
            : conversation,
        ),
      }));
      return true;
    },
  };
}
