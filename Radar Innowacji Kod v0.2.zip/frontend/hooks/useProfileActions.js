import { validateProfile } from '../domain/validation.js';

export default function useProfileActions({ update, profile, notify }) {
  return {
    saveProfile(draft) {
      const error = validateProfile(draft);
      if (error) return error;
      const saved = {
        ...draft,
        id: draft.id || crypto.randomUUID(),
        name: draft.name.trim(),
        city: draft.city.trim(),
        affiliation: draft.affiliation.trim(),
      };
      update((current) => ({
        ...current,
        profiles: current.profiles.some((value) => value.id === saved.id)
          ? current.profiles.map((value) => (value.id === saved.id ? saved : value))
          : [...current.profiles, saved],
        activeProfileId: saved.id,
        // Keep author cards consistent after a profile edit.
        items: current.items.map((item) =>
          item.owner === saved.id
            ? {
                ...item,
                author: saved.name,
                type: saved.type,
                city: saved.city,
                region: saved.region,
              }
            : item,
        ),
      }));
      notify('Profil demonstracyjny został zapisany.');
      return '';
    },
    switchProfile(id) {
      update((current) =>
        current.profiles.some((value) => value.id === id)
          ? { ...current, activeProfileId: id }
          : current,
      );
      notify('Zmieniono aktywny profil demo.');
    },
    logout() {
      if (profile) update((current) => ({ ...current, activeProfileId: null }));
    },
  };
}
