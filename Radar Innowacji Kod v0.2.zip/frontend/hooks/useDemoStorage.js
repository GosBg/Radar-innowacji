import { useCallback, useEffect, useState } from 'react';
import {
  STORAGE_KEY,
  createDemoState,
  isDemoState,
  migrateLegacy,
} from '../services/demoStorage.js';

export default function useDemoStorage() {
  const [error, setError] = useState('');
  const [state, setState] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return isDemoState(saved) ? saved : migrateLegacy(localStorage);
    } catch {
      return createDemoState();
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      setError('');
    } catch {
      setError(
        'Nie udało się zapisać zmian w przeglądarce. Dane działają tylko do odświeżenia strony. Zwolnij miejsce lub zmniejsz zdjęcie.',
      );
    }
  }, [state]);

  useEffect(() => {
    const sync = (event) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;
      try {
        const next = JSON.parse(event.newValue);
        if (isDemoState(next)) setState(next);
      } catch {
        /* Ignore malformed writes from another browser tab. */
      }
    };
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);

  const update = useCallback((updater) => setState((current) => updater(current)), []);
  return { state, update, storageError: error };
}
