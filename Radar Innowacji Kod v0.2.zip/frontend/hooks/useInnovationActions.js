import {
  findSimilarInnovation,
  publishInnovation,
  removeInnovation,
  containsProfanity,
} from '../domain/moderation.js';
import { validateIdea } from '../domain/validation.js';
import { isRating } from '../domain/ratings.js';

export default function useInnovationActions({ state, update, profile, notify }) {
  return {
    submitIdea(draft) {
      if (!profile) return 'Najpierw wybierz profil.';
      const error = validateIdea(draft);
      if (error) return error;
      if (containsProfanity(`${draft.title} ${draft.description}`)) return 'Wykryto wulgaryzm!';
      const idea = {
        ...draft,
        title: draft.title.trim(),
        description: draft.description.trim(),
        id: crypto.randomUUID(),
        author: profile.name,
        owner: profile.id,
        type: profile.type,
        city: profile.city,
        region: profile.region,
        created: Date.now(),
        publishedAt: null,
        ratings: [0, 0, 0, 0],
        votes: 0,
        art: 'tech',
        status: 'pending',
        similar: findSimilarInnovation(draft, state.items),
      };
      update((current) => ({ ...current, items: [idea, ...current.items] }));
      notify('Pomysł wysłany do moderacji.');
      return '';
    },
    toggleFavorite(id) {
      const owner = profile?.id ?? 'guest';
      update((current) => {
        const ids = current.favorites[owner] || [];
        return {
          ...current,
          favorites: {
            ...current.favorites,
            [owner]: ids.includes(id) ? ids.filter((value) => value !== id) : [...ids, id],
          },
        };
      });
    },
    rateIdea(id, index, value) {
      if (!profile || !isRating(value) || index < 0 || index > 3) return;
      update((current) => {
        if (current.items.find((item) => item.id === id)?.status !== 'published') return current;
        const ballots = current.ratings[id] || {};
        const ballot = ballots[profile.id] || [null, null, null, null];
        return {
          ...current,
          ratings: {
            ...current.ratings,
            [id]: {
              ...ballots,
              [profile.id]: ballot.map((rating, position) => (position === index ? value : rating)),
            },
          },
        };
      });
    },
    publish(id) {
      update((current) => ({
        ...current,
        items: current.items.map((item) => (item.id === id ? publishInnovation(item) : item)),
      }));
      notify('Innowacja jest dostępna w katalogu.');
    },
    archive(id) {
      update((current) => ({
        ...current,
        items: current.items.map((item) =>
          item.id === id ? { ...item, status: 'archived' } : item,
        ),
      }));
      notify('Innowacja została zarchiwizowana.');
    },
    deleteIdea(id) {
      update((current) => removeInnovation(current, id));
      notify('Innowacja została usunięta z demonstracji.');
    },
  };
}
