import { useEffect, useState } from 'react';

const pages = ['discover', 'favorites', 'messages', 'future', 'mine', 'admin'];
function readRoute() {
  const params = new URLSearchParams(location.search);
  return {
    page: pages.includes(params.get('page')) ? params.get('page') : 'discover',
    ideaId: params.get('idea'),
  };
}

/** Small native-history router: links survive refresh and browser Back/Forward. */
export default function useNavigation() {
  const [route, setRoute] = useState(readRoute);
  useEffect(() => {
    const onPopState = () => setRoute(readRoute());
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);
  const navigate = (next, replace = false) => {
    const url = new URL(location.href);
    url.search = '';
    if (next.page !== 'discover') url.searchParams.set('page', next.page);
    if (next.ideaId) url.searchParams.set('idea', next.ideaId);
    history[replace ? 'replaceState' : 'pushState']({}, '', url);
    setRoute(next);
  };
  return {
    ...route,
    go: (page) => {
      navigate({ page, ideaId: null });
      window.scrollTo({ top: 0 });
    },
    showIdea: (ideaId) => navigate({ ...route, ideaId }),
    closeIdea: () => navigate({ ...route, ideaId: null }, true),
  };
}
