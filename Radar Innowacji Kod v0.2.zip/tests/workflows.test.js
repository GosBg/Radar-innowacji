import test from 'node:test';
import assert from 'node:assert/strict';
import {
  containsProfanity,
  findSimilarInnovation,
  publishInnovation,
  removeInnovation,
} from '../frontend/domain/moderation.js';
import {
  canStartConversation,
  canSendMessage,
  getConversation,
} from '../frontend/domain/conversations.js';
import { migrateLegacy, createDemoState } from '../frontend/services/demoStorage.js';
import { validateAvatar, validateIdea, validateProfile } from '../frontend/domain/validation.js';

test('similarity flags overlap, ignores pending and does not match substrings', () => {
  const idea = {
    id: 'one',
    title: 'Sensor wody',
    description: 'Rehabilitacja pacjenta',
    status: 'published',
  };
  assert.equal(findSimilarInnovation(idea, [idea]), 'one');
  assert.equal(findSimilarInnovation(idea, [{ ...idea, status: 'pending' }]), null);
  assert.equal(
    findSimilarInnovation({ title: 'Sensory', description: 'Elektrownia' }, [idea]),
    null,
  );
});

test('profanity check supports Unicode words and letter variants', () => {
  assert.equal(containsProfanity('To jest kurwa test'), true);
  assert.equal(containsProfanity('KURWĄ'), true);
  assert.equal(containsProfanity('Kulturalny opis rozwiązania'), false);
});

test('republishing an archived innovation preserves its first publication date', () => {
  const item = publishInnovation({ created: 5, publishedAt: null }, 10);
  assert.equal(item.publishedAt, 10);
  assert.equal(publishInnovation({ ...item, status: 'archived' }, 20).publishedAt, 10);
  assert.equal(item.created, 5);
});

test('deletion removes stale favorites, scores and duplicate references', () => {
  const state = {
    items: [{ id: 'one' }, { id: 'two', similar: 'one' }],
    ratings: { one: { alice: [4] } },
    favorites: { alice: ['one', 'two'], guest: ['one'] },
  };
  const result = removeInnovation(state, 'one');
  assert.equal(result.items[0].similar, null);
  assert.deepEqual(result.favorites, { alice: ['two'], guest: [] });
  assert.deepEqual(result.ratings, {});
  assert.equal(state.items.length, 2);
});

test('company initiates, both participants reply, third parties cannot send', () => {
  const company = { id: 'company', type: 'company' };
  const person = { id: 'person', type: 'private' };
  assert.equal(canStartConversation(company, person), true);
  assert.equal(canStartConversation(person, company), false);
  assert.equal(canStartConversation(company, company), false);
  const conversation = { id: 'thread', participants: ['company', 'person'] };
  assert.equal(canSendMessage(conversation, person.id), true);
  assert.equal(canSendMessage(conversation, 'other'), false);
  assert.equal(getConversation([conversation], 'person', 'company').id, 'thread');
});

test('v1 migration preserves existing profile, favorites, votes and readable messages', () => {
  const legacy = {
    'radar.profile.v1': { id: 'old-profile', name: 'Tester' },
    'radar.favorites.v1': ['1'],
    'radar.ratings.v1': { 1: [5, 0, 0, 0] },
    'radar.messages.v1': [
      {
        id: 'message',
        owner: 'old-profile',
        partner: 'Anna Kowalska',
        text: 'Dzień dobry',
        created: 10,
      },
    ],
  };
  const storage = { getItem: (key) => JSON.stringify(legacy[key] ?? null) };
  const state = migrateLegacy(storage, createDemoState());
  assert.equal(state.activeProfileId, 'old-profile');
  assert.deepEqual(state.favorites['old-profile'], ['1']);
  assert.equal(state.ratings['1']['old-profile'][0], 5);
  assert.equal(state.conversations[0].messages[0].text, 'Dzień dobry');
});

test('profile, idea and file validation rejects whitespace and invalid uploads', () => {
  assert.ok(
    validateProfile({
      type: 'private',
      name: '  ',
      city: 'X',
      affiliation: 'Student',
      region: 'Podkarpackie',
    }),
  );
  assert.ok(
    validateIdea({
      title: '        ',
      description: ' '.repeat(40),
      category: 'Zdrowie',
      stage: 'Pomysł',
    }),
  );
  assert.ok(validateAvatar({ type: 'text/html', size: 10 }));
  assert.ok(validateAvatar({ type: 'image/png', size: 1024 * 1024 + 1 }));
  assert.equal(validateAvatar({ type: 'image/jpeg', size: 10 }), '');
});
