# Radar innowacji

Responsywna aplikacja demonstracyjna React + Vite. Wersja 0.2 rozdziela widoki, komponenty, reguły biznesowe i zapis danych.

## Uruchomienie

Wymagany Node.js 20.19+ lub 22.12+.

```sh
npm ci
npm run dev
```

| Polecenie              | Działanie                                         |
| ---------------------- | ------------------------------------------------- |
| `npm run build`        | Kompilacja do `dist/`                             |
| `npm run preview`      | Podgląd kompilacji                                |
| `npm test`             | Testy ocen, filtrów, moderacji, rozmów i migracji |
| `npm run format`       | Formatowanie kodu przez Prettier                  |
| `npm run format:check` | Sprawdzenie formatowania bez zmian                |

## Mapa projektu

```text
frontend/
  main.jsx                 # tylko uruchomienie Reacta i import CSS
  app/
    App.jsx                # składanie układu i wybór strony
    AppDialogs.jsx         # jedno aktywne okno
    RadarContext.jsx       # wspólny stan i dostęp do akcji
  components/
    ui/                    # Button, Modal, Avatar, EmptyState, Toast
    layout/                # Header i Footer
    innovation/            # karta, grafika, serce, gwiazdki
  features/
    catalog/               # katalog, filtry, wyszukiwarka, hero
    profiles/              # wybór profilu, edycja, zdjęcie
    innovations/           # zgłoszenie, szczegóły, moje pomysły
    moderation/            # kolejka moderatora i usuwanie
    messages/              # lista rozmów i historia wiadomości
    development/           # przyszły rozwój
    help/                  # opis działania
  hooks/                   # stan filtrów, nawigacja i akcje
  domain/                  # czyste reguły bez Reacta i przeglądarki
  services/demoStorage.js  # model lokalnego magazynu i migracja v1
  data/                    # stałe i fikcyjne przykłady
  styles/                  # kaskada i osobne obszary CSS
tests/                     # testy uruchamiane w Node.js
backend/README.md          # plan rzeczywistego backendu
```

Komponenty w `components/` przyjmują dane i callbacki przez props. Nie odczytują localStorage. Widoki funkcji korzystają z `useRadar()`. Hooki akcji zmieniają stan, a funkcje w `domain/` obliczają wyniki i walidują dane. Algorytm ocen można zmienić bez edycji JSX.

## Kaskada CSS

Jedyny punkt wejścia stylów to `frontend/styles/index.css`:

```css
@layer tokens, base, layout, components, utilities;
```

1. `tokens.css`: kolory, fonty, odstępy i promienie — pierwsze miejsce do zmiany motywu.
2. `base.css`: dziedziczenie fontu, podstawowe elementy i formularze.
3. `layout.css`: nagłówek, nawigacja, stopka.
4. Pliki komponentów, np. `cards.css`, `catalog.css`, `profiles.css`, `ratings.css`: wygląd i warianty danego obszaru. Reguły responsywne są w tym samym pliku co komponent.
5. `accessibility.css` i `motion.css`: fokus, dostępność i ograniczenie animacji.

Późniejsza warstwa ma pierwszeństwo przed wcześniejszą. W obrębie warstwy obowiązują specyficzność i kolejność CSS. Nie ma inline styles ani reguł `!important`. Nie dodawaj stylów poza warstwami — nieprzypisana reguła mogłaby nieoczekiwanie wygrać z całą kaskadą.

`Button` obsługuje warianty `primary`, `outline`, `danger`, `icon`. Domyślnie ma `type="button"`; zapis formularza wymaga jawnego `type="submit"`.

## Jak rozbudowywać

- Nowy widok: plik w `features/`, wpis w `CurrentPage` w `App.jsx` i trasa w `useNavigation.js`.
- Powtarzalny element: komponent z nazwanymi props w `components/`. Nie przekazuj całego stanu do elementów UI.
- Reguła biznesowa: czysta funkcja w `domain/` i test zachowania w `tests/`.
- Style: plik danego obszaru albo nowy import `layer(components)` w `styles/index.css`.
- Serwer: zastąp `useDemoStorage` i hooki akcji wywołaniami API. Walidacja i autoryzacja muszą działać także na backendzie.

## Zachowanie interfejsu

- Katalog: wyszukiwanie, obszar, autor, województwo, wiek publikacji i oceny. Niepoprawny zakres pokazuje błąd. Reset przywraca także sortowanie.
- Oceny: 0,5–5, osobne dla profilu i kategorii. Kolejny wybór zastępuje głos. Brak oceny nie jest zerem. Średnia ogólna to suma oddanych ocen podzielona przez ich liczbę.
- TOP: ranking pomysłów **opublikowanych** w wybranym okresie, nie głosów oddanych w tym okresie.
- Ulubione: osobne dla profili i gościa.
- Profil: zmiany i zdjęcie zapisują się dopiero po zatwierdzeniu. Zamknięcie odrzuca szkic. Dane autora aktualizują się także na kartach.
- Zgłoszenie: walidacja, lokalny słownik wulgaryzmów, podobieństwo słów, kolejka moderatora. Alert nie kasuje wpisanej treści.
- Moderacja: publikacja, archiwizacja, przywrócenie z zachowaniem pierwszej daty publikacji i usuwanie z potwierdzeniem. Usuwanie czyści też powiązane ulubione, oceny i linki duplikatów.
- Rozmowy: firma rozpoczyna kontakt z innym autorem; obaj uczestnicy mogą odpowiedzieć po przełączeniu profilu demo na tym samym urządzeniu.
- Nawigacja: strony i szczegóły mają URL; działają odświeżenie i Wstecz/Dalej. Nieaktualny link pokazuje komunikat.
- Okna: Escape, zatrzymanie i przywrócenie fokusu, nieaktywne tło. Kontrolki mają działanie lub wyjaśniony stan niedostępności.

## Ręczne sprawdzenie

1. Wybierz ReLab przez „Zmień profil demo”. Otwórz pomysł Anny Kowalskiej, wystaw 4,5, dodaj do ulubionych, rozpocznij rozmowę i wyślij wiadomość.
2. Przełącz się na Annę, odpowiedz w skrzynce i odśwież stronę. Historia powinna pozostać.
3. Zgłoś pomysł, zaakceptuj w Demo moderatora i sprawdź katalog. Po archiwizacji pomysł znika; po przywróceniu wraca.
4. Sprawdź zakres dni 5–1 (błąd), TOP z ostatniej doby, reset i ocenę tylko wybranej kategorii.
5. Zmień nazwę profilu i zamknij bez zapisu — stara nazwa zostaje. Powtórz z zatwierdzeniem.
6. Na szerokości telefonu sprawdź menu, filtry, formularz i Escape.

## Granice demonstracji

To frontend bez rzeczywistego serwera i kont. Wybór profilu demo nie jest uwierzytelnianiem. Administrator demo jest dostępny jawnie. Nie wpisuj prawdziwych haseł ani danych wrażliwych. Kontakt działa w lokalnej skrzynce; nie pokazujemy fikcyjnego e-maila jako prawdziwego kontaktu.

Dane są w localStorage pod `radar.demo.v2`. Migracja zachowuje dane v1 i nie usuwa starych kluczy. Karty przeglądarki synchronizują się przez `storage`; przy równoczesnej edycji wygrywa ostatni zapis. To nie magazyn dla wielu rzeczywistych użytkowników. Brak miejsca na zapis jest sygnalizowany.

Słownik wulgaryzmów i podobieństwo słów to heurystyki, nie gwarancja moderacji ani nowości. Przykładowe projekty, autorzy i oceny są fikcyjne. Przyszłe funkcje w zakładce „Innowacje” są oznaczone „W planach”. Fonty DM Sans i Manrope są opcjonalnie pobierane z Google Fonts; ikony pochodzą z Lucide.
