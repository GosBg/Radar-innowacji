# Backend — kolejny etap

Ta wersja jest prototypem interfejsu. Nie zawiera serwera, bazy danych ani rzeczywistego uwierzytelniania. Profile, wiadomości, oceny i zgłoszenia pozostają w localStorage przeglądarki. Panel moderatora jest jawnie dostępną symulacją. Nie stosować do danych osobowych ani rzeczywistej moderacji.

Docelowy backend powinien zapewniać:

- PostgreSQL: organizacje, użytkownicy, członkostwa, innowacje, oceny, ulubione, rozmowy, wiadomości i dziennik moderacji. Każdy rekord organizacji zawiera tenant_id.
- Rejestrację i logowanie przez dostawcę tożsamości lub hasła hashowane Argon2id; weryfikację adresu e-mail, reset hasła, sesje HttpOnly/Secure/SameSite i MFA administratora.
- Autoryzację każdego żądania: osoba prywatna zgłasza pomysły i odpowiada; zweryfikowana firma rozpoczyna rozmowy i otrzymuje kontakt autora; moderator zatwierdza, archiwizuje i usuwa. Uprawnienia nie mogą pochodzić z danych klienta.
- Weryfikację organizacji przed dostępem do kontaktów. E-maile poza publicznym API, udostępniane wyłącznie zgodnie ze zgodą autora i uprawnieniami. Wiadomości widoczne tylko uczestnikom rozmowy.
- Walidację serwerową, limitowanie żądań, ochronę CSRF, kontrolę rozmiaru i typu plików oraz skanowanie uploadów. Parametryzowane zapytania i poprawne kodowanie treści.
- Weryfikację publikacji i filtr wulgaryzmów na serwerze. Obecny słownik w przeglądarce jest demonstracyjny i łatwy do obejścia.
- Oceny 0,5–5, unikalne dla pary użytkownik/innowacja/kategoria; agregaty liczone z rzeczywistych głosów. Ranking okresu publikacji odrębny od rankingu ocen oddanych w okresie.
- Podobieństwo leksykalne jako sygnał dla moderatora; później wyszukiwanie semantyczne z uzasadnieniem i linkami. Żadna metoda nie dowodzi braku duplikatów ani nowości patentowej.
- API wersjonowane /api/v1, paginację, filtrowanie po stronie serwera, audyt dostępu, szyfrowane kopie zapasowe, retencję i usuwanie danych.

Rozdzielenie folderów frontend/backend jest organizacją kodu, nie granicą bezpieczeństwa. Nie istnieje gwarancja systemu „nie do złamania”. Przed udostępnieniem rzeczywistym użytkownikom wymagane są testy izolacji organizacji, uprawnień i przepływów danych.
