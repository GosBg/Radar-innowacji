import { readFile, writeFile, mkdir, readdir, unlink } from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import { configuration } from './config.js';
import { encryption } from './lib/crypto.js';
import { connectDatabase } from './db/connection.js';
import { applyRetention } from './services/retention.js';

// Explicit list is also the restore dependency order. Sessions/tokens are deliberately not backed up.
const tables = [
  'organizations',
  'users',
  'memberships',
  'innovations',
  'ratings',
  'favorites',
  'conversations',
  'conversation_members',
  'messages',
  'reports',
  'sanctions',
  'attachments',
  'moderation_log',
];
const config = configuration(),
  crypto = await encryption(config);
if (!config.databaseUrl) {
  const listening = await new Promise((resolve) => {
    const socket = net.connect(config.port, config.host);
    socket.on('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.on('error', () => resolve(false));
  });
  if (listening)
    throw new Error('Zatrzymaj npm run dev przed kopią lub odtwarzaniem lokalnej bazy PGlite.');
}
const db = await connectDatabase(config);
try {
  const command = process.argv[2];
  if (command === 'retention') {
    await applyRetention(db, config);
    console.log('Retencja wykonana.');
  } else if (command === 'backup') {
    const snapshot = { version: 1, created: new Date().toISOString(), tables: {}, files: {} };
    await db.transaction(async (tx) => {
      await tx.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
      for (const table of tables)
        snapshot.tables[table] = (await tx.query(`SELECT * FROM ${table}`)).rows;
      for (const file of snapshot.tables.attachments)
        snapshot.files[file.id] = (
          await readFile(path.join(config.dataDir, 'uploads', file.id))
        ).toString('base64');
    });
    const folder = path.join(config.dataDir, 'backups');
    await mkdir(folder, { recursive: true });
    const name = `radar-${Date.now()}.enc`;
    await writeFile(path.join(folder, name), crypto.seal(Buffer.from(JSON.stringify(snapshot))), {
      mode: 0o600,
    });
    const old = (await readdir(folder))
      .filter((n) => /^radar-\d+\.enc$/.test(n))
      .sort()
      .slice(0, -7);
    for (const name of old) await unlink(path.join(folder, name));
    console.log(`Zapisano szyfrowaną kopię: ${path.join(folder, name)}. Klucz przechowuj osobno.`);
  } else if (command === 'restore') {
    if (!process.argv[3]) throw new Error('Podaj ścieżkę kopii .enc.');
    const snapshot = JSON.parse(crypto.open(await readFile(process.argv[3])).toString());
    if (snapshot.version !== 1) throw new Error('Nieobsługiwana wersja kopii.');
    for (const table of tables)
      if ((await db.query(`SELECT 1 FROM ${table} LIMIT 1`)).rows.length)
        throw new Error('Odtwarzanie jest dozwolone tylko do pustej bazy.');
    await mkdir(path.join(config.dataDir, 'uploads'), { recursive: true });
    for (const [id, bytes] of Object.entries(snapshot.files)) {
      if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('Niepoprawny identyfikator pliku.');
      await writeFile(path.join(config.dataDir, 'uploads', id), Buffer.from(bytes, 'base64'), {
        mode: 0o600,
      });
    }
    await db.transaction(async (tx) => {
      for (const table of tables) {
        const allowed = new Set(
          (
            await tx.query(
              "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=$1",
              [table],
            )
          ).rows.map((r) => r.column_name),
        );
        for (const row of snapshot.tables[table]) {
          const keys = Object.keys(row);
          if (keys.some((k) => !allowed.has(k))) throw new Error('Niepoprawna kolumna kopii.');
          const values = keys.map((k) => (k === 'similar_id' ? null : row[k]));
          await tx.query(
            `INSERT INTO ${table}(${keys.join(',')}) VALUES(${keys.map((_, i) => `$${i + 1}`).join(',')})`,
            values,
          );
        }
      }
      for (const row of snapshot.tables.innovations)
        if (row.similar_id)
          await tx.query('UPDATE innovations SET similar_id=$2 WHERE id=$1', [
            row.id,
            row.similar_id,
          ]);
    });
    console.log('Kopia odtworzona. Wszystkie osoby muszą zalogować się ponownie.');
  } else throw new Error('Polecenia: backup, restore <plik>, retention');
} finally {
  await db.close();
}
