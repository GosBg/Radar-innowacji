import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';
import { sessionService } from './middleware/session.js';
import { authRoutes } from './routes/auth.js';
import { ideaRoutes } from './routes/ideas.js';
import { communityRoutes } from './routes/community.js';
import { adminRoutes } from './routes/admin.js';
import { fileRoutes } from './routes/files.js';
import { errorHandler } from './lib/errors.js';
import { mailService } from './services/mail.js';

export function createApp({ db, config, crypto }) {
  const app = express();
  app.disable('x-powered-by');
  if (config.production) app.set('trust proxy', 1);
  app.use(
    helmet({
      contentSecurityPolicy: config.production ? undefined : false,
      crossOriginEmbedderPolicy: false,
    }),
  );
  const limiter = (limit, windowMs = 60000) =>
    rateLimit({
      windowMs,
      limit,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      message: { message: 'Zbyt wiele żądań. Spróbuj ponownie za chwilę.' },
    });
  const sessions = sessionService(db, config),
    mail = mailService(db, config);
  const deps = {
    db,
    config,
    crypto,
    sessions,
    mail,
    authLimiter: limiter(config.testing ? 1000 : 25, 15 * 60000),
    uploadLimiter: limiter(15),
  };
  app.use(
    '/api',
    (req, res, next) => {
      if (req.get('sec-fetch-site') === 'cross-site')
        return res.status(403).json({ message: 'Żądanie spoza witryny zostało odrzucone.' });
      next();
    },
    limiter(config.testing ? 10000 : 300),
    express.json({ limit: '64kb' }),
    cookieParser(),
    sessions.load,
    sessions.csrf,
    (req, res, next) => {
      res.set('Cache-Control', 'no-store');
      next();
    },
  );
  app.use('/api/v1/auth', authRoutes(deps));
  app.use('/api/v1/ideas', ideaRoutes(deps));
  app.use('/api/v1', communityRoutes(deps));
  app.use('/api/v1/admin', adminRoutes(deps));
  app.use('/api/v1/files', fileRoutes(deps));
  app.get('/api/v1/health', (req, res) => res.json({ ok: true, version: '0.3.0' }));
  app.use('/api', (req, res) => res.status(404).json({ message: 'Nie znaleziono endpointu.' }));
  app.use(errorHandler);
  return app;
}
