import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import {
  requireUser,
  requireParticipant,
  requireVerifiedCompany,
  checkSanction,
} from '../lib/policy.js';
import { getProfile } from '../services/projections.js';
import { reportInput } from '../lib/validation.js';
import { visibleIdea } from './ideas.js';

export async function conversationView(db, id, page = 1) {
  const members = (
    await db.query('SELECT user_id FROM conversation_members WHERE conversation_id=$1', [id])
  ).rows.map((r) => r.user_id);
  const messages = (
    await db.query(
      'SELECT * FROM messages WHERE conversation_id=$1 ORDER BY created_at DESC,id DESC LIMIT 50 OFFSET $2',
      [id, (page - 1) * 50],
    )
  ).rows
    .reverse()
    .map((r) => ({
      id: r.id,
      sender: r.sender_id,
      text: r.body,
      created: +new Date(r.created_at),
    }));
  return { id, participants: members, messages, page, hasOlder: messages.length === 50 };
}
export function communityRoutes({ db }) {
  const router = Router();
  router.get(
    '/reports',
    route(async (req, res) => {
      const user = requireUser(req),
        kind = z.enum(['idea', 'message']).parse(req.query.kind || 'idea'),
        page = z.coerce
          .number()
          .int()
          .min(1)
          .max(10000)
          .parse(req.query.page || 1);
      res.json({
        items: (
          await db.query(
            'SELECT id,kind,reason,status,created_at,innovation_id,message_id FROM reports WHERE reporter_id=$1 AND kind=$2 ORDER BY created_at DESC,id LIMIT 25 OFFSET $3',
            [user.id, kind, (page - 1) * 25],
          )
        ).rows,
        total: (
          await db.query(
            'SELECT count(*)::int AS total FROM reports WHERE reporter_id=$1 AND kind=$2',
            [user.id, kind],
          )
        ).rows[0].total,
        page,
      });
    }),
  );
  router.get(
    '/state',
    route(async (req, res) => {
      if (!req.user)
        return res.json({
          profiles: [],
          conversations: [],
          favorites: [],
          reports: [],
          sanctions: [],
        });
      const id = req.user.id;
      const threadIds = (
        await db.query(
          'SELECT conversation_id FROM conversation_members WHERE user_id=$1 ORDER BY conversation_id LIMIT 100',
          [id],
        )
      ).rows;
      const conversations = [];
      for (const row of threadIds)
        conversations.push(await conversationView(db, row.conversation_id));
      const ids = [...new Set([id, ...conversations.flatMap((c) => c.participants)])],
        profiles = [];
      for (const member of ids) profiles.push(await getProfile(db, member));
      res.json({
        profiles: profiles.filter(Boolean),
        conversations,
        favorites: (
          await db.query('SELECT innovation_id FROM favorites WHERE user_id=$1', [id])
        ).rows.map((r) => r.innovation_id),
        reports: (
          await db.query(
            'SELECT id,kind,reason,status,created_at,innovation_id,message_id FROM reports WHERE reporter_id=$1 ORDER BY created_at DESC LIMIT 100',
            [id],
          )
        ).rows,
        sanctions: (
          await db.query(
            'SELECT kind,reason,expires_at FROM sanctions WHERE user_id=$1 AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>now())',
            [id],
          )
        ).rows,
      });
    }),
  );
  router.post(
    '/conversations',
    route(async (req, res) => {
      const user = requireUser(req);
      await requireVerifiedCompany(db, user);
      await checkSanction(db, user.id, 'mute');
      const recipient = z.string().uuid().parse(req.body.recipient);
      ensure(recipient !== user.id, 400, 'Wybierz inną osobę.');
      ensure(
        (await db.query('SELECT 1 FROM users WHERE id=$1', [recipient])).rows.length,
        404,
        'Nie znaleziono odbiorcy.',
      );
      const pair = [user.id, recipient].sort().join(':'),
        id = randomUUID();
      const result = await db.transaction(async (tx) => {
        const row = (
          await tx.query(
            'INSERT INTO conversations(id,pair_key) VALUES($1,$2) ON CONFLICT(pair_key) DO UPDATE SET pair_key=EXCLUDED.pair_key RETURNING id',
            [id, pair],
          )
        ).rows[0];
        await tx.query(
          'INSERT INTO conversation_members VALUES($1,$2),($1,$3) ON CONFLICT DO NOTHING',
          [row.id, user.id, recipient],
        );
        return row.id;
      });
      res.status(201).json({ id: result });
    }),
  );
  router.get(
    '/conversations/:id',
    route(async (req, res) => {
      const user = requireUser(req);
      await requireParticipant(db, user.id, req.params.id);
      const page = z.coerce
        .number()
        .int()
        .min(1)
        .max(10000)
        .parse(req.query.page || 1);
      res.json(await conversationView(db, req.params.id, page));
    }),
  );
  router.post(
    '/conversations/:id/messages',
    route(async (req, res) => {
      const user = requireUser(req);
      await requireParticipant(db, user.id, req.params.id);
      await checkSanction(db, user.id, 'mute');
      const text = z.string().trim().min(1).max(2000).parse(req.body.text);
      await db.query(
        'INSERT INTO messages(id,conversation_id,sender_id,body) VALUES($1,$2,$3,$4)',
        [randomUUID(), req.params.id, user.id, text],
      );
      res.status(201).json({ ok: true });
    }),
  );
  router.post(
    '/reports',
    route(async (req, res) => {
      const user = requireUser(req),
        input = reportInput.parse(req.body);
      let owner,
        idea = null,
        message = null;
      if (input.kind === 'idea') {
        const row = await visibleIdea(db, req, input.targetId);
        ensure(row.status === 'published', 403, 'Zgłaszać można opublikowane pomysły.');
        owner = row.owner_id;
        idea = row.id;
      } else {
        const row = (await db.query('SELECT * FROM messages WHERE id=$1', [input.targetId]))
          .rows[0];
        ensure(row, 404, 'Brak wiadomości.');
        await requireParticipant(db, user.id, row.conversation_id);
        owner = row.sender_id;
        message = row.id;
      }
      ensure(owner !== user.id, 400, 'Nie zgłaszaj własnej treści.');
      ensure(
        !(
          await db.query(
            "SELECT 1 FROM reports WHERE reporter_id=$1 AND status='open' AND (innovation_id=$2 OR message_id=$3)",
            [user.id, idea, message],
          )
        ).rows.length,
        409,
        'To zgłoszenie już oczekuje na rozpatrzenie.',
      );
      await db.query(
        'INSERT INTO reports(id,reporter_id,kind,innovation_id,message_id,target_user_id,reason) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [randomUUID(), user.id, input.kind, idea, message, owner, input.reason],
      );
      res.status(201).json({ ok: true });
    }),
  );
  return router;
}
