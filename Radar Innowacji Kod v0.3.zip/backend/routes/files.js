import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import multer from 'multer';
import { fileTypeFromBuffer } from 'file-type';
import sharp from 'sharp';
import { zip } from 'fflate';
import { z } from 'zod';
import { route, ensure } from '../lib/errors.js';
import { requireUser, checkSanction, audit } from '../lib/policy.js';
import { visibleIdea } from './ideas.js';
import { scan, inspectOffice } from '../services/scanner.js';
import { digest } from '../lib/crypto.js';

export function fileRoutes({ db, config, crypto, uploadLimiter }) {
  const router = Router(),
    folder = path.join(config.dataDir, 'uploads');
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 20 * 1024 * 1024, files: 1, fields: 0 },
  }).single('file');
  router.post(
    '/upload/:purpose',
    uploadLimiter,
    async (req, res, next) => {
      try {
        z.enum(['idea', 'avatar']).parse(req.params.purpose);
        const ticket = req.get('x-registration-token');
        if (ticket && req.params.purpose === 'avatar') {
          z.string().min(30).max(100).parse(ticket);
          const grant = (
            await db.query(
              'DELETE FROM registration_uploads WHERE token_hash=$1 AND expires_at>now() RETURNING user_id',
              [digest(ticket)],
            )
          ).rows[0];
          ensure(
            grant,
            403,
            'Możliwość dodania zdjęcia przy rejestracji wygasła. Dodaj zdjęcie po zalogowaniu.',
          );
          req.uploadUser = { id: grant.user_id };
        } else requireUser(req);
        next();
      } catch (e) {
        next(e);
      }
    },
    upload,
    route(async (req, res) => {
      const user = req.uploadUser || req.user,
        purpose = req.params.purpose,
        file = req.file;
      ensure(file, 400, 'Wybierz plik.');
      if (purpose === 'idea') await checkSanction(db, user.id, 'post');
      const usage = (
        await db.query(
          "SELECT COALESCE(sum(size),0)::bigint AS bytes FROM attachments WHERE owner_id=$1 AND innovation_id IS NULL AND created_at>now()-interval '1 day'",
          [user.id],
        )
      ).rows[0];
      ensure(
        Number(usage.bytes) < 100 * 1024 * 1024,
        429,
        'Limit nowych plików na dziś został osiągnięty.',
      );
      ensure(
        file.size <= (purpose === 'avatar' ? 5 : 20) * 1024 * 1024,
        413,
        purpose === 'avatar'
          ? 'Zdjęcie profilowe może mieć maksymalnie 5 MB.'
          : 'Limit pliku to 20 MB.',
      );
      let buffer = file.buffer,
        type = await fileTypeFromBuffer(buffer),
        name = path
          .basename(file.originalname)
          .replace(/[\x00-\x1f<>:"/\\|?*]/g, '_')
          .slice(0, 120);
      ensure(
        type && ['jpg', 'png', 'pdf', 'docx', 'pptx'].includes(type.ext),
        400,
        'Obsługujemy JPG, PNG, PDF, DOCX oraz PPTX.',
      );
      ensure(
        path.extname(name).toLowerCase().replace('.', '').replace('jpeg', 'jpg') === type.ext,
        400,
        'Rozszerzenie nie odpowiada zawartości pliku.',
      );
      if (purpose === 'avatar')
        ensure(['jpg', 'png'].includes(type.ext), 400, 'Profilowe musi być JPG lub PNG.');
      if (['docx', 'pptx'].includes(type.ext)) await inspectOffice(buffer, type.ext);
      const scanStatus = await scan(buffer, config);
      if (['jpg', 'png'].includes(type.ext)) {
        buffer = await sharp(buffer, { limitInputPixels: 25000000 })
          .rotate()
          .resize({
            width: purpose === 'avatar' ? 512 : 3000,
            height: purpose === 'avatar' ? 512 : 3000,
            fit: 'inside',
            withoutEnlargement: true,
          })
          .jpeg({ quality: 90 })
          .toBuffer();
        type = { mime: 'image/jpeg', ext: 'jpg' };
        name = name.replace(/\.[^.]+$/, '.jpg');
      }
      const id = randomUUID();
      await mkdir(folder, { recursive: true });
      await writeFile(path.join(folder, id), crypto.seal(buffer), { mode: 0o600 });
      await db.query(
        'INSERT INTO attachments(id,owner_id,purpose,original_name,mime,size,scan_status) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [id, user.id, purpose, name, type.mime, buffer.length, scanStatus],
      );
      if (req.uploadUser)
        await db.query('UPDATE users SET avatar_id=$2 WHERE id=$1', [user.id, id]);
      res.status(201).json({ id, name, size: buffer.length, mime: type.mime });
    }),
  );
  const bytes = (file) => readFile(path.join(folder, file.id)).then(crypto.open);
  router.get(
    '/innovation/:id/zip',
    route(async (req, res) => {
      const idea = await visibleIdea(db, req, req.params.id),
        files = (await db.query('SELECT * FROM attachments WHERE innovation_id=$1', [idea.id]))
          .rows;
      ensure(files.length, 404, 'Brak załączników.');
      await audit(db, req.user, 'files.download.zip', idea.id);
      const entries = {};
      for (const [index, file] of files.entries())
        entries[`${index + 1}-${file.original_name}`] = new Uint8Array(await bytes(file));
      const archive = await new Promise((resolve, reject) =>
        zip(entries, { level: 6 }, (error, data) => (error ? reject(error) : resolve(data))),
      );
      res.attachment('radar-zalaczniki.zip').send(Buffer.from(archive));
    }),
  );
  router.get(
    '/:id',
    route(async (req, res) => {
      const id = z.string().uuid().parse(req.params.id),
        file = (await db.query('SELECT * FROM attachments WHERE id=$1', [id])).rows[0];
      ensure(file, 404, 'Brak pliku.');
      if (file.innovation_id) await visibleIdea(db, req, file.innovation_id);
      else if (file.purpose === 'avatar') {
        ensure(
          file.owner_id === req.user?.id ||
            (await db.query('SELECT 1 FROM users WHERE avatar_id=$1', [id])).rows.length,
          403,
          'Niedostępny plik.',
        );
      } else ensure(file.owner_id === req.user?.id, 403, 'Niedostępny plik.');
      await audit(db, req.user, 'file.read', id);
      res.set('Cache-Control', 'private, no-store');
      res.type(file.mime);
      if (!(file.purpose === 'avatar' && req.query.inline === '1'))
        res.attachment(file.original_name);
      res.send(await bytes(file));
    }),
  );
  return router;
}
