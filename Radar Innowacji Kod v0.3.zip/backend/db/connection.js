import { readFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { PGlite } from '@electric-sql/pglite';
import pg from 'pg';

export async function connectDatabase(config) {
  if (!config.databaseUrl && !config.memory) await mkdir(config.dataDir, { recursive: true });
  let engine;
  if (config.databaseUrl) engine = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });
  else engine = new PGlite(config.memory ? undefined : path.join(config.dataDir, 'postgres'));
  const query = (sql, parameters = []) => engine.query(sql, parameters);
  // Serialize embedded transactions; a PostgreSQL pool gets a dedicated client per transaction.
  let pending = Promise.resolve();
  async function transaction(work) {
    if (config.databaseUrl) {
      const client = await engine.connect();
      try {
        await client.query('BEGIN');
        const value = await work(client);
        await client.query('COMMIT');
        return value;
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    }
    const operation = pending.then(() => engine.transaction(work));
    pending = operation.catch(() => {});
    return operation;
  }
  const schema = await readFile(new URL('./schema.sql', import.meta.url), 'utf8');
  if (config.databaseUrl) await engine.query(schema);
  else await engine.exec(schema);
  return {
    query,
    transaction,
    close: () => (config.databaseUrl ? engine.end() : engine.close()),
    engine: config.databaseUrl ? 'PostgreSQL' : 'PGlite (PostgreSQL lokalny)',
  };
}
