import { randomUUID } from 'node:crypto';
import argon2 from 'argon2';
import { createDemoInnovations } from '../../frontend/data/demoInnovations.js';

export async function seed(db, config, crypto) {
  const existing = await db.query("SELECT id FROM users WHERE role='admin'");
  if (!existing.rows.length) {
    const example = config.examples;
    if (example || config.adminLogin) {
      await db.query(
        'INSERT INTO users(id,tenant_id,login,email,password_hash,name,account_type,role,city,region,affiliation,email_verified,example,mfa_secret) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,true,$12,$13)',
        [
          randomUUID(),
          randomUUID(),
          example ? 'admin' : config.adminLogin,
          example ? 'admin@example.invalid' : config.adminEmail,
          await argon2.hash(example ? 'admin' : config.adminPassword, { type: argon2.argon2id }),
          'Administrator',
          'private',
          'admin',
          'Bydgoszcz',
          'Kujawsko-pomorskie',
          'Radar innowacji',
          example,
          config.adminTotp ? crypto.seal(Buffer.from(config.adminTotp)).toString('base64') : null,
        ],
      );
    }
  }
  if (
    !config.examples ||
    (await db.query("SELECT id FROM users WHERE example=true AND role<>'admin' LIMIT 1")).rows
      .length
  )
    return;
  const fixtures = createDemoInnovations();
  for (const [index, item] of fixtures.entries()) {
    const id = randomUUID(),
      tenant = randomUUID();
    await db.query(
      'INSERT INTO users(id,tenant_id,login,email,password_hash,name,account_type,city,region,affiliation,email_verified,contact_consent,example) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true,true,true)',
      [
        id,
        tenant,
        `przyklad${index + 1}`,
        `przyklad${index + 1}@example.invalid`,
        await argon2.hash(randomUUID(), { type: argon2.argon2id }),
        item.author,
        item.type,
        item.city,
        item.region,
        item.author,
      ],
    );
    if (item.type === 'company') {
      const org = randomUUID();
      await db.query(
        'INSERT INTO organizations(id,tenant_id,name,verified) VALUES($1,$2,$3,true)',
        [org, tenant, item.author],
      );
      await db.query(
        'INSERT INTO memberships(user_id,organization_id,tenant_id) VALUES($1,$2,$3)',
        [id, org, tenant],
      );
    }
    await db.query(
      'INSERT INTO innovations(id,tenant_id,owner_id,title,description,category,stage,art,status,created_at,published_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)',
      [
        randomUUID(),
        tenant,
        id,
        item.title,
        item.description,
        item.category,
        item.stage,
        item.art,
        'published',
        new Date(item.created),
      ],
    );
  }
}
