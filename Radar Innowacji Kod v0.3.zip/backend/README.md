# Backend Radaru

Instrukcje uruchamiania, usług, bezpieczeństwa i kopii znajdują się w [głównym README](../README.md).

Endpointy mają prefiks `/api/v1`. Klient zaczyna od `GET /auth/session`; odpowiedź zwraca token CSRF, a ciasteczko sesji pozostaje HttpOnly. Każde POST/PATCH/PUT/DELETE wymaga zgodnego `Origin` i nagłówka `X-CSRF-Token`.

| Obszar            | Endpointy                                                                                                          |
| ----------------- | ------------------------------------------------------------------------------------------------------------------ |
| Konta             | `/auth/register`, `/auth/login`, `/auth/logout`, `/auth/profile`, `/auth/forgot`, `/auth/token`                    |
| Katalog           | `/ideas?filters=JSON&page=1`, `/ideas/:id`, `?scope=mine`, `?scope=moderation`                                     |
| Pomysły           | POST `/ideas`, PATCH `/ideas/:id/moderation`, DELETE `/ideas/:id`                                                  |
| Oceny i zapisane  | PUT `/ideas/:id/rating`, PUT `/ideas/:id/favorite`                                                                 |
| Kontakt           | GET `/ideas/:id/contact`                                                                                           |
| Rozmowy           | POST `/conversations`, GET `/conversations/:id?page=1`, POST `/conversations/:id/messages`                         |
| Zgłoszenia        | POST `/reports`, GET `/state` dla własnej skrzynki i zgłoszeń                                                      |
| Admin             | `/admin/users?page=1`, `/admin/users/:id/reset`, `/role`, `/verification`, `/sanctions`                            |
| Zgłoszenia admina | `/admin/reports?kind=idea&page=1`, `/admin/reports/:id/context?page=1`                                             |
| Pliki             | POST `/files/upload/idea` lub `/avatar` (multipart pole `file`), GET `/files/:id`, GET `/files/innovation/:id/zip` |

`routes` odpowiadają za transport, `lib/policy.js` za wspólne uprawnienia, `services/projections.js` za jawne wybieranie pól odpowiedzi. Dane klienta nigdy nie nadają roli ani weryfikacji organizacji. Moderator ma wyłącznie zatwierdzanie/odrzucanie, admin ma pozostałe operacje moderacji. `db/schema.sql` inicjalizuje nową bazę; przyszłe zmiany istniejącego schematu wymagają numerowanych migracji.
