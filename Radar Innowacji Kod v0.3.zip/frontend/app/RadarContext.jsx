import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import useToast from '../hooks/useToast.js';
import useNavigation from '../hooks/useNavigation.js';
import { api } from '../api/client.js';
const RadarContext = createContext(null);
const empty = {
  items: [],
  profiles: [],
  conversations: [],
  favorites: [],
  reports: [],
  sanctions: [],
  ratings: {},
};
export function RadarProvider({ children }) {
  const [state, setState] = useState(empty),
    [profile, setProfile] = useState(null),
    [ready, setReady] = useState(false),
    [examples, setExamples] = useState(false),
    [revision, setRevision] = useState(0),
    [storageError, setError] = useState('');
  const [dialog, setDialog] = useState(() =>
      new URLSearchParams(location.search).has('auth') ? { type: 'token' } : null,
    ),
    [conversationId, setConversationId] = useState(null);
  const toast = useToast(),
    navigation = useNavigation();
  const mergeIdeas = useCallback(
    (items) =>
      setState((s) => ({
        ...s,
        items: [...s.items.filter((i) => !items.some((n) => n.id === i.id)), ...items],
      })),
    [],
  );
  const refresh = useCallback(async () => {
    const data = await api('/state');
    setState((s) => ({ ...s, ...data }));
    setRevision((r) => r + 1);
  }, []);
  async function bootstrap() {
    try {
      const session = await api('/auth/session');
      setProfile(session.user);
      setExamples(session.examples);
      await refresh();
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setReady(true);
    }
  }
  useEffect(() => {
    bootstrap();
  }, []);
  useEffect(() => {
    if (!profile) return;
    const timer = setInterval(() => refresh().catch(() => {}), 15000);
    return () => clearInterval(timer);
  }, [profile?.id, refresh]);
  useEffect(() => {
    if (!navigation.ideaId || !ready) return;
    api(`/ideas/${navigation.ideaId}`)
      .then((item) => mergeIdeas([item]))
      .catch((e) => toast.notify(e.message));
  }, [navigation.ideaId, ready, revision, mergeIdeas]);
  function handleError(error) {
    if (error.details?.kind) setDialog({ type: 'sanction', ...error.details });
    else toast.notify(error.message);
  }
  async function authenticate(path, body) {
    const data = await api(`/auth/${path}`, { method: 'POST', body });
    setProfile(data.user);
    setState(empty);
    await refresh();
    setDialog(null);
    return data;
  }
  const mutations = async (path, method, body) => {
    const data = await api(path, { method, body });
    await refresh();
    return data;
  };
  const innovations = {
    submitIdea: async (draft) => {
      try {
        await mutations('/ideas', 'POST', draft);
        return '';
      } catch (e) {
        return e.message + (e.details?.reason ? ` Powód: ${e.details.reason}` : '');
      }
    },
    toggleFavorite: async (id) => {
      if (!profile) return setDialog({ type: 'login' });
      try {
        await mutations(`/ideas/${id}/favorite`, 'PUT', { active: !state.favorites.includes(id) });
      } catch (e) {
        handleError(e);
      }
    },
    rateIdea: async (id, category, value) => {
      try {
        mergeIdeas([await mutations(`/ideas/${id}/rating`, 'PUT', { category, value })]);
      } catch (e) {
        handleError(e);
      }
    },
    deleteIdea: async (id) => {
      await mutations(`/ideas/${id}`, 'DELETE');
      setState((s) => ({ ...s, items: s.items.filter((i) => i.id !== id) }));
      navigation.closeIdea();
    },
    moderate: async (id, action, reason = '') =>
      mutations(`/ideas/${id}/moderation`, 'PATCH', { action, reason }),
  };
  function requestSubmission() {
    if (!profile) return setDialog({ type: 'login' });
    const sanction = state.sanctions.find(
      (s) => s.kind === 'post' && (!s.expires_at || new Date(s.expires_at) > new Date()),
    );
    setDialog(
      sanction
        ? {
            type: 'sanction',
            kind: 'post',
            reason: sanction.reason,
            expiresAt: sanction.expires_at,
          }
        : { type: 'submit' },
    );
  }
  async function openConversation(recipient) {
    try {
      const { id } = await mutations('/conversations', 'POST', { recipient });
      setConversationId(id);
      setDialog(null);
      navigation.go('messages');
    } catch (e) {
      handleError(e);
    }
  }
  const conversations = {
    sendMessage: async (id, text) => {
      try {
        await mutations(`/conversations/${id}/messages`, 'POST', { text });
        return true;
      } catch (e) {
        handleError(e);
        return false;
      }
    },
  };
  return (
    <RadarContext.Provider
      value={{
        state,
        profile,
        ready,
        examples,
        revision,
        storageError,
        ...toast,
        navigation,
        dialog,
        setDialog,
        closeDialog: () => setDialog(null),
        conversationId,
        setConversationId,
        innovations,
        conversations,
        requestSubmission,
        openConversation,
        favorites: state.favorites,
        refresh,
        mergeIdeas,
        authenticate,
        bootstrap,
        handleError,
        saveProfile: async (body) => {
          const user = await api('/auth/profile', { method: 'PATCH', body });
          setProfile(user);
          await refresh();
        },
        logout: async () => {
          await authenticate('logout');
          navigation.go('discover');
        },
      }}
    >
      {children}
    </RadarContext.Provider>
  );
}
export function useRadar() {
  const value = useContext(RadarContext);
  if (!value) throw new Error('Brak RadarProvider.');
  return value;
}
