import React, { useState } from 'react';
import { upload } from '../../api/client.js';
export default function AttachmentUpload({ files, onChange, onBusy }) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const total = files.reduce((sum, f) => sum + f.size, 0);
  return (
    <div className="attachments">
      <label>
        Załączniki · łącznie maks. 20 MB
        <input
          type="file"
          multiple
          disabled={busy}
          accept=".pdf,.docx,.pptx,.jpg,.jpeg,.png"
          onChange={async (e) => {
            const picked = [...e.target.files];
            e.target.value = '';
            setError('');
            if (
              files.length + picked.length > 10 ||
              total + picked.reduce((s, f) => s + f.size, 0) > 20 * 1024 * 1024
            ) {
              setError('Możesz dodać do 10 plików, łącznie maksymalnie 20 MB.');
              return;
            }
            setBusy(true);
            onBusy(true);
            let current = [...files];
            try {
              for (const file of picked) {
                current = [...current, await upload(file)];
                onChange(current);
              }
            } catch (e) {
              setError(e.message);
            } finally {
              setBusy(false);
              onBusy(false);
            }
          }}
        />
      </label>
      <small>
        PDF, Word (DOCX), prezentacja (PPTX), JPG, PNG. {(total / 1024 / 1024).toFixed(1)} / 20 MB
      </small>
      {files.map((file) => (
        <div className="file-row" key={file.id}>
          <span>{file.name}</span>
          <button
            type="button"
            disabled={busy}
            onClick={() => onChange(files.filter((f) => f.id !== file.id))}
          >
            Usuń
          </button>
        </div>
      ))}
      {busy && <p role="status">Sprawdzanie i przesyłanie plików…</p>}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
