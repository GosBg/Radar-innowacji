import React, { useState } from 'react';
import Button from '../../components/ui/Button.jsx';
export default function AttachmentList({ idea }) {
  const [selected, setSelected] = useState(null),
    [askAll, setAskAll] = useState(false),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const files = idea.attachments || [];
  async function download(all = false) {
    setBusy(true);
    setError('');
    try {
      const url = all ? `/api/v1/files/innovation/${idea.id}/zip` : `/api/v1/files/${selected.id}`;
      const response = await fetch(url, { credentials: 'same-origin' });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Nie można pobrać pliku.');
      }
      const blob = await response.blob(),
        href = URL.createObjectURL(blob),
        link = document.createElement('a');
      link.href = href;
      link.download = all ? 'radar-zalaczniki.zip' : selected.name;
      link.click();
      setTimeout(() => URL.revokeObjectURL(href), 30000);
      setSelected(null);
      setAskAll(false);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  if (!files.length) return null;
  return (
    <section className="attachments">
      <h3>Załączniki ({files.length})</h3>
      {files.map((file) => (
        <button
          className="file-row"
          key={file.id}
          onClick={() => {
            setSelected(file);
            setAskAll(false);
          }}
        >
          <span>↧ {file.name}</span>
          <small>{(file.size / 1024 / 1024).toFixed(2)} MB</small>
        </button>
      ))}
      {selected && (
        <div className="download-choice" role="group" aria-label="Pobieranie załączników">
          {askAll ? (
            <>
              <p>Czy pobrać wszystkie pliki?</p>
              <Button disabled={busy} onClick={() => download(true)}>
                Tak — pobierz ZIP
              </Button>
              <Button disabled={busy} variant="outline" onClick={() => download()}>
                Nie — tylko wybrany plik
              </Button>
            </>
          ) : (
            <>
              <p>{selected.name}</p>
              <Button
                disabled={busy}
                onClick={() => (files.length === 1 ? download() : setAskAll(true))}
              >
                Pobierz
              </Button>
            </>
          )}
          <button disabled={busy} onClick={() => setSelected(null)}>
            Anuluj
          </button>
        </div>
      )}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
