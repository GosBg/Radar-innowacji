import React from 'react';
import { Lightbulb } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { statusLabels } from '../../data/constants.js';
import EmptyState from '../../components/ui/EmptyState.jsx';
import Button from '../../components/ui/Button.jsx';
import useRemoteIdeas from '../../hooks/useRemoteIdeas.js';
import Pagination from '../../components/ui/Pagination.jsx';
import { formatRating } from '../../domain/ratings.js';

export default function MySubmissionsPage() {
  const { state, profile, navigation, requestSubmission, setDialog } = useRadar();
  const remote = useRemoteIdeas({ scope: 'mine' }),
    items = remote.items;
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <h1>Moje Innowacje</h1>
      <p>Śledź drogę swojego pomysłu do publikacji.</p>
      {!profile ? (
        <EmptyState
          title="Wybierz swój profil"
          description="Zgłoszenia są przypisane do ich twórcy."
        >
          <Button onClick={() => setDialog({ type: 'login' })}>Zaloguj</Button>
        </EmptyState>
      ) : !items.length ? (
        <EmptyState title="Twój pierwszy pomysł jest przed Tobą" icon={Lightbulb}>
          <Button onClick={requestSubmission}>Zgłoś pomysł</Button>
        </EmptyState>
      ) : (
        items.map((idea) => (
          <div className="manage-row" key={idea.id}>
            <div>
              <h3>{idea.title}</h3>
              <span className="tag">{statusLabels[idea.status]}</span>
              <p>
                Średnia ocen: {formatRating(idea.summary.overall)} · {idea.summary.voters}{' '}
                głosujących
              </p>
              {idea.rejectionReason && <p className="field-error">{idea.rejectionReason}</p>}
            </div>
            <Button variant="outline" onClick={() => navigation.showIdea(idea.id)}>
              Szczegóły
            </Button>
            <Button
              variant="danger-text"
              onClick={() => setDialog({ type: 'delete', ideaId: idea.id })}
            >
              Usuń
            </Button>
          </div>
        ))
      )}
      {profile && remote.error && (
        <p role="alert" className="field-error">
          {remote.error}
        </p>
      )}
      <Pagination {...remote} />
    </main>
  );
}
