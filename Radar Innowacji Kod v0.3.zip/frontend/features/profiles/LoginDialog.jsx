import React, { useState, useEffect } from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import { api } from '../../api/client.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import Avatar from '../../components/ui/Avatar.jsx';
import DeliveryNotice from './DeliveryNotice.jsx';
export default function LoginDialog({ onClose }) {
  const { examples, authenticate, setDialog } = useRadar();
  const [mode, setMode] = useState('choose'),
    [accounts, setAccounts] = useState([]),
    [login, setLogin] = useState(''),
    [password, setPassword] = useState(''),
    [otp, setOtp] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [delivery, setDelivery] = useState(null);
  useEffect(() => {
    if (examples)
      api('/auth/examples')
        .then(setAccounts)
        .catch((e) => setError(e.message));
  }, [examples]);
  async function run(work) {
    setBusy(true);
    setError('');
    try {
      await work();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="Zaloguj się do Radaru" onClose={onClose}>
      {mode === 'choose' && (
        <div className="stack">
          <p>Wróć do swoich pomysłów, zapisanych innowacji i rozmów.</p>
          <Button onClick={() => setMode('account')}>Zaloguj do założonego konta</Button>
          {examples && (
            <Button variant="outline" onClick={() => setMode('examples')}>
              Zaloguj profilem Demo
            </Button>
          )}
          <Button variant="outline" onClick={() => setDialog({ type: 'profile', create: true })}>
            Zarejestruj się
          </Button>
        </div>
      )}
      {mode === 'examples' && (
        <div className="stack">
          <p>Profile demonstracyjne do lokalnego sprawdzenia funkcji.</p>
          {accounts.map((account) => (
            <button
              className="profile-choice"
              key={account.id}
              disabled={busy}
              onClick={() =>
                account.role === 'admin'
                  ? (setLogin('admin'), setMode('account'))
                  : run(() => authenticate('example', { id: account.id }))
              }
            >
              <Avatar profile={account} />
              <span>
                <b>{account.name}</b>
                <small>
                  {account.role === 'admin'
                    ? 'Administrator · wymagany login i hasło'
                    : account.type === 'company'
                      ? 'Firma / instytucja'
                      : 'Osoba prywatna'}
                </small>
              </span>
            </button>
          ))}
        </div>
      )}
      {mode === 'account' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run(() => authenticate('login', { login, password, otp }));
          }}
        >
          <label>
            Login lub e-mail
            <input
              required
              autoComplete="username"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
            />
          </label>
          <label>
            Hasło
            <input
              required
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <label>
            Kod MFA administratora (jeśli skonfigurowany)
            <input
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
          </label>
          <Button full type="submit" disabled={busy}>
            {busy ? 'Logowanie…' : 'Zaloguj'}
          </Button>
          <Button variant="outline" full onClick={() => setMode('forgot')}>
            Nie pamiętam hasła / ponów weryfikację
          </Button>
        </form>
      )}
      {mode === 'forgot' && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run(async () =>
              setDelivery(await api('/auth/forgot', { method: 'POST', body: { email: login } })),
            );
          }}
        >
          <label>
            E-mail
            <input required type="email" value={login} onChange={(e) => setLogin(e.target.value)} />
          </label>
          <Button type="submit" disabled={busy}>
            Resetuj hasło
          </Button>
          <Button
            variant="outline"
            disabled={busy}
            onClick={() =>
              run(async () =>
                setDelivery(
                  await api('/auth/resend-verification', {
                    method: 'POST',
                    body: { email: login },
                  }),
                ),
              )
            }
          >
            Ponów weryfikację e-mail
          </Button>
          <DeliveryNotice delivery={delivery} />
        </form>
      )}
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
      {mode !== 'choose' && (
        <Button
          variant="outline"
          full
          onClick={() => {
            setMode('choose');
            setError('');
          }}
        >
          Wróć
        </Button>
      )}
    </Modal>
  );
}
