import React, { useState } from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import { api, upload } from '../../api/client.js';
import { regions } from '../../data/constants.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import DeliveryNotice from './DeliveryNotice.jsx';
export default function ProfileDialog({ create = false, onClose, onSaved }) {
  const { profile, saveProfile } = useRadar();
  const [draft, setDraft] = useState(
    create
      ? {
          name: '',
          city: '',
          region: 'Podkarpackie',
          affiliation: '',
          type: 'private',
          login: '',
          email: '',
          password: '',
          contactConsent: false,
        }
      : { ...profile },
  );
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [delivery, setDelivery] = useState(null),
    [avatar, setAvatar] = useState(null);
  const change = (key) => (e) =>
    setDraft((d) => ({
      ...d,
      [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value,
    }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (create) {
        const result = await api('/auth/register', { method: 'POST', body: draft });
        if (avatar) {
          try {
            await upload(avatar, 'avatar', result.avatarTicket);
          } catch (error) {
            result.message += ` Zdjęcie nie zostało dodane: ${error.message} Możesz dodać je później w ustawieniach.`;
          }
        }
        setDelivery(result);
      } else {
        let avatarId;
        if (avatar) avatarId = (await upload(avatar, 'avatar')).id;
        const { name, city, region, affiliation, contactConsent } = draft;
        await saveProfile({
          name,
          city,
          region,
          affiliation,
          contactConsent,
          ...(avatarId ? { avatarId } : {}),
        });
        onSaved();
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title={create ? 'Dołącz do świata innowacji' : 'Ustawienia konta'} onClose={onClose}>
      {delivery ? (
        <DeliveryNotice delivery={delivery} />
      ) : (
        <form onSubmit={submit}>
          {create ? (
            <label>
              Rodzaj konta
              <select value={draft.type} onChange={change('type')}>
                <option value="private">Osoba prywatna</option>
                <option value="company">Firma / instytucja</option>
              </select>
            </label>
          ) : (
            <p className="notice">
              Rodzaj konta: {draft.type === 'private' ? 'osoba prywatna' : 'firma / instytucja'}.
              Nie można go zmienić po rejestracji.
            </p>
          )}
          <label>
            {draft.type === 'private' ? 'Imię i nazwisko' : 'Nazwa firmy / instytucji'}
            <input
              required
              minLength={2}
              maxLength={90}
              value={draft.name}
              onChange={change('name')}
            />
          </label>
          <div className="two-fields">
            <label>
              Miejscowość
              <input required maxLength={80} value={draft.city} onChange={change('city')} />
            </label>
            <label>
              Województwo
              <select value={draft.region} onChange={change('region')}>
                {regions.map((region) => (
                  <option key={region}>{region}</option>
                ))}
              </select>
            </label>
          </div>
          <label>
            {draft.type === 'private'
              ? 'Status / afiliacja (np. student, uczeń, pracownik)'
              : 'Reprezentowana organizacja'}
            <input
              required
              maxLength={100}
              value={draft.affiliation}
              onChange={change('affiliation')}
            />
          </label>
          {create ? (
            <>
              <label>
                Login
                <input
                  required
                  pattern="[a-zA-Z0-9_.-]{3,40}"
                  autoComplete="username"
                  value={draft.login}
                  onChange={change('login')}
                />
              </label>
              <label>
                E-mail
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={draft.email}
                  onChange={change('email')}
                />
              </label>
              <label>
                Hasło — co najmniej 12 znaków
                <input
                  type="password"
                  required
                  minLength={12}
                  maxLength={128}
                  autoComplete="new-password"
                  value={draft.password}
                  onChange={change('password')}
                />
              </label>
            </>
          ) : null}
          <label>
            Zdjęcie profilowe · JPG / PNG · maks. 5 MB
            <input
              type="file"
              accept="image/jpeg,image/png"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file?.size > 5 * 1024 * 1024) {
                  setError('Maksymalny rozmiar to 5 MB.');
                  e.target.value = '';
                  setAvatar(null);
                } else {
                  setAvatar(file);
                  setError('');
                }
              }}
            />
          </label>
          <label className="check-field">
            <input
              type="checkbox"
              checked={draft.contactConsent}
              onChange={change('contactConsent')}
            />
            Zgadzam się udostępniać mój e-mail zweryfikowanym firmom zainteresowanym moimi
            opublikowanymi pomysłami.
          </label>
          {draft.type === 'company' && (
            <p className="notice">
              Dostęp do kontaktów i rozpoczynania rozmów wymaga weryfikacji organizacji przez
              administratora.
            </p>
          )}
          {error && (
            <p className="field-error" role="alert">
              {error}
            </p>
          )}
          <Button type="submit" full disabled={busy}>
            {busy ? 'Zapisywanie…' : create ? 'Zarejestruj' : 'Zapisz zmiany'}
          </Button>
        </form>
      )}
    </Modal>
  );
}
