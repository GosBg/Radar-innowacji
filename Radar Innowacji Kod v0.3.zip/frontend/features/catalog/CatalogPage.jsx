import React, { useState } from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import useCatalogFilters from '../../hooks/useCatalogFilters.js';
import { summarizeRatings } from '../../domain/ratings.js';
import InnovationCard from '../../components/innovation/InnovationCard.jsx';
import EmptyState from '../../components/ui/EmptyState.jsx';
import Button from '../../components/ui/Button.jsx';
import Hero from './Hero.jsx';
import FilterPanel from './FilterPanel.jsx';
import CatalogToolbar from './CatalogToolbar.jsx';
import useRemoteIdeas from '../../hooks/useRemoteIdeas.js';
import Pagination from '../../components/ui/Pagination.jsx';

export default function CatalogPage({ onlyFavorites = false }) {
  const { state, favorites, innovations, navigation, requestSubmission, setDialog } = useRadar();
  const filters = useCatalogFilters();
  const [filtersOpen, setFiltersOpen] = useState(false);
  const remote = useRemoteIdeas({ filters: filters.values, favorites: onlyFavorites });
  const visible = remote.items;

  return (
    <>
      {!onlyFavorites && (
        <Hero onSubmit={requestSubmission} onHow={() => setDialog({ type: 'how' })} />
      )}
      <main className="catalog" id="main-content" tabIndex={-1}>
        <div className="section-heading">
          <div className="eyebrow dark">ODKRYJ TO, CO NADCHODZI</div>
          <h2>
            {onlyFavorites ? 'Twoje ulubione pomysły' : 'Na radarze innowacji'}
            <span>{remote.total}</span>
          </h2>
          <p>
            {onlyFavorites
              ? 'Wracaj do rozwiązań, w których widzisz potencjał.'
              : 'Znajdź pomysł, któremu pomożesz zrobić kolejny krok.'}
          </p>
        </div>
        <CatalogToolbar model={filters} expanded={filtersOpen} onToggleFilters={setFiltersOpen} />
        <div className="catalog-layout">
          <FilterPanel model={filters} expanded={filtersOpen} />
          <div>
            <div className="results-line" aria-live="polite">
              <span>
                {remote.loading ? (
                  'Wczytywanie…'
                ) : (
                  <>
                    Liczba pomysłów: <b>{remote.total}</b>
                  </>
                )}
              </span>
              <span>
                <span className="tiny-dot" />
                Zweryfikowane przez moderatora
              </span>
            </div>
            {remote.error && (
              <p role="alert" className="field-error">
                {remote.error}
              </p>
            )}
            <label className="ranking-mode">
              Podstawa rankingu
              <select
                value={filters.values.ranking || 'publication'}
                onChange={(e) => filters.setRanking(e.target.value)}
              >
                <option value="publication">Pomysły opublikowane w wybranym okresie</option>
                <option value="votes">Oceny oddane w wybranym okresie</option>
              </select>
            </label>
            <div className="cards">
              {visible.map((innovation) => (
                <InnovationCard
                  key={innovation.id}
                  innovation={innovation}
                  author={state.profiles.find((profile) => profile.id === innovation.owner)}
                  summary={summarizeRatings(innovation, state.ratings)}
                  favorite={favorites.includes(innovation.id)}
                  onFavorite={() => innovations.toggleFavorite(innovation.id)}
                  onOpen={() => navigation.showIdea(innovation.id)}
                />
              ))}
            </div>
            <Pagination {...remote} />
            {!visible.length && !remote.loading && !remote.error && (
              <EmptyState
                title={
                  filters.validationError ? 'Popraw zakres filtrów' : 'Jeszcze nic na tym radarze'
                }
                description={
                  filters.validationError || 'Zmień filtry lub dodaj pomysły do ulubionych.'
                }
              >
                <Button variant="outline" onClick={filters.reset}>
                  Wyczyść filtry
                </Button>
              </EmptyState>
            )}
          </div>
        </div>
      </main>
    </>
  );
}
