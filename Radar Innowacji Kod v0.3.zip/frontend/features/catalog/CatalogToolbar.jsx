import React from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { categories } from '../../data/constants.js';
export default function CatalogToolbar({ model, expanded, onToggleFilters }) {
  const { query, setQuery, sort, setSort, category, setCategory } = model;
  const filters = expanded;
  const setFilters = onToggleFilters;
  return (
    <>
      <div className="search-row">
        <label className="search">
          <Search size={21} />
          <input
            aria-label="Szukaj innowacji"
            placeholder="Szukaj pomysłów, technologii, twórców…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <button
          className="outline filter-toggle"
          aria-expanded={filters}
          aria-controls="catalog-filters"
          onClick={() => setFilters(!filters)}
        >
          <SlidersHorizontal size={18} /> Filtry
        </button>
        <label className="sort-label">
          Sortuj:
          <select aria-label="Sortowanie" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="new">Najnowsze</option>
            <option value="rating">Najwyżej oceniane</option>
          </select>
        </label>
      </div>
      <div className="categories">
        {['Wszystkie', ...categories].map((c) => (
          <button
            key={c}
            aria-pressed={category === c}
            className={category === c ? 'selected' : ''}
            onClick={() => setCategory(c)}
          >
            {c}
          </button>
        ))}
      </div>
    </>
  );
}
