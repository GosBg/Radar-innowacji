import React, { useState, useEffect } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../../components/ui/Button.jsx';
import Pagination from '../../components/ui/Pagination.jsx';
export default function ReportsPage({ own = false }) {
  const { state, ready, revision, setDialog, navigation, refresh, handleError } = useRadar();
  const [kind, setKind] = useState('idea'),
    [page, setPage] = useState(1),
    [data, setData] = useState({ items: [], total: 0 }),
    [error, setError] = useState('');
  useEffect(() => {
    if (ready)
      api(`${own ? '' : '/admin'}/reports?kind=${kind}&page=${page}`)
        .then((d) => {
          setData(d);
          setError('');
        })
        .catch((e) => setError(e.message));
  }, [own, ready, kind, page, revision]);
  const items = data.items;
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <h1>{own ? 'Moje zgłoszenia' : 'Zgłoszenia do administratora'}</h1>
      <p>
        {own
          ? 'Zgłoszone naruszenia dotyczące pomysłów i rozmów.'
          : 'Odczyt rozmowy jest możliwy wyłącznie w kontekście zgłoszonej wiadomości i jest audytowany.'}
      </p>
      <div className="tabs">
        {[
          ['idea', 'Pomysły'],
          ['message', 'Wiadomości'],
        ].map(([value, label]) => (
          <Button
            key={value}
            variant={kind === value ? 'primary' : 'outline'}
            onClick={() => {
              setKind(value);
              setPage(1);
            }}
          >
            {label}
          </Button>
        ))}
      </div>
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
      {!items.length && !error && <p>Brak zgłoszeń w tej kategorii.</p>}
      {items.map((report) => (
        <article className="manage-row" key={report.id}>
          <div>
            <h3>
              {report.title ||
                report.author ||
                (kind === 'idea' ? 'Zgłoszenie pomysłu' : 'Zgłoszenie wiadomości')}
            </h3>
            <p className="preserve-lines">{report.reason}</p>
            <span className="tag">{report.status === 'open' ? 'Oczekuje' : 'Rozpatrzone'}</span>
            <small> {new Date(report.created_at).toLocaleString('pl')}</small>
          </div>
          {!own && (
            <div className="row-actions">
              {kind === 'idea' && report.innovation_id && (
                <Button variant="outline" onClick={() => navigation.showIdea(report.innovation_id)}>
                  Zobacz pomysł
                </Button>
              )}
              {kind === 'message' && report.message_id && (
                <Button
                  variant="outline"
                  onClick={() => setDialog({ type: 'reportContext', reportId: report.id })}
                >
                  Zobacz rozmowę
                </Button>
              )}
              {report.target_user_id && (
                <Button
                  variant="outline"
                  onClick={() =>
                    setDialog({
                      type: 'setSanction',
                      kind: kind === 'idea' ? 'post' : 'mute',
                      userId: report.target_user_id,
                    })
                  }
                >
                  {kind === 'idea' ? 'Zablokuj dodawanie' : 'Wycisz autora'}
                </Button>
              )}
              {report.status === 'open' && (
                <Button
                  onClick={async () => {
                    try {
                      await api(`/admin/reports/${report.id}`, { method: 'PATCH' });
                      await refresh();
                    } catch (e) {
                      handleError(e);
                    }
                  }}
                >
                  Oznacz jako rozpatrzone
                </Button>
              )}
            </div>
          )}
        </article>
      ))}
      <Pagination page={page} setPage={setPage} total={data.total} limit={25} />
    </main>
  );
}
