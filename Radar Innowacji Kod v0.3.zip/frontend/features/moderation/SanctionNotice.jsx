import React from 'react';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
import Countdown from '../../components/ui/Countdown.jsx';
export default function SanctionNotice({ kind, reason, expiresAt, onClose }) {
  return (
    <Modal
      title={
        kind === 'mute'
          ? 'Wysyłanie wiadomości jest wyciszone'
          : 'Dodawanie pomysłów jest zablokowane'
      }
      onClose={onClose}
    >
      <p>Administrator zablokował tę możliwość z powodu:</p>
      <p className="field-error">{reason}</p>
      <p>
        Pozostały czas: <Countdown until={expiresAt} />
      </p>
      <p>Możesz dalej korzystać z pozostałych funkcji strony.</p>
      <Button full onClick={onClose}>
        Rozumiem
      </Button>
    </Modal>
  );
}
