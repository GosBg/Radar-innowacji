import React, { useState, useEffect } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../../components/ui/Button.jsx';
import Pagination from '../../components/ui/Pagination.jsx';
import Countdown from '../../components/ui/Countdown.jsx';
import DeliveryNotice from '../profiles/DeliveryNotice.jsx';
export default function AccountsPage() {
  const { ready, revision, setDialog, refresh, handleError } = useRadar();
  const [page, setPage] = useState(1),
    [data, setData] = useState({ items: [], total: 0 }),
    [error, setError] = useState(''),
    [delivery, setDelivery] = useState(null);
  useEffect(() => {
    if (ready)
      api(`/admin/users?page=${page}`)
        .then((d) => {
          setData(d);
          setError('');
        })
        .catch((e) => setError(e.message));
  }, [ready, page, revision]);
  async function run(path, method, body) {
    try {
      const result = await api(path, { method, body });
      if (result.message) setDelivery(result);
      await refresh();
    } catch (e) {
      handleError(e);
    }
  }
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <div className="eyebrow dark">ADMINISTRATOR</div>
      <h1>Konta użytkowników i firm</h1>
      <p>Zmiany uprawnień oraz odczyt listy kont trafiają do dziennika audytu.</p>
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
      <DeliveryNotice delivery={delivery} />
      {data.items.map((user) => (
        <article className="manage-row account-row" key={user.id}>
          <div>
            <h3>{user.name}</h3>
            <p>
              {user.login} · {user.email}
            </p>
            <span className="tag">
              {user.role === 'admin'
                ? 'Administrator'
                : user.role === 'moderator'
                  ? 'Moderator'
                  : user.account_type === 'company'
                    ? 'Firma / instytucja'
                    : 'Osoba prywatna'}
            </span>
            {user.account_type === 'company' && (
              <p>
                {user.verified ? 'Organizacja zweryfikowana' : 'Organizacja czeka na weryfikację'}
              </p>
            )}
            {user.sanctions.map((s) => (
              <p className="field-error" key={s.kind}>
                {s.kind === 'post' ? 'Blokada pomysłów' : 'Wyciszenie'}: {s.reason} ·{' '}
                <Countdown until={s.expires_at} />
                <button
                  onClick={() => run(`/admin/users/${user.id}/sanctions/${s.kind}`, 'DELETE')}
                >
                  Cofnij
                </button>
              </p>
            ))}
          </div>
          {user.role !== 'admin' && (
            <div className="row-actions">
              <Button
                variant="outline"
                onClick={() => run(`/admin/users/${user.id}/reset`, 'POST')}
              >
                Reset hasła
              </Button>
              {user.account_type === 'private' ? (
                <Button
                  variant="outline"
                  onClick={() =>
                    run(`/admin/users/${user.id}/role`, 'PATCH', {
                      role: user.role === 'moderator' ? 'user' : 'moderator',
                    })
                  }
                >
                  {user.role === 'moderator' ? 'Odbierz moderację' : 'Awansuj na moderatora'}
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={() =>
                    run(`/admin/users/${user.id}/verification`, 'PATCH', {
                      verified: !user.verified,
                    })
                  }
                >
                  {user.verified ? 'Cofnij weryfikację' : 'Zweryfikuj organizację'}
                </Button>
              )}
              <Button
                variant="outline"
                onClick={() => setDialog({ type: 'setSanction', kind: 'post', userId: user.id })}
              >
                Blokada pomysłów
              </Button>
              <Button
                variant="outline"
                onClick={() => setDialog({ type: 'setSanction', kind: 'mute', userId: user.id })}
              >
                Wycisz
              </Button>
              <Button
                variant="danger-text"
                onClick={() => setDialog({ type: 'deleteAccount', userId: user.id })}
              >
                Usuń konto
              </Button>
            </div>
          )}
        </article>
      ))}
      <Pagination page={page} setPage={setPage} total={data.total} limit={25} />
    </main>
  );
}
