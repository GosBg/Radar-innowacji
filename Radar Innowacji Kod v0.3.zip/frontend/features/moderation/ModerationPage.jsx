import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { statusLabels } from '../../data/constants.js';
import useRemoteIdeas from '../../hooks/useRemoteIdeas.js';
import Button from '../../components/ui/Button.jsx';
import Pagination from '../../components/ui/Pagination.jsx';
export default function ModerationPage() {
  const { profile, innovations, navigation, setDialog, handleError } = useRadar();
  const remote = useRemoteIdeas({ scope: 'moderation' });
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <div className="eyebrow dark">PANEL MODERACJI</div>
      <h1>Moderacja innowacji</h1>
      <p>
        Podobieństwo słów jest wskazówką do ręcznej analizy. Nie dowodzi braku duplikatów ani
        nowości patentowej.
      </p>
      {remote.error && (
        <p role="alert" className="field-error">
          {remote.error}
        </p>
      )}
      {remote.items.map((idea) => (
        <div className="manage-row" key={idea.id}>
          <div>
            <h3>{idea.title}</h3>
            <span className="tag">{statusLabels[idea.status]}</span>
            {idea.similar && (
              <div className="duplicate">
                <AlertTriangle />
                Ryzyko dublowania treści{' '}
                <a href={`?idea=${idea.similar}`} target="_blank" rel="noreferrer">
                  ZOBACZ
                </a>
              </div>
            )}
          </div>
          <div className="row-actions">
            <Button variant="outline" onClick={() => navigation.showIdea(idea.id)}>
              Zobacz
            </Button>
            {idea.status === 'pending' && (
              <>
                <Button onClick={() => innovations.moderate(idea.id, 'approve').catch(handleError)}>
                  Akceptuj
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setDialog({ type: 'reject', ideaId: idea.id })}
                >
                  Odrzuć
                </Button>
              </>
            )}
            {profile?.role === 'admin' && (
              <>
                {idea.status === 'published' && (
                  <Button
                    variant="outline"
                    onClick={() => innovations.moderate(idea.id, 'archive').catch(handleError)}
                  >
                    Archiwizuj
                  </Button>
                )}
                <Button
                  variant="danger-text"
                  onClick={() => setDialog({ type: 'delete', ideaId: idea.id })}
                >
                  Usuń
                </Button>
              </>
            )}
          </div>
        </div>
      ))}
      {!remote.loading && !remote.error && !remote.items.length && (
        <p>Brak pomysłów do rozpatrzenia.</p>
      )}
      <Pagination {...remote} />
    </main>
  );
}
