import React, { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
export default function ReportContextDialog({ reportId, onClose }) {
  const [data, setData] = useState(null),
    [page, setPage] = useState(0),
    [error, setError] = useState('');
  useEffect(() => {
    api(`/admin/reports/${reportId}/context${page ? `?page=${page}` : ''}`)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [reportId, page]);
  return (
    <Modal title="Kontekst zgłoszonej wiadomości" onClose={onClose}>
      <p>Wiadomość objęta zgłoszeniem jest oznaczona kolorem czerwonym.</p>
      {error && <p className="field-error">{error}</p>}
      {data?.messages.map((message) => (
        <div
          className={`review-message ${message.id === data.reportedMessageId ? 'reported-message' : ''}`}
          key={message.id}
        >
          <b>{message.id === data.reportedMessageId ? 'ZGŁOSZONA WIADOMOŚĆ' : 'Wiadomość'}</b>
          <small>
            {message.sender || 'Usunięte konto'} · {new Date(message.created).toLocaleString('pl')}
          </small>
          <p className="preserve-lines">{message.text}</p>
        </div>
      ))}
      <div className="pagination">
        <Button
          variant="outline"
          disabled={!data || data.page <= 1}
          onClick={() => setPage(data.page - 1)}
        >
          Nowsze
        </Button>
        <span>Strona {data?.page || 1}</span>
        <Button variant="outline" disabled={!data?.hasOlder} onClick={() => setPage(data.page + 1)}>
          Starsze
        </Button>
      </div>
    </Modal>
  );
}
