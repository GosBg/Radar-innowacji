import React, { useState } from 'react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Modal from '../../components/ui/Modal.jsx';
import Button from '../../components/ui/Button.jsx';
export default function AdminActionDialog({ action, userId, ideaId, onClose }) {
  const { refresh, innovations } = useRadar();
  const [reason, setReason] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  return (
    <Modal
      title={action === 'reject' ? 'Odrzuć pomysł' : 'Usuń konto użytkownika'}
      onClose={onClose}
    >
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            if (action === 'reject') await innovations.moderate(ideaId, 'reject', reason);
            else {
              await api(`/admin/users/${userId}`, { method: 'DELETE' });
              await refresh();
            }
            onClose();
          } catch (e) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        {action === 'reject' ? (
          <label>
            Powód odrzucenia
            <textarea
              required
              minLength={5}
              maxLength={2000}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </label>
        ) : (
          <p>
            Usunięcie konta, jego innowacji, ocen i załączników jest nieodwracalne. Autor wiadomości
            w zachowanych rozmowach zostanie oznaczony jako usunięte konto.
          </p>
        )}
        {error && <p className="field-error">{error}</p>}
        <Button variant="danger" full type="submit" disabled={busy}>
          {action === 'reject' ? 'Odrzuć' : 'Usuń konto'}
        </Button>
        <Button variant="outline" full onClick={onClose}>
          Anuluj
        </Button>
      </form>
    </Modal>
  );
}
