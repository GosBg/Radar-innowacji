import React, { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { api } from '../../api/client.js';
import { useRadar } from '../../app/RadarContext.jsx';
import Button from '../../components/ui/Button.jsx';
import Countdown from '../../components/ui/Countdown.jsx';
import ReportButton from '../moderation/ReportButton.jsx';
export default function MessageThread({ conversation, partner, profileId, onSend }) {
  const { state } = useRadar();
  const [text, setText] = useState(''),
    [busy, setBusy] = useState(false),
    [older, setOlder] = useState([]),
    [page, setPage] = useState(1),
    [hasOlder, setHasOlder] = useState(conversation.hasOlder),
    [error, setError] = useState('');
  const log = useRef(null);
  const mute = state.sanctions.find(
    (s) => s.kind === 'mute' && new Date(s.expires_at) > new Date(),
  );
  useEffect(() => {
    log.current.scrollTop = log.current.scrollHeight;
  }, [conversation.messages.length]);
  return (
    <section>
      <h3>{partner?.name || 'Usunięte konto'}</h3>
      <div
        className="chat-body"
        ref={log}
        role="log"
        aria-label="Historia rozmowy"
        aria-live="polite"
      >
        {hasOlder && (
          <Button
            variant="outline"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                const data = await api(`/conversations/${conversation.id}?page=${page + 1}`);
                setOlder((prev) => [...data.messages, ...prev]);
                setPage(page + 1);
                setHasOlder(data.hasOlder);
              } catch (e) {
                setError(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            Wczytaj starsze wiadomości
          </Button>
        )}
        {[...older, ...conversation.messages]
          .filter((m, i, arr) => arr.findIndex((x) => x.id === m.id) === i)
          .map((message) => (
            <div
              className={`bubble ${message.sender === profileId ? 'bubble--outgoing' : 'bubble--incoming'}`}
              key={message.id}
            >
              <span className="message-author">
                {message.sender === profileId ? 'Ty' : partner?.name || 'Usunięte konto'}
              </span>
              {message.text}
              <small>{new Date(message.created).toLocaleString('pl')}</small>
              <ReportButton kind="message" targetId={message.id} owner={message.sender} />
            </div>
          ))}
      </div>
      {mute && (
        <p className="notice">
          Wyciszenie: {mute.reason}. <Countdown until={mute.expires_at} />
        </p>
      )}
      <form
        className="message-form"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          if (await onSend(conversation.id, text)) setText('');
          setBusy(false);
        }}
      >
        <input
          aria-label="Wiadomość"
          placeholder="Napisz wiadomość…"
          maxLength={2000}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <Button type="submit" aria-label="Wyślij wiadomość" disabled={busy || !text.trim()}>
          <Send size={19} />
        </Button>
      </form>
      {error && <p className="field-error">{error}</p>}
    </section>
  );
}
