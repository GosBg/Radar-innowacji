import React from 'react';
import Avatar from '../../components/ui/Avatar.jsx';

export default function ConversationList({
  conversations,
  profiles,
  profileId,
  selectedId,
  onSelect,
}) {
  return (
    <aside>
      <h3>Wiadomości</h3>
      {conversations.map((conversation) => {
        const partner = profiles.find(
          (profile) => conversation.participants.includes(profile.id) && profile.id !== profileId,
        );
        return (
          <button
            key={conversation.id}
            className={`conversation${selectedId === conversation.id ? ' active' : ''}`}
            aria-pressed={selectedId === conversation.id}
            onClick={() => onSelect(conversation.id)}
          >
            <Avatar profile={partner} />
            <b>{partner?.name || 'Profil niedostępny'}</b>
          </button>
        );
      })}
      {!conversations.length && (
        <p>Brak rozmów. Firma może rozpocząć kontakt z poziomu opublikowanego pomysłu.</p>
      )}
    </aside>
  );
}
