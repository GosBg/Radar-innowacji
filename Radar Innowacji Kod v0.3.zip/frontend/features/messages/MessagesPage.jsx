import React from 'react';
import { Mail } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import EmptyState from '../../components/ui/EmptyState.jsx';
import Button from '../../components/ui/Button.jsx';
import ConversationList from './ConversationList.jsx';
import MessageThread from './MessageThread.jsx';

export default function MessagesPage() {
  const { state, profile, conversationId, setConversationId, conversations, setDialog } =
    useRadar();
  const available = state.conversations.filter((conversation) =>
    conversation.participants.includes(profile?.id),
  );
  const selected =
    available.find((conversation) => conversation.id === conversationId) || available[0];
  const partner =
    selected &&
    state.profiles.find(
      (candidate) => selected.participants.includes(candidate.id) && candidate.id !== profile?.id,
    );
  return (
    <main className="simple-page" id="main-content" tabIndex={-1}>
      <h1>Twoja przestrzeń rozmowy</h1>
      <p>Dobry pomysł to początek. Rozmowa może zmienić go w partnerstwo.</p>
      {!profile ? (
        <EmptyState icon={Mail} title="Zacznij od swojego profilu">
          <Button onClick={() => setDialog({ type: 'login' })}>Zaloguj</Button>
        </EmptyState>
      ) : (
        <div className="inbox">
          <ConversationList
            conversations={available}
            profiles={state.profiles}
            profileId={profile.id}
            selectedId={selected?.id}
            onSelect={setConversationId}
          />
          {selected ? (
            <MessageThread
              key={`${selected.id}-${profile.id}`}
              conversation={selected}
              partner={partner}
              profileId={profile.id}
              onSend={conversations.sendMessage}
            />
          ) : (
            <section>
              <EmptyState
                icon={Mail}
                title="Tutaj pojawi się rozmowa"
                description="Po rozpoczęciu rozmowy oba profile znajdą ją w swojej skrzynce."
              />
            </section>
          )}
        </div>
      )}
    </main>
  );
}
