import React from 'react';
import { Check } from 'lucide-react';
import Modal from '../../components/ui/Modal.jsx';
export default function HowItWorksDialog({ onClose }) {
  return (
    <Modal title="Od pomysłu do możliwości" onClose={onClose}>
      <div className="steps">
        {[
          ['Zgłoś pomysł', 'Utwórz profil i opisz problem, rozwiązanie oraz etap rozwoju.'],
          [
            'Daj się odkryć',
            'Moderator sprawdzi zgłoszenie. Po publikacji społeczność oceni cztery obszary potencjału.',
          ],
          [
            'Znajdź partnera',
            'Firmy i instytucje mogą rozpocząć z Tobą rozmowę o rozwoju i wdrożeniu.',
          ],
        ].map(([h, p]) => (
          <div key={h}>
            <Check />
            <section>
              <h3>{h}</h3>
              <p>{p}</p>
            </section>
          </div>
        ))}
      </div>
      <p className="notice">
        Oceny są opinią społeczności, nie ekspertyzą. Każdy oddany głos ma równą wagę; średnia
        ogólna uwzględnia wszystkie cztery kategorie.
      </p>
    </Modal>
  );
}
