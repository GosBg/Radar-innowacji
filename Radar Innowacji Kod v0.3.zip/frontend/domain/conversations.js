export function canStartConversation(sender, recipient) {
  return Boolean(sender?.type === 'company' && recipient && sender.id !== recipient.id);
}

export function getConversation(conversations, senderId, recipientId) {
  return conversations.find(
    (conversation) =>
      conversation.participants.includes(senderId) &&
      conversation.participants.includes(recipientId),
  );
}

export function canSendMessage(conversation, profileId) {
  return Boolean(conversation?.participants.includes(profileId));
}
