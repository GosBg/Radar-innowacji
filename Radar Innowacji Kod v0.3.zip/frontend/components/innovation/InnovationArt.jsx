import React from 'react';
import { Leaf, Activity, FlaskConical, Droplets, Layers, Users, Lightbulb } from 'lucide-react';
const icons = {
  solar: Leaf,
  health: Activity,
  education: FlaskConical,
  water: Droplets,
  tech: Layers,
  social: Users,
};
export default function InnovationArt({ kind = 'tech' }) {
  let Icon = icons[kind] || Lightbulb;
  return (
    <div className={'art ' + kind}>
      <div className="orbit one" />
      <div className="orbit two" />
      <div className="orb">
        <Icon size={58} strokeWidth={1.2} />
      </div>
      <div className="spark s1" />
      <div className="spark s2" />
      <span className="art-caption">POMYSŁY, KTÓRE ZMIENIAJĄ JUTRO</span>
    </div>
  );
}
