import React, { useState, useRef, useEffect } from 'react';
import { useRadar } from '../../app/RadarContext.jsx';
import Avatar from '../ui/Avatar.jsx';
export default function AccountMenu() {
  const { profile, navigation, setDialog, logout, handleError } = useRadar();
  const [open, setOpen] = useState(false),
    [dark, setDark] = useState(() => localStorage.getItem('radar-theme') === 'dark');
  const root = useRef(null);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    localStorage.setItem('radar-theme', dark ? 'dark' : 'light');
  }, [dark]);
  useEffect(() => {
    const close = (e) => {
      if (!root.current?.contains(e.target)) setOpen(false);
    };
    const key = (e) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('pointerdown', close);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', close);
      document.removeEventListener('keydown', key);
    };
  }, []);
  const go = (page) => {
    setOpen(false);
    navigation.go(page);
  };
  return (
    <div className="account-menu" ref={root}>
      <button
        className="login"
        aria-expanded={open}
        aria-controls="profile-menu"
        onClick={() => setOpen(!open)}
      >
        <Avatar profile={profile} />
        <span>{profile.name.split(' ')[0]}</span>
        <span aria-hidden="true">⌄</span>
      </button>
      {open && (
        <div id="profile-menu" className="account-dropdown">
          <b>{profile.name}</b>
          <small>
            {profile.role === 'admin'
              ? 'Administrator'
              : profile.role === 'moderator'
                ? 'Moderator'
                : profile.type === 'company'
                  ? 'Firma / instytucja'
                  : 'Osoba prywatna'}
          </small>
          <button onClick={() => setDark(!dark)}>{dark ? '☀ Tryb jasny' : '☾ Tryb ciemny'}</button>
          <button
            onClick={() => {
              setOpen(false);
              setDialog({ type: 'profile' });
            }}
          >
            Ustawienia
          </button>
          <button onClick={() => go('myReports')}>Moje zgłoszenia</button>
          <button onClick={() => go('mine')}>Moje Innowacje</button>
          {['admin', 'moderator'].includes(profile.role) && (
            <button onClick={() => go('admin')}>Moderacja innowacji</button>
          )}
          {profile.role === 'admin' && (
            <>
              <button onClick={() => go('accounts')}>Konta użytkowników</button>
              <button onClick={() => go('reports')}>Zgłoszenia do administratora</button>
            </>
          )}
          <button
            onClick={() => {
              setOpen(false);
              logout().catch(handleError);
            }}
          >
            Wyloguj
          </button>
        </div>
      )}
    </div>
  );
}
