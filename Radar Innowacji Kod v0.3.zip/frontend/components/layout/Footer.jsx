import React from 'react';
import { Radar } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';

export default function Footer() {
  const { navigation, setDialog } = useRadar();
  return (
    <footer>
      <div className="brand">
        <Radar />
        <b>
          radar<span className="brand-light">innowacji</span>
        </b>
      </div>
      <span>Pomysły z potencjałem. Ludzie z wizją.</span>
      <div>
        <button onClick={() => setDialog({ type: 'contact' })}>Kontakt</button>
        <span>HackNation 2026 · PCI</span>
      </div>
    </footer>
  );
}
