import { createDemoInnovations } from '../data/demoInnovations.js';

export const STORAGE_KEY = 'radar.demo.v2';

export function createDemoState() {
  const items = createDemoInnovations();
  return {
    version: 2,
    items,
    profiles: items.map((item) => ({
      id: item.owner,
      name: item.author,
      type: item.type,
      city: item.city,
      region: item.region,
      affiliation: item.type === 'company' ? item.author : 'Twórca innowacji',
      avatar: '',
    })),
    activeProfileId: null,
    favorites: {},
    ratings: {},
    conversations: [],
  };
}

export function isDemoState(value) {
  return (
    value?.version === 2 &&
    Array.isArray(value.items) &&
    Array.isArray(value.profiles) &&
    Array.isArray(value.conversations) &&
    value.ratings &&
    value.favorites &&
    value.items.every(
      (item) =>
        typeof item.id === 'string' &&
        typeof item.title === 'string' &&
        Array.isArray(item.ratings),
    ) &&
    value.profiles.every(
      (profile) => typeof profile.id === 'string' && typeof profile.name === 'string',
    )
  );
}

/** Migrate v1 without deleting its keys. Old local messages remain as readable history. */
export function migrateLegacy(storage, initial = createDemoState()) {
  const read = (key, fallback) => {
    try {
      return JSON.parse(storage.getItem(key)) ?? fallback;
    } catch {
      return fallback;
    }
  };
  const profile = read('radar.profile.v1', null);
  const items = read('radar.items.v1', initial.items);
  if (
    Array.isArray(items) &&
    items.every((item) => typeof item.id === 'string' && Array.isArray(item.ratings))
  )
    initial.items = items;
  if (profile?.id && profile.name) {
    initial.profiles.push(profile);
    initial.activeProfileId = profile.id;
  }
  const owner = profile?.id ?? 'guest';
  const favorites = read('radar.favorites.v1', []);
  initial.favorites[owner] = Array.isArray(favorites) ? favorites : [];
  const oldRatings = read('radar.ratings.v1', {});
  initial.ratings = Object.fromEntries(
    Object.entries(oldRatings)
      .filter(([, ballot]) => Array.isArray(ballot))
      .map(([id, ballot]) => [id, { [owner]: ballot }]),
  );
  const oldMessages = read('radar.messages.v1', []);
  if (Array.isArray(oldMessages)) {
    for (const message of oldMessages) {
      let partner = initial.profiles.find((candidate) => candidate.name === message.partner);
      if (!partner) {
        partner = {
          id: `legacy-${initial.profiles.length}`,
          name: message.partner,
          type: 'company',
          city: '',
          region: 'Podkarpackie',
          affiliation: 'Historia demo',
          avatar: '',
        };
        initial.profiles.push(partner);
      }
      let thread = initial.conversations.find(
        (thread) =>
          thread.participants.includes(message.owner) && thread.participants.includes(partner.id),
      );
      if (!thread) {
        thread = {
          id: `legacy-${initial.conversations.length}`,
          participants: [message.owner, partner.id],
          messages: [],
        };
        initial.conversations.push(thread);
      }
      thread.messages.push({
        id: message.id,
        senderId: message.owner,
        text: message.text,
        created: message.created,
      });
    }
  }
  return initial;
}
