# Radar innowacji — BETA 0.3

React + Node.js/Express + PostgreSQL. Dane kont, pomysłów, ocen, zgłoszeń i rozmów zapisuje backend. Przeglądarka przechowuje tylko preferencję motywu; sesja jest w ciasteczku HttpOnly.

## Lokalny start

Wymagany **Node.js 24+**. Otwórz terminal w tym folderze:

```sh
npm ci
npm run dev
```

Otwórz **http://localhost:3000**. React i API działają na tym samym hoście. Nie uruchamiaj równolegle drugiej instancji z tym samym katalogiem danych. Domyślnie używany jest **PGlite — lokalny PostgreSQL w WASM**, zapisujący dane na dysku w `.runtime/postgres`. Nie trzeba instalować Dockera, serwera PostgreSQL ani SMTP.

Menu **Zaloguj → Zaloguj profilem Demo** udostępnia przykładowe osoby i firmy. Administrator wymaga loginu **admin** i hasła **admin**. To konto działa wyłącznie w lokalnej bazie przykładowej. Konto rzeczywiste tworzysz przez **Zarejestruj**; po rejestracji interfejs wyświetla lokalny link weryfikacji e-maila. Gdy skonfigurujesz SMTP, linki będą wysyłane pocztą i nie będą zwracane przez API produkcyjne.

## Funkcje

- Konta prywatne i firmowe, niezmienny rodzaj konta, ustawienia profilu, profilowe JPG/PNG do 5 MB, zgoda na udostępnienie e-maila.
- Admin: publikacja, odrzucanie, archiwizacja i usuwanie pomysłów, wykaz kont, reset hasła, usuwanie kont, weryfikacja organizacji, awans osoby prywatnej na moderatora.
- Moderator: wyłącznie akceptacja lub odrzucenie oczekujących pomysłów. Autor może usunąć własny pomysł.
- Zgłoszenia pomysłów i wiadomości; dostęp admina do rozmowy tylko przez zgłoszenie. Zgłoszona wiadomość ma czerwone wyróżnienie.
- Blokada publikacji czasowa lub permanentna oraz wyciszenie 1 godzina–365 dni, z powodem i odliczaniem sekund. Suwak i ręczne dni/godziny/sekundy.
- Rozmowy rozpoczyna zweryfikowana firma; obaj uczestnicy mogą odpowiadać. E-mail autora wymaga dodatkowo jego zgody. Pozostałe osoby, również administrator bez zgłoszenia, nie mają dostępu do rozmowy.
- Załączniki PDF, DOCX, PPTX, JPG, PNG: do 10 plików i 20 MB łącznie na pomysł. Pobieranie pojedynczego pliku lub wszystkich jako ZIP. Starsze formaty `.doc` i `.ppt` należy przekonwertować do DOCX/PPTX.
- Ulubione, oceny 0,5–5 w czterech kategoriach, rzeczywiste agregaty bez przykładowych głosów, serwerowe filtry i paginacja. Oddzielny wybór rankingu według okresu publikacji lub okresu oddania aktualnych głosów.
- Menu konta zamykane kliknięciem poza nim i Escape, jasny/ciemny motyw, kontakt w stopce.

## Kod i testy

```text
frontend/
  api/                 klient HTTP i upload
  app/                 układ, routing, kontekst sesji, wybór dialogu
  components/          reużywalne elementy interfejsu
  features/            katalog, profile, rozmowy, moderacja, załączniki
  hooks/               nawigacja, filtry i pobieranie danych
  domain/              czyste funkcje ocen, filtrów i heurystyk
  styles/              tokeny, baza, układ, komponenty, motywy, dostępność
backend/
  db/                  schemat PostgreSQL, połączenie, dane przykładowe
  lib/                 walidacja, polityki dostępu, kryptografia
  middleware/          sesje i CSRF
  routes/              auth, ideas, community, admin, files
  services/            poczta, projekcje publiczne, skaner, retencja
  app.js               konfiguracja Express i API /api/v1
  server.js            jeden host dla API i Reacta
  maintenance.js       szyfrowane kopie i odtwarzanie
tests/                 testy domeny i integracyjne testy API
```

CSS korzysta z jawnych warstw `tokens → base → layout → components → utilities`. Motyw zmienia dziedziczone zmienne kolorów. Nie używa `!important` do rozwiązywania kaskady.

```sh
npm test
npm run build
npm run format:check
npm audit
```

Testy API używają oddzielnej bazy w pamięci i tymczasowych plików, bez zmian w Twoich danych lokalnych. Historyczny moduł `services/demoStorage.js` służy wyłącznie testom starego formatu; aplikacja go nie importuje i nie przenosi automatycznie niezweryfikowanych kont z localStorage.

## Opcjonalne pełne usługi

Jeśli zainstalujesz Docker, `docker compose up -d` uruchomi PostgreSQL, Mailpit i ClamAV na interfejsie lokalnym. Skopiuj `.env.example` do `.env` i ustaw `DATABASE_URL`, `SMTP_URL` oraz `CLAMAV_HOST`. Skrzynka Mailpit jest dostępna pod http://localhost:8025. ClamAV może potrzebować kilku minut na pobranie sygnatur. Zmiana `DATABASE_URL` wybiera inną bazę; nie migruje automatycznie obecnych danych PGlite.

## Bezpieczeństwo i przyszłe wdrożenie

Hasła: Argon2id. Sesje: losowe, przechowywane jako skróty, HttpOnly/SameSite=Strict, Secure w produkcji. MFA administratora: TOTP z ochroną przed ponownym użyciem kodu. API sprawdza uprawnienia z bazy, waliduje wejście, stosuje CSRF/Origin, limity żądań i zapytania parametryzowane. React koduje tekst użytkowników. E-maile nie są częścią publicznego katalogu. Pliki poza `dist` są szyfrowane AES-256-GCM i pobierane przez kontrolowane endpointy.

Lokalnie pliki przechodzą kontrolę sygnatur, rozmiaru, struktury Office oraz dekodowanie obrazów. **Bez ClamAV nie jest wykonywany skan antywirusowy.** Słownik wulgaryzmów działa na serwerze, lecz nadal jest heurystyką. Wyszukiwanie podobieństw analizuje maksymalnie 2000 ostatnich publicznych pomysłów; nie stanowi analizy patentowej.

Produkcja wymaga oddzielnej pustej bazy PostgreSQL, SMTP, ClamAV, HTTPS/reverse proxy, silnych sekretów oraz MFA administratora. Ustaw `NODE_ENV=production`, `ENABLE_EXAMPLES=false`, `APP_ORIGIN=https://...` i wszystkie wartości wskazane w `.env.example`; następnie `npm run build` i `npm start`. Serwer odmawia startu bez wymaganej konfiguracji lub przy obecności przykładowych kont. `admin/admin` nie jest dopuszczalne w produkcji. Sekret TOTP należy wcześniej wprowadzić do aplikacji uwierzytelniającej. Ogranicz dostęp sieciowy bezpośrednio do Node, bo konfiguracja ufa jednemu reverse proxy.

To lokalna BETA, nie potwierdzenie gotowości do publicznego wdrożenia. Testy przeprowadzono z PGlite; pełny PostgreSQL, SMTP, działający ClamAV, reverse proxy/TLS i środowisko wielu instancji wymagają testu integracyjnego przy wdrożeniu. Limiter działa w pamięci pojedynczej instancji — skalowanie wymaga współdzielonego magazynu limitów i plików. Każda organizacja ma `tenant_id`; członkostwa są bazą do dalszej obsługi wielu organizacji w jednym koncie, której obecny interfejs jeszcze nie udostępnia.

## Kopie i retencja

Zatrzymaj lokalny serwer przed operacjami na PGlite:

```sh
npm run backup
npm run retention
npm run restore -- C:/sciezka/radar-123.enc
```

Backup zawiera spójny obraz tabel i załączniki, jest szyfrowany AES-256-GCM, pomija sesje i tokeny, zachowuje siedem ostatnich kopii w `.runtime/backups`. Kopiuj backup poza komputer i **przechowuj klucz osobno**: lokalnie `.runtime/local.key`, produkcyjnie `DATA_ENCRYPTION_KEY`. Bez identycznego klucza nie odtworzysz kopii ani plików. Restore działa tylko na pustej bazie. Dla dużych produkcyjnych baz użyj zarządzanych kopii PostgreSQL/PITR; obecny eksport ładuje dane do pamięci. Harmonogram i zewnętrzny magazyn kopii konfiguruje operator.

Retencja działa przy starcie i co godzinę: usuwa wygasłe sesje/tokeny, nieprzypięte pliki po dobie, rozpatrzone zgłoszenia i audyt po `RETENTION_DAYS` (domyślnie 365). Usunięcie konta usuwa jego pomysły, głosy i ulubione; zachowane wiadomości rozmów mają usunięte powiązanie z nadawcą. Pliki osierocone są sprzątane po godzinie. Wiadomości starsze niż MESSAGE_RETENTION_DAYS (domyślnie 730 dni) są usuwane, chyba że dotyczą nierozpatrzonego zgłoszenia. Należy uwzględnić możliwość identyfikacji autora w samym tekście i obsługę wniosków o usunięcie. Kopie zachowują stan historyczny aż do rotacji.
