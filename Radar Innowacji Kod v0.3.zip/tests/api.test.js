import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';
import { configuration } from '../backend/config.js';
import { encryption } from '../backend/lib/crypto.js';
import { connectDatabase } from '../backend/db/connection.js';
import { seed } from '../backend/db/seed.js';
import { createApp } from '../backend/app.js';
import { durationSeconds } from '../backend/lib/policy.js';
import { unzipSync } from 'fflate';
import sharp from 'sharp';
import { TOTP, Secret } from 'otpauth';
let app, db, config, folder, examples, admin, privateUser, company, other;
const origin = 'http://localhost:3000';
async function client() {
  const agent = request.agent(app);
  let csrf = (await agent.get('/api/v1/auth/session')).body.csrf;
  return {
    get: (p) => agent.get('/api/v1' + p),
    send: async (p, body = {}, method = 'post') => {
      const response = await agent[method]('/api/v1' + p)
        .set('Origin', origin)
        .set('X-CSRF-Token', csrf)
        .send(body);
      if (response.body.csrf) csrf = response.body.csrf;
      return response;
    },
    agent,
    csrf: () => csrf,
  };
}
before(async () => {
  folder = await mkdtemp(path.join(os.tmpdir(), 'radar-test-'));
  config = configuration({
    memory: true,
    dataDir: folder,
    examples: true,
    testing: true,
    production: false,
  });
  const crypto = await encryption(config);
  db = await connectDatabase(config);
  await seed(db, config, crypto);
  app = createApp({ db, config, crypto });
  admin = await client();
  assert.equal(
    (await admin.send('/auth/login', { login: 'admin', password: 'admin' })).status,
    200,
  );
  examples = (await admin.get('/auth/examples')).body;
  const privates = examples.filter((u) => u.type === 'private' && u.role !== 'admin');
  privateUser = await client();
  privateUser.id = privates[0].id;
  await privateUser.send('/auth/example', { id: privateUser.id });
  other = await client();
  other.id = privates[1].id;
  await other.send('/auth/example', { id: other.id });
  company = await client();
  company.id = examples.find((u) => u.type === 'company').id;
  await company.send('/auth/example', { id: company.id });
});
after(async () => {
  await db?.close();
  if (folder) await rm(folder, { recursive: true, force: true });
});
test('anonymous cannot impersonate admin; CSRF and account access are enforced', async () => {
  const anon = await client();
  assert.equal(
    (await anon.send('/auth/example', { id: examples.find((u) => u.role === 'admin').id })).status,
    403,
  );
  assert.equal((await anon.get('/admin/users')).status, 401);
  assert.equal((await privateUser.get('/admin/users')).status, 403);
  assert.equal((await admin.agent.post('/api/v1/auth/logout').send({})).status, 403);
  assert.equal((await privateUser.send('/auth/profile', { role: 'admin' }, 'patch')).status, 400);
  const catalog = await anon.get('/ideas');
  assert.equal(catalog.status, 200);
  assert(!JSON.stringify(catalog.body).includes('password_hash'));
  assert(!JSON.stringify(catalog.body).includes('@'));
});
test('email verification and password reset tokens are one-use', async () => {
  const c = await client(),
    body = {
      login: 'newuser',
      email: 'new@example.invalid',
      password: 'long-password-123',
      name: 'Nowy Użytkownik',
      city: 'Bydgoszcz',
      region: 'Kujawsko-pomorskie',
      affiliation: 'student',
      type: 'private',
    };
  const registered = await c.send('/auth/register', body);
  assert.equal(registered.status, 201, JSON.stringify(registered.body));
  assert.equal(
    (await c.send('/auth/login', { login: body.login, password: body.password })).status,
    403,
  );
  const token = new URL(registered.body.developmentLink).searchParams.get('token');
  assert.equal((await c.send('/auth/token', { kind: 'verify', token })).status, 200);
  assert.equal((await c.send('/auth/token', { kind: 'verify', token })).status, 400);
  assert.equal(
    (await c.send('/auth/login', { login: body.login, password: body.password })).status,
    200,
  );
  const reset = await c.send('/auth/forgot', { email: body.email });
  const resetToken = new URL(reset.body.developmentLink).searchParams.get('token');
  assert.equal(
    (
      await c.send('/auth/token', {
        kind: 'reset',
        token: resetToken,
        password: 'different-password-123',
      })
    ).status,
    200,
  );
  assert.equal((await c.get('/admin/users')).status, 401);
});
let ideaId;
test('server moderates profanity, validates scores and computes actual aggregates', async () => {
  assert.equal(
    (
      await privateUser.send('/ideas', {
        title: 'Kurwiszcze testowe',
        description: 'To jest wystarczająco długi opis pomysłu testowego.',
        category: 'Technologia',
        stage: 'Pomysł',
      })
    ).status,
    400,
  );
  const created = await privateUser.send('/ideas', {
    title: 'Nowa innowacja testowa',
    description: 'Rozwiązanie problemu z pomiarami temperatury w miejscowości testowej.',
    category: 'Technologia',
    stage: 'Pomysł',
  });
  assert.equal(created.status, 201, JSON.stringify(created.body));
  ideaId = created.body.id;
  assert.equal((await other.get(`/ideas/${ideaId}`)).status, 403);
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/moderation`, { action: 'approve' }, 'patch')).status,
    403,
  );
  assert.equal(
    (await admin.send(`/ideas/${ideaId}/moderation`, { action: 'approve' }, 'patch')).status,
    200,
  );
  assert.equal(
    (await company.send(`/ideas/${ideaId}/rating`, { category: 0, value: 3.7 }, 'put')).status,
    400,
  );
  await company.send(`/ideas/${ideaId}/rating`, { category: 0, value: 4.5 }, 'put');
  await company.send(`/ideas/${ideaId}/rating`, { category: 0, value: 2.5 }, 'put');
  await other.send(`/ideas/${ideaId}/rating`, { category: 1, value: 5 }, 'put');
  const detail = (await privateUser.get(`/ideas/${ideaId}`)).body;
  assert.equal(detail.summary.overall, 3.75);
  assert.equal(detail.summary.voters, 2);
  assert.deepEqual(detail.ballot, [null, null, null, null]);
});
test('moderator can approve/reject, but cannot archive/delete/manage accounts', async () => {
  await admin.send(`/admin/users/${other.id}/role`, { role: 'moderator' }, 'patch');
  assert.equal((await other.get('/ideas?scope=moderation')).status, 200);
  assert.equal(
    (await other.send(`/ideas/${ideaId}/moderation`, { action: 'archive' }, 'patch')).status,
    403,
  );
  assert.equal((await other.send(`/ideas/${ideaId}`, {}, 'delete')).status, 403);
  assert.equal((await other.get('/admin/users')).status, 403);
  await admin.send(`/admin/users/${other.id}/role`, { role: 'user' }, 'patch');
});
test('contact requires verified organization and explicit consent', async () => {
  assert.equal((await privateUser.get(`/ideas/${ideaId}/contact`)).status, 403);
  await db.query('UPDATE users SET contact_consent=false WHERE id=$1', [privateUser.id]);
  assert.equal((await company.get(`/ideas/${ideaId}/contact`)).status, 403);
  await db.query('UPDATE users SET contact_consent=true WHERE id=$1', [privateUser.id]);
  assert.equal((await company.get(`/ideas/${ideaId}/contact`)).status, 200);
  await admin.send(`/admin/users/${company.id}/verification`, { verified: false }, 'patch');
  assert.equal((await company.get(`/ideas/${ideaId}/contact`)).status, 403);
  await admin.send(`/admin/users/${company.id}/verification`, { verified: true }, 'patch');
});
test('conversations are private; reported messages grant audited access to admin only', async () => {
  assert.equal((await privateUser.send('/conversations', { recipient: company.id })).status, 403);
  const created = await company.send('/conversations', { recipient: privateUser.id });
  assert.equal(created.status, 201);
  const id = created.body.id;
  assert.equal((await other.get(`/conversations/${id}`)).status, 403);
  assert.equal((await admin.get(`/conversations/${id}`)).status, 403);
  await company.send(`/conversations/${id}/messages`, {
    text: 'Dzień dobry, porozmawiajmy o pomyśle.',
  });
  const thread = (await privateUser.get(`/conversations/${id}`)).body;
  const message = thread.messages[0].id;
  assert.equal(
    (
      await other.send('/reports', {
        kind: 'message',
        targetId: message,
        reason: 'Próba odczytu cudzej rozmowy',
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await privateUser.send('/reports', {
        kind: 'message',
        targetId: message,
        reason: 'Test zgłoszenia wiadomości',
      })
    ).status,
    201,
  );
  const report = (await admin.get('/admin/reports?kind=message')).body.items[0];
  const context = await admin.get(`/admin/reports/${report.id}/context`);
  assert.equal(context.status, 200);
  assert.equal(context.body.reportedMessageId, message);
  assert.equal((await other.get(`/admin/reports/${report.id}/context`)).status, 403);
  assert(
    (await db.query("SELECT 1 FROM moderation_log WHERE action='report.conversation.read'")).rows
      .length,
  );
});
test('bans and mutes apply server-side, expire and respect maximum duration', async () => {
  assert.equal(durationSeconds({ days: 365 }, 'mute'), 31536000);
  assert.throws(() => durationSeconds({ days: 365, seconds: 1 }, 'mute'));
  assert.throws(() => durationSeconds({ permanent: true }, 'mute'));
  assert.equal(
    (
      await admin.send(`/admin/users/${privateUser.id}/sanctions`, {
        kind: 'post',
        reason: 'Powód blokady testowej',
        permanent: true,
      })
    ).status,
    200,
  );
  const result = await privateUser.send('/ideas', {
    title: 'Kolejna innowacja',
    description: 'Wystarczająco długi opis innowacji po blokadzie.',
    category: 'Technologia',
    stage: 'Pomysł',
  });
  assert.equal(result.status, 403);
  assert.equal(result.body.details.reason, 'Powód blokady testowej');
  await admin.send(`/admin/users/${privateUser.id}/sanctions/post`, {}, 'delete');
  await admin.send(`/admin/users/${company.id}/sanctions`, {
    kind: 'mute',
    reason: 'Powód wyciszenia testowego',
    hours: 1,
  });
  const id = (await company.get('/state')).body.conversations[0].id;
  assert.equal(
    (await company.send(`/conversations/${id}/messages`, { text: 'Zablokowana wiadomość' })).status,
    403,
  );
  await db.query("UPDATE sanctions SET expires_at=now()-interval '1 second' WHERE user_id=$1", [
    company.id,
  ]);
  assert.equal(
    (await company.send(`/conversations/${id}/messages`, { text: 'Po wygaśnięciu' })).status,
    201,
  );
});
test('uploads reject disguised files and protect unpublished attachments', async () => {
  const bad = await privateUser.agent
    .post('/api/v1/files/upload/idea')
    .set('Origin', origin)
    .set('X-CSRF-Token', privateUser.csrf())
    .attach('file', Buffer.from('<script>test</script>'), 'bad.pdf');
  assert.equal(bad.status, 400);
  const file = await privateUser.agent
    .post('/api/v1/files/upload/idea')
    .set('Origin', origin)
    .set('X-CSRF-Token', privateUser.csrf())
    .attach('file', Buffer.from('%PDF-1.7\n1 0 obj\n<<>>\nendobj\n%%EOF'), 'test.pdf');
  assert.equal(file.status, 201, JSON.stringify(file.body));
  assert.equal((await other.get(`/files/${file.body.id}`)).status, 403);
  assert.equal((await privateUser.get(`/files/${file.body.id}`)).status, 200);
});

test('opening a second tab preserves the first tab CSRF token', async () => {
  const previous = privateUser.csrf();
  const session = await privateUser.get('/auth/session');
  assert.equal(session.body.csrf, previous);
  assert.equal(
    (await privateUser.send(`/ideas/${ideaId}/favorite`, { active: true }, 'put')).status,
    200,
  );
});
test('registration avatar grant is single-use and cannot grant posting access', async () => {
  const c = await client();
  const registration = await c.send('/auth/register', {
    login: 'avatar-user',
    email: 'avatar@example.invalid',
    password: 'a-long-test-password',
    name: 'Zdjęcie Testowe',
    type: 'private',
    city: 'Toruń',
    region: 'Kujawsko-pomorskie',
    affiliation: 'student',
  });
  assert.equal(registration.status, 201);
  const png = await sharp({ create: { width: 16, height: 16, channels: 3, background: '#187c68' } })
    .png()
    .toBuffer();
  const post = (purpose) =>
    c.agent
      .post(`/api/v1/files/upload/${purpose}`)
      .set('Origin', origin)
      .set('X-CSRF-Token', c.csrf())
      .set('X-Registration-Token', registration.body.avatarTicket)
      .attach('file', png, 'avatar.png');
  assert.equal((await post('idea')).status, 401);
  const file = await post('avatar');
  assert.equal(file.status, 201, JSON.stringify(file.body));
  assert.equal((await post('avatar')).status, 403);
  assert.equal((await c.get(`/files/${file.body.id}?inline=1`)).status, 200);
  assert.equal((await c.send('/ideas', {})).status, 401);
});
test('ZIP contains authorized attachments and aggregate size is enforced', async () => {
  const ids = [];
  for (const name of ['pierwszy.pdf', 'drugi.pdf']) {
    const result = await privateUser.agent
      .post('/api/v1/files/upload/idea')
      .set('Origin', origin)
      .set('X-CSRF-Token', privateUser.csrf())
      .attach('file', Buffer.from('%PDF-1.7\n1 0 obj\n<<>>\nendobj\n%%EOF'), name);
    assert.equal(result.status, 201);
    ids.push(result.body.id);
  }
  await db.query('UPDATE attachments SET size=11000000 WHERE id=ANY($1::uuid[])', [ids]);
  const draft = {
    title: 'Innowacja z załącznikami',
    description: 'Nowe rozwiązanie testowe z dwoma dokumentami prezentującymi plan wdrożenia.',
    category: 'Technologia',
    stage: 'Pomysł',
    attachmentIds: ids,
  };
  assert.equal((await privateUser.send('/ideas', draft)).status, 413);
  await db.query('UPDATE attachments SET size=40 WHERE id=ANY($1::uuid[])', [ids]);
  const created = await privateUser.send('/ideas', draft);
  assert.equal(created.status, 201);
  const id = created.body.id;
  assert.equal((await other.get(`/files/innovation/${id}/zip`)).status, 403);
  await admin.send(`/ideas/${id}/moderation`, { action: 'approve' }, 'patch');
  const result = await other
    .get(`/files/innovation/${id}/zip`)
    .buffer(true)
    .parse((res, callback) => {
      const parts = [];
      res.on('data', (part) => parts.push(part));
      res.on('end', () => callback(null, Buffer.concat(parts)));
    });
  assert.equal(result.status, 200);
  assert.deepEqual(Object.keys(unzipSync(result.body)), ['1-pierwszy.pdf', '2-drugi.pdf']);
  assert.equal((await privateUser.send(`/ideas/${id}`, {}, 'delete')).status, 200);
  assert.equal((await other.get(`/files/${ids[0]}`)).status, 404);
});
test('admin MFA rejects missing and replayed codes', async () => {
  const crypto = await encryption(config),
    secret = new Secret(),
    totp = new TOTP({ secret });
  await db.query("UPDATE users SET mfa_secret=$1,mfa_last_step=NULL WHERE role='admin'", [
    crypto.seal(Buffer.from(secret.base32)).toString('base64'),
  ]);
  const c = await client();
  assert.equal((await c.send('/auth/login', { login: 'admin', password: 'admin' })).status, 401);
  const otp = totp.generate();
  assert.equal(
    (await c.send('/auth/login', { login: 'admin', password: 'admin', otp })).status,
    200,
  );
  assert.equal(
    (await c.send('/auth/login', { login: 'admin', password: 'admin', otp })).status,
    401,
  );
  await db.query("UPDATE users SET mfa_secret=NULL,mfa_last_step=NULL WHERE role='admin'");
});
test('reported old messages open the correct page of context', async () => {
  const report = (await admin.get('/admin/reports?kind=message')).body.items[0],
    message = (await db.query('SELECT * FROM messages WHERE id=$1', [report.message_id])).rows[0];
  await db.query(
    "INSERT INTO messages(id,conversation_id,sender_id,body,created_at) SELECT gen_random_uuid(),$1,$2,'Nowsza wiadomość testowa',now()+n*interval '1 second' FROM generate_series(1,51) AS n",
    [message.conversation_id, company.id],
  );
  const context = await admin.get(`/admin/reports/${report.id}/context`);
  assert.equal(context.status, 200);
  assert.equal(context.body.page, 2);
  assert(context.body.messages.some((m) => m.id === report.message_id));
});
