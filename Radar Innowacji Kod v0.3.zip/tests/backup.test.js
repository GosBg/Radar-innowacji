import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { configuration } from '../backend/config.js';
import { connectDatabase } from '../backend/db/connection.js';
import { encryption } from '../backend/lib/crypto.js';
import { seed } from '../backend/db/seed.js';

test('encrypted backup restores into an empty database and rejects overwriting data', async () => {
  const folder = await mkdtemp(path.join(os.tmpdir(), 'radar-backup-')),
    source = path.join(folder, 'source'),
    target = path.join(folder, 'target'),
    key = randomBytes(32).toString('base64');
  let db;
  try {
    const config = configuration({
      dataDir: source,
      encryptionKey: key,
      production: false,
      examples: true,
      databaseUrl: undefined,
    });
    db = await connectDatabase(config);
    await seed(db, config, await encryption(config));
    const count = (await db.query('SELECT count(*)::int AS total FROM users')).rows[0].total;
    await db.close();
    db = null;
    const env = {
      ...process.env,
      NODE_ENV: 'test',
      DATABASE_URL: '',
      DATA_ENCRYPTION_KEY: key,
      DATA_DIR: source,
      PORT: '43219',
    };
    const backup = spawnSync(process.execPath, ['backend/maintenance.js', 'backup'], {
      env,
      encoding: 'utf8',
    });
    assert.equal(backup.status, 0, backup.stderr);
    const filename = path.join(source, 'backups', (await readdir(path.join(source, 'backups')))[0]);
    assert(!(await readFile(filename)).includes(Buffer.from('Administrator')));
    const restored = spawnSync(process.execPath, ['backend/maintenance.js', 'restore', filename], {
      env: { ...env, DATA_DIR: target },
      encoding: 'utf8',
    });
    assert.equal(restored.status, 0, restored.stderr);
    db = await connectDatabase({ ...config, dataDir: target });
    assert.equal((await db.query('SELECT count(*)::int AS total FROM users')).rows[0].total, count);
    assert.equal((await db.query('SELECT count(*)::int AS total FROM sessions')).rows[0].total, 0);
    await db.close();
    db = null;
    const repeated = spawnSync(process.execPath, ['backend/maintenance.js', 'restore', filename], {
      env: { ...env, DATA_DIR: target },
      encoding: 'utf8',
    });
    assert.notEqual(repeated.status, 0);
    assert.match(repeated.stderr, /pustej bazy/);
  } finally {
    await db?.close();
    await rm(folder, { recursive: true, force: true });
  }
});
