import { Router } from 'express';
import { z } from 'zod';
import { route } from '../lib/errors.js';
import {
  asksForPrivateData,
  refusal,
  localAnswer,
  isHelpQuestion,
} from '../assistant/knowledge.js';
import { searchPublicCards } from '../assistant/search.js';
import { generateAnswer, aiConfigured } from '../assistant/model.js';
import { clearlyOffTopic, offTopicReply, relatedToRadar } from '../assistant/scope.js';
import { retrievalQuestion } from '../assistant/context.js';

const input = z
  .object({
    message: z.string().trim().min(1).max(1500),
    history: z
      .array(z.object({ role: z.enum(['user', 'assistant']), text: z.string().max(6000) }).strict())
      .max(6)
      .default([]),
  })
  .strict();

export function assistantRoutes({ db, config }) {
  const router = Router();
  let active = 0;
  router.get('/status', (req, res) =>
    res.json({
      aiConfigured: aiConfigured(config),
      provider: config.assistantProvider === 'openai' ? 'OpenAI' : 'Google Gemini',
    }),
  );
  router.post(
    '/',
    route(async (req, res) => {
      const { message, history } = input.parse(req.body);
      if (asksForPrivateData(message))
        return res.json({ answer: refusal, cards: [], mode: 'help' });
      if (clearlyOffTopic(message))
        return res.json({ answer: offTopicReply, cards: [], mode: 'help' });
      const cards = isHelpQuestion(message)
        ? []
        : await searchPublicCards(db, retrievalQuestion(message, history));
      if (aiConfigured(config) && active < 2) {
        active++;
        try {
          const answer = await generateAnswer(config, message, history, cards);
          return res.json({
            answer,
            cards: answer.includes(offTopicReply) ? [] : cards,
            mode: 'ai',
          });
        } catch {
          // Never expose provider responses, credentials or configuration in errors/logs.
        } finally {
          active--;
        }
      }
      res.json({
        answer:
          cards.length || relatedToRadar(message) ? localAnswer(message, cards) : offTopicReply,
        cards,
        mode: 'search',
        notice: aiConfigured(config)
          ? 'AI jest chwilowo niedostępne. Korzystam z wyszukiwania i pomocy strony.'
          : 'AI nie jest jeszcze podłączone. Działa wyszukiwanie i pomoc strony.',
      });
    }),
  );
  return router;
}
