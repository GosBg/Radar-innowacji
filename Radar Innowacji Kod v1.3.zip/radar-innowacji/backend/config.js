import 'dotenv/config';
import path from 'node:path';

export function configuration(overrides = {}) {
  const production = process.env.NODE_ENV === 'production';
  const config = {
    production,
    port: Number(process.env.PORT || 3000),
    host: process.env.HOST || '127.0.0.1',
    origin: process.env.APP_ORIGIN || 'http://localhost:3000',
    databaseUrl: process.env.DATABASE_URL,
    publicOrigin: process.env.PUBLIC_ORIGIN || '',
    serveBuild: process.env.SERVE_BUILD === 'true',
    dataDir: path.resolve(process.env.DATA_DIR || '.runtime'),
    examples: !production && process.env.ENABLE_EXAMPLES !== 'false',
    sessionHours: 12,
    retentionDays: Number(process.env.RETENTION_DAYS || 365),
    messageRetentionDays: Number(process.env.MESSAGE_RETENTION_DAYS || 730),
    encryptionKey: process.env.DATA_ENCRYPTION_KEY,
    smtpUrl: process.env.SMTP_URL,
    mailFrom: process.env.MAIL_FROM || 'admin@radarinnowacji.pl',
    clamHost: process.env.CLAMAV_HOST,
    clamPort: Number(process.env.CLAMAV_PORT || 3310),
    adminLogin: process.env.ADMIN_LOGIN,
    adminPassword: process.env.ADMIN_PASSWORD,
    adminEmail: process.env.ADMIN_EMAIL,
    adminTotp: process.env.ADMIN_TOTP_SECRET,
    geminiApiKey: process.env.GEMINI_API_KEY || '',
    assistantProvider: process.env.ASSISTANT_PROVIDER || 'gemini',
    openaiApiKey: process.env.OPENAI_API_KEY || '',
    openaiModel: process.env.OPENAI_MODEL || 'gpt-5.4-mini',
    assistantModel: process.env.ASSISTANT_MODEL || 'gemini-3.5-flash-lite',
    ...overrides,
  };
  if (
    config.publicOrigin &&
    (!config.publicOrigin.startsWith('https://') ||
      new URL(config.publicOrigin).origin !== config.publicOrigin)
  )
    throw new Error('PUBLIC_ORIGIN musi być dokładnym origin HTTPS bez ścieżki.');
  if (config.production) {
    for (const name of [
      'databaseUrl',
      'smtpUrl',
      'clamHost',
      'encryptionKey',
      'adminLogin',
      'adminPassword',
      'adminEmail',
      'adminTotp',
    ]) {
      if (!config[name]) throw new Error(`Brak konfiguracji produkcyjnej: ${name}`);
    }
    if (
      !config.origin.startsWith('https://') ||
      config.examples ||
      config.adminPassword.length < 12 ||
      config.adminPassword === 'admin'
    ) {
      throw new Error(
        'Produkcja wymaga HTTPS, mocnego hasła administratora i wyłączonych profili przykładowych.',
      );
    }
    if (Buffer.from(config.encryptionKey, 'base64').length !== 32)
      throw new Error('DATA_ENCRYPTION_KEY musi zawierać 32 losowe bajty w base64.');
  }
  return config;
}
