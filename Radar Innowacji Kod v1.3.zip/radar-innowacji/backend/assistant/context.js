/** Follow-up retrieval uses only user text, never model-generated SQL or identifiers. */
export function retrievalQuestion(message, history) {
  if (
    !/^(a |i |które|która|który|czy (one|ono|ta|ten|to)|opowiedz więcej|powiedz więcej|porównaj je)/i.test(
      message.trim(),
    )
  )
    return message;
  const previous = history
    .filter((item) => item.role === 'user')
    .slice(-2)
    .map((item) => item.text);
  return [message, ...previous].join(' ').slice(0, 3000);
}
