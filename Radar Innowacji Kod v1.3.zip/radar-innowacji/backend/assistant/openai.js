import { knowledge } from './knowledge.js';

export async function openaiAnswer(config, message, history, cards, fetcher) {
  const response = await fetcher('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.openaiApiKey}` },
    signal: AbortSignal.timeout(25000),
    body: JSON.stringify({
      model: config.openaiModel || 'gpt-5.4-mini',
      instructions: knowledge,
      store: false,
      max_output_tokens: 600,
      input: [
        ...history.map(({ role, text }) => ({ role, content: text })),
        { role: 'user', content: JSON.stringify({ question: message, publicCards: cards }) },
      ],
    }),
  });
  if (!response.ok) throw new Error('Model unavailable');
  const data = await response.json();
  const answer = data.output
    ?.filter((item) => item.type === 'message')
    .flatMap((item) => item.content || [])
    .filter((part) => part.type === 'output_text')
    .map((part) => part.text)
    .join('')
    .trim();
  if (!answer || data.status === 'incomplete') throw new Error('Incomplete model response');
  return answer.slice(0, 3000);
}
