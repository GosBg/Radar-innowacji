export const offTopicReply =
  'Do wyższych celów jestem stworzony! Zapytaj o coś związanego ze stroną.';

// Fast path for obvious unrelated requests. Ambiguous requests are judged by the model.
export function clearlyOffTopic(text) {
  if (/innowac|radar|technolog|katalog|rozwiązan|porówn|wdroże/i.test(text)) return false;
  return /(?:po ile|ile kosztuje|cena|ceny).{0,50}(?:paliw|benzyn|dies|ropy)|pogoda|horoskop|napisz.{0,25}(?:wiersz|bajkę|dowcip)|przepis na|wynik meczu|stolica (?:francji|niemiec)/i.test(
    text,
  );
}

export function relatedToRadar(text) {
  return /radar|innowac|stron|trl|dojrzało|ulubion|serdusz|porówn|komentar|ocen|gwiazdk|zalog|rejestr|konto|profil|źródł|katalog|rozwiązan|technolog|energia|energię|medyc|recykling|fotowolta/i.test(
    text,
  );
}
