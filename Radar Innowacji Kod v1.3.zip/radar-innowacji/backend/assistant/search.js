const ignored = new Set(
  'znajdź znajdz szukam pokaż pokaz proszę prosze jakie jest innowacje innowacji rozwiązania rozwiązanie temat chciałbym chciałabym mnie dla oraz czy jak się na do to i w z o mi'.split(
    ' ',
  ),
);
export function searchTerms(text) {
  return [
    ...new Set(
      (text.toLocaleLowerCase('pl').match(/[\p{L}\p{N}]{3,}/gu) || [])
        .filter((word) => !ignored.has(word))
        .map((word) => (word.length > 6 ? word.slice(0, -2) : word)),
    ),
  ].slice(0, 8);
}
/** Deliberately independent of the authenticated account and admin serializers. */
export async function searchPublicCards(db, message) {
  const terms = searchTerms(message);
  if (!terms.length) return [];
  const { rows } = await db.query(
    `
    SELECT i.id, i.title, left(i.description, 1000) AS description,
      i.category, i.stage, left(i.application, 400) AS application,
      i.assessment->>'trl' AS trl, i.assessment->>'trlKind' AS "trlKind"
    FROM innovations i
    CROSS JOIN LATERAL (
      SELECT count(*) AS score FROM unnest($1::text[]) term
      WHERE concat_ws(' ', i.title, i.description, i.category, i.application) ILIKE '%' || term || '%'
    ) matches
    WHERE i.status='published' AND i.owner_id IS NULL AND matches.score > 0
    ORDER BY matches.score DESC, i.published_at DESC NULLS LAST, i.id LIMIT 5
  `,
    [terms],
  );
  return rows;
}
