# RADARUŚ

## OpenAI zamiast Gemini

W `.env` lub sekretach hostingu ustaw `ASSISTANT_PROVIDER=openai`, `OPENAI_API_KEY` oraz opcjonalnie `OPENAI_MODEL=gpt-5.4-mini`. Zrestartuj backend. API ma osobne rozliczenie od ChatGPT Plus. Klucz utwórz na https://platform.openai.com/api-keys, a środki i rozliczenia ustaw na https://platform.openai.com/settings/organization/billing/overview. Nie wklejaj klucza do frontendu ani do repozytorium. Wybrany dostawca jest widoczny w informacji o prywatności czatu.

Odpowiedzi mają zwykle 2–4 krótkie zdania (instrukcja do 100 słów), limit generacji 600 tokenów i kontekst ostatnich 4 wiadomości, po maksymalnie 1200 znaków. Limit obejmuje generację, nie całkowity koszt pytania: płatne są również instrukcje, historia i karty wejściowe. OpenAI używa Responses API z `store:false`. To nie oznacza wyłączenia wszystkich logów bezpieczeństwa dostawcy.

Oczywiste pytania niezwiązane ze stroną (w tym ceny paliw) dostają stałą odpowiedź bez wywołania modelu: „Do wyższych celów jestem stworzony! Zapytaj o coś związanego ze stroną.” Inne przypadki ocenia model zgodnie z instrukcją zakresu; filtr regułowy nie rozpoznaje wszystkich możliwych parafraz. Dostęp do danych pozostaje ograniczony do publicznych kart niezależnie od klasyfikacji pytania.

Widget jest dostępny na każdej stronie, także bez logowania. Ukrywa się podczas każdego okna z `aria-modal="true"`. Rozmowa pozostaje w pamięci przeglądarki do przeładowania lub zmiany konta; przycisk czyszczenia usuwa ją od razu.

## Uruchomienie AI

1. Utwórz klucz Gemini w https://aistudio.google.com/api-keys. Nie przesyłaj go na czacie ani nie commituj.
2. W lokalnym `.env` w katalogu projektu ustaw `GEMINI_API_KEY=twój_klucz`. Domyślny model: `gemini-3.5-flash-lite`; zmienisz go przez `ASSISTANT_MODEL`.
3. Zrestartuj `npm run dev`. Na hostingu ustaw te same zmienne w sekretach backendu i uruchom ponownie usługę.

Potrzebny jest hosting obsługujący Node.js i PostgreSQL; samo statyczne hostowanie Reacta nie uruchomi backendu. Frontend korzysta z `/api/v1/assistant` na tym samym hoście. Nie wymaga Ollamy ani modelu na komputerze użytkownika.

Gemini oferuje ograniczony plan bezpłatny, ale limity i dostępność zależą od konta i modelu: https://ai.google.dev/gemini-api/docs/pricing. Nie włączaj płatności, jeśli oczekujesz wyłącznie darmowego użycia. Przy wyczerpaniu limitu, braku klucza lub awarii działa jawnie oznaczone wyszukiwanie lokalne i instrukcje strony. W darmowym planie Google może używać przesłanych treści do ulepszania produktów. Widget informuje o wysyłaniu rozmowy do Google; nie należy wpisywać danych poufnych. Przed publikacją uwzględnij dostawcę AI w polityce prywatności.

## Granica dostępu

To wyszukiwanie wspomagające model (RAG), nie trening modelu. Każde pytanie odczytuje maksymalnie pięć opublikowanych kart z bazy. SQL ma stały warunek `status='published' AND owner_id IS NULL` i jawny wybór kolumn. Asystent nie używa konta rozmówcy, serializerów administratora, danych użytkowników, wiadomości, zgłoszeń, źródeł konfiguracji ani narzędzi wykonujących polecenia. Nie ma możliwości zmiany danych. Uprawnienia są takie same dla gościa i administratora. Treści kart i historia są niezaufanymi danymi. Filtr pytań o prywatne dane jest tylko dodatkową odpowiedzią UX; bezpieczeństwo opiera się na braku tych danych w kontekście.

Odpowiedzi modelu są renderowane jako tekst, bez HTML i aktywnych linków. Przyciski prowadzą wyłącznie do kart zwróconych przez backend. API wymaga sesji i CSRF także dla gościa, ogranicza długość zapytań i historii, liczbę zapytań na IP oraz równoległych wywołań modelu (2 na proces). Timeout modelu wynosi 25 sekund. Nie zapisuje ani nie loguje rozmów czy błędów dostawcy. Przy wielu instancjach backendu należy zastosować wspólny magazyn limitów; limit lokalny nie stanowi globalnego limitu wydatków.

Instrukcje publicznej pomocy są w `knowledge.js`, zapytanie katalogu w `search.js`, komunikacja z dostawcą w `model.js`. Aktualizacja katalogu jest widoczna przy następnym pytaniu bez ponownego treningu. Odpowiedzi AI mogą być błędne; źródła i oznaczenia szacowanego TRL należy sprawdzać w karcie.
