import { knowledge } from './knowledge.js';
import { openaiAnswer } from './openai.js';

export function aiConfigured(config) {
  return Boolean(config.assistantProvider === 'openai' ? config.openaiApiKey : config.geminiApiKey);
}

export async function generateAnswer(config, message, history, cards, fetcher = fetch) {
  history = history.slice(-4).map((item) => ({ role: item.role, text: item.text.slice(0, 1200) }));
  if (config.assistantProvider === 'openai')
    return openaiAnswer(config, message, history, cards, fetcher);
  // Only this narrow, public projection leaves the server. No account/session/config context.
  const response = await fetcher(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.assistantModel)}:generateContent`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': config.geminiApiKey },
      signal: AbortSignal.timeout(25000),
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: knowledge }] },
        contents: [
          ...history.map(({ role, text }) => ({
            role: role === 'assistant' ? 'model' : 'user',
            parts: [{ text }],
          })),
          {
            role: 'user',
            parts: [{ text: JSON.stringify({ question: message, publicCards: cards }) }],
          },
        ],
        generationConfig: { temperature: 0.2, maxOutputTokens: 600 },
      }),
    },
  );
  if (!response.ok) throw new Error('Model unavailable');
  const data = await response.json();
  const answer = data.candidates?.[0]?.content?.parts
    ?.filter((part) => !part.thought)
    .map((part) => part.text || '')
    .join('')
    .trim();
  if (!answer) throw new Error('Empty model response');
  return answer.slice(0, 6000);
}
