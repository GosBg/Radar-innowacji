import React, { useEffect, useRef, useState } from 'react';
import { MessageCircle, Send, X, RotateCcw } from 'lucide-react';
import { useRadar } from '../../app/RadarContext.jsx';
import { api } from '../../api/client.js';
import RadarAvatar from './RadarAvatar.jsx';
import useModalVisibility from './useModalVisibility.js';

const welcome = {
  role: 'assistant',
  text: 'Cześć! Jestem RADARUŚ. Pomogę Ci znaleźć innowacje i odnaleźć się na stronie. Czego szukasz?',
};
const suggestions = [
  'Znajdź rozwiązania dla energii',
  'Co oznacza TRL?',
  'Jak porównywać innowacje?',
];

export default function AssistantWidget() {
  const { profile, ready, navigation } = useRadar();
  // Changing account unmounts the conversation and cancels requests.
  return (
    <Conversation key={profile?.id || 'guest'} ready={ready} onOpenCard={navigation.showIdea} />
  );
}

function Conversation({ ready, onOpenCard }) {
  const [open, setOpen] = useState(false),
    [messages, setMessages] = useState([welcome]);
  const [text, setText] = useState(''),
    [busy, setBusy] = useState(false),
    [status, setStatus] = useState(null);
  const modalVisible = useModalVisibility();
  const input = useRef(null),
    launcher = useRef(null),
    bottom = useRef(null),
    controller = useRef(null);
  useEffect(() => () => controller.current?.abort(), []);
  useEffect(() => {
    if (!open) return;
    const abort = new AbortController();
    api('/assistant/status', { signal: abort.signal })
      .then(setStatus)
      .catch(() => {});
    return () => abort.abort();
  }, [open]);
  useEffect(() => {
    if (open && !modalVisible) input.current?.focus();
  }, [open, modalVisible]);
  useEffect(() => {
    if (open && !modalVisible) bottom.current?.scrollIntoView({ block: 'nearest' });
  }, [messages, busy, open, modalVisible]);
  function close() {
    setOpen(false);
    requestAnimationFrame(() => launcher.current?.focus());
  }
  function clear() {
    controller.current?.abort();
    controller.current = null;
    setBusy(false);
    setMessages([welcome]);
    setText('');
    input.current?.focus();
  }
  async function send(value) {
    const question = value.trim();
    if (!question || busy || !ready) return;
    const abort = new AbortController();
    controller.current = abort;
    const history = messages
      .filter((m) => !m.error)
      .slice(-6)
      .map(({ role, text }) => ({ role, text }));
    setMessages((m) => [...m, { role: 'user', text: question }]);
    setText('');
    setBusy(true);
    try {
      const result = await api('/assistant', {
        method: 'POST',
        body: { message: question, history },
        signal: abort.signal,
      });
      if (!abort.signal.aborted)
        setMessages((m) => [...m, { role: 'assistant', text: result.answer, ...result }]);
    } catch (error) {
      if (!abort.signal.aborted)
        setMessages((m) => [...m, { role: 'assistant', text: error.message, error: true }]);
    } finally {
      if (controller.current === abort) {
        controller.current = null;
        setBusy(false);
        input.current?.focus();
      }
    }
  }
  return (
    <aside className="radar-assistant" hidden={modalVisible} aria-label="Pomoc RADARUSIA">
      {open && (
        <section
          className="radarus-panel"
          role="dialog"
          aria-modal="false"
          aria-labelledby="radarus-title"
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.stopPropagation();
              close();
            }
          }}
        >
          <header className="radarus-header">
            <RadarAvatar />
            <div>
              <strong id="radarus-title">RADARUŚ AI</strong>
              <small>Twój przewodnik po innowacjach</small>
            </div>
            <button
              type="button"
              onClick={clear}
              aria-label="Wyczyść rozmowę"
              title="Wyczyść rozmowę"
            >
              <RotateCcw size={18} />
            </button>
            <button type="button" onClick={close} aria-label="Zamknij rozmowę">
              <X size={20} />
            </button>
          </header>
          <div className="radarus-status">
            {status === null
              ? 'Sprawdzam połączenie…'
              : status.aiConfigured
                ? 'AI · odpowiedzi na podstawie publicznych kart'
                : 'Wyszukiwanie i pomoc · AI niepodłączone'}
          </div>
          <div
            className="radarus-messages"
            role="log"
            aria-label="Rozmowa z RADARUSIEM"
            aria-live="polite"
            aria-relevant="additions"
          >
            {messages.map((message, i) => (
              <div key={i} className={`radarus-message radarus-message--${message.role}`}>
                {message.role === 'assistant' && <RadarAvatar />}
                <div>
                  <p>{message.text}</p>
                  {message.notice && <small className="radarus-notice">{message.notice}</small>}
                  {message.cards?.map((card) => (
                    <button
                      type="button"
                      className="radarus-card"
                      key={card.id}
                      onClick={() => onOpenCard(card.id)}
                    >
                      {card.title}
                      <small>Otwórz kartę →</small>
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {busy && (
              <div className="radarus-typing" role="status">
                <RadarAvatar />
                <span>
                  RADARUŚ szuka odpowiedzi<span className="radarus-dots">…</span>
                </span>
              </div>
            )}
            <div ref={bottom} />
          </div>
          {messages.length === 1 && (
            <div className="radarus-suggestions">
              {suggestions.map((s) => (
                <button type="button" key={s} disabled={!ready || busy} onClick={() => send(s)}>
                  {s}
                </button>
              ))}
            </div>
          )}
          <form
            className="radarus-form"
            onSubmit={(e) => {
              e.preventDefault();
              send(text);
            }}
          >
            <label className="sr-only" htmlFor="radarus-question">
              Twoje pytanie
            </label>
            <textarea
              id="radarus-question"
              ref={input}
              rows={2}
              maxLength={1500}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Czego szukasz na Radarze?"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                  e.preventDefault();
                  send(text);
                }
              }}
            />
            <button
              type="submit"
              disabled={busy || !ready || !text.trim()}
              aria-label="Wyślij pytanie"
            >
              <Send size={20} />
            </button>
          </form>
          <small className="radarus-privacy">
            AI może się mylić — sprawdzaj źródła w kartach.{' '}
            {status?.aiConfigured
              ? `Treść rozmowy jest wysyłana do ${status.provider || 'dostawcy AI'}. Nie wpisuj danych poufnych.`
              : 'Rozmowa nie jest zapisywana na Twoim koncie.'}
          </small>
        </section>
      )}
      {!open && (
        <button
          type="button"
          ref={launcher}
          className="radarus-launcher"
          onClick={() => setOpen(true)}
          aria-label="Zapytaj RADARUSIA AI"
          aria-expanded={open}
        >
          <MessageCircle size={25} />
          <span>Zapytaj RADARUSIA AI</span>
        </button>
      )}
    </aside>
  );
}
