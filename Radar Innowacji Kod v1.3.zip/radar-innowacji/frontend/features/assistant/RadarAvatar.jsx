import React from 'react';

export default function RadarAvatar() {
  return (
    <svg className="radarus-avatar" viewBox="0 0 64 64" aria-hidden="true">
      <circle cx="32" cy="32" r="31" fill="#d8f3e9" />
      <path d="M32 16V9" stroke="#187c68" strokeWidth="3" />
      <circle cx="32" cy="8" r="4" fill="#e8b54d" />
      <rect x="9" y="25" width="7" height="16" rx="3" fill="#187c68" />
      <rect x="48" y="25" width="7" height="16" rx="3" fill="#187c68" />
      <rect x="14" y="17" width="36" height="34" rx="13" fill="#187c68" />
      <path
        d="M21 31a11 11 0 0 1 22 0M25 31a7 7 0 0 1 14 0"
        fill="none"
        stroke="#80dfc0"
        strokeWidth="2"
      />
      <path d="m32 31 7-9" stroke="#e8b54d" strokeWidth="2" strokeLinecap="round" />
      <circle cx="24" cy="35" r="3" fill="white" />
      <circle cx="40" cy="35" r="3" fill="white" />
      <path d="M27 42q5 5 10 0" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" />
      <circle cx="20" cy="41" r="2" fill="#eba3a6" />
      <circle cx="44" cy="41" r="2" fill="#eba3a6" />
    </svg>
  );
}
