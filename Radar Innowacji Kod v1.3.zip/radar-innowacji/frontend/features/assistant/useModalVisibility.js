import { useEffect, useState } from 'react';

export default function useModalVisibility() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const check = () => setVisible(Boolean(document.querySelector('[aria-modal="true"]')));
    const observer = new MutationObserver(check);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['aria-modal'],
    });
    check();
    return () => observer.disconnect();
  }, []);
  return visible;
}
