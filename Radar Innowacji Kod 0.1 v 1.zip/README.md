# Radar innowacji

Responsywny prototyp React + Vite dla wyzwania Podkarpackiego Centrum Innowacji podczas HackNation 2026.

## Uruchomienie

Wymagany Node.js 20.19+ lub 22.12+.

```sh
npm install
npm run dev
```

Kompilacja: `npm run build`. Podgląd kompilacji: `npm run preview`.

## Zakres

Katalog z sześcioma fikcyjnymi przykładami, wyszukiwanie, kategorie, filtry czasu, autora, województwa i ocen, ranking okresu publikacji, ulubione, szczegóły pomysłu, oceny co pół gwiazdki, lokalny profil osoby lub organizacji, formularz zgłoszenia, moderacja, archiwizacja, usuwanie z potwierdzeniem, ostrzeżenie o podobnych słowach, demonstracyjny filtr wulgaryzmów, lokalna skrzynka wiadomości i zakładka dalszego rozwoju.

Widoki kont i korespondencji są symulacją — bez rzeczywistych haseł, e-maili i wysyłki. Dane zapisują się wyłącznie w localStorage. Przycisk „Demo moderatora” umożliwia prezentację procesu. Szczegółowe wymagania następnego etapu znajdują się w backend/README.md.

Wszystkie przykładowe pomysły, autorzy, statystyki i oceny są fikcyjne; nazwy miejscowości służą demonstracji filtrów. Grafiki kart są autorskimi kompozycjami CSS z ikonami Lucide. Fonty DM Sans i Manrope są opcjonalnie pobierane z Google Fonts, z lokalnym fallbackiem sans-serif.

## Scenariusze demonstracji

1. Utwórz profil osoby, zgłoś pomysł, otwórz Demo moderatora, zaakceptuj, wróć do katalogu i oceń opublikowany pomysł.
2. Zmień profil na firmowy, znajdź pomysł filtrami, dodaj do ulubionych i rozpocznij lokalną rozmowę demonstracyjną.
3. Zgłoś opis podobny do istniejącej innowacji; moderator zobaczy ostrzeżenie i link do porównania. Przetestuj także archiwizację i anulowanie usunięcia.

Nie tworzyłem prezentacji konkursowej ani filmu z PDF — są odrębnymi materiałami, poza aktualną prośbą o stronę.
