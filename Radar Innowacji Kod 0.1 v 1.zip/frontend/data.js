export const regions=['Dolnośląskie','Kujawsko-pomorskie','Lubelskie','Lubuskie','Łódzkie','Małopolskie','Mazowieckie','Opolskie','Podkarpackie','Podlaskie','Pomorskie','Śląskie','Świętokrzyskie','Warmińsko-mazurskie','Wielkopolskie','Zachodniopomorskie'];
export const criteria=['Dalszy rozwój','Transfer','Komercjalizacja','Wdrożenie'];
export const times=[['Teraz',0],['Godzinę temu',1/24],['5 godzin temu',5/24],['10 godzin temu',10/24],['24 godziny temu',1],['3 dni temu',3],['5 dni temu',5],['Tydzień temu',7],['2 tygodnie temu',14],['Miesiąc temu',30],['3 miesiące temu',90],['6 miesięcy temu',180],['Rok temu',365],['2 lata temu',730]];
const now=Date.now();
export const seeds=[
['Zielona energia','Inteligentne ławki, które zasilają miasto','Modułowe ławki solarne łączą odpoczynek, ładowanie urządzeń i monitoring jakości powietrza.','Politechnika Rzeszowska','Rzeszów','Podkarpackie','company',2,[4.5,4,4.5,5],'solar','Prototyp'],
['Zdrowie','Mały sensor. Wielki krok dla rehabilitacji.','Lekki czujnik ruchu wspiera domową rehabilitację i pomaga fizjoterapeutom śledzić postępy pacjenta.','Anna Kowalska','Bydgoszcz','Kujawsko-pomorskie','private',.2,[5,4,4.5,4.5],'health','W fazie testów'],
['Edukacja','Laboratorium dostępne dla każdej szkoły','Mobilny zestaw doświadczeń pozwala uczniom odkrywać naukę bez kosztownego wyposażenia sal.','Fundacja Otwarta Nauka','Kraków','Małopolskie','company',5,[4,5,4,4.5],'education','Gotowe do wdrożenia'],
['Smart city','Deszczówka, która nie idzie na marne','System czujników i zbiorników pomaga samorządom wykorzystać wodę opadową do podlewania zieleni.','Michał Nowak','Mielec','Podkarpackie','private',12,[4,4,4.5,4],'water','Prototyp'],
['Technologia','Drugie życie materiałów z druku 3D','Lokalny obieg odzyskiwania filamentu zmienia odpady z pracowni w surowiec do kolejnych projektów.','ReLab','Poznań','Wielkopolskie','company',45,[4.5,4,5,4],'tech','W fazie testów'],
['Społeczeństwo','Sąsiedzka sieć dobrych spraw','Prosty system wymiany umiejętności łączy mieszkańców i przeciwdziała samotności seniorów.','Julia Wiśniewska','Gdańsk','Pomorskie','private',.03,[4.5,5,3,4.5],'social','Pomysł']
].map((a,i)=>({id:String(i+1),category:a[0],title:a[1],description:a[2],author:a[3],city:a[4],region:a[5],type:a[6],created:now-a[7]*86400000,ratings:a[8],art:a[9],stage:a[10],status:'published',votes:12+i*7,owner:'seed'+i}));
