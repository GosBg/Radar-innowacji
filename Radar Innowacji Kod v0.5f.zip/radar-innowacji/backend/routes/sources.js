import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { route, ensure, HttpError } from '../lib/errors.js';
import { requireRole, audit } from '../lib/policy.js';
import { validateUrl } from '../research/fetch.js';
import { testSource } from '../research/connectors.js';
const input = z.object({
  name: z.string().trim().min(3).max(120),
  url: z.string().url().max(1000),
  connector: z.enum(['html', 'rss', 'ncbr', 'pending']),
  enabled: z.boolean(),
  interval_hours: z.number().int().min(1).max(720).default(24),
  config: z
    .object({
      linkSelector: z.string().max(200).optional(),
      contentSelector: z.string().max(200).optional(),
    })
    .default({}),
});
function safeUrl(url) {
  try {
    return validateUrl(url);
  } catch (e) {
    throw new HttpError(400, e.message);
  }
}
export function sourceRoutes({ db }) {
  const router = Router();
  router.use((req, res, next) => {
    try {
      requireRole(req, 'admin');
      next();
    } catch (e) {
      next(e);
    }
  });
  router.get(
    '/',
    route(async (req, res) =>
      res.json({
        worker: (
          await db.query(
            "SELECT heartbeat_at,heartbeat_at>now()-interval '90 seconds' AS online FROM worker_status WHERE id='research'",
          )
        ).rows[0] || { online: false },
        items: (await db.query('SELECT * FROM research_sources ORDER BY name')).rows,
        runs: (
          await db.query(
            'SELECT r.*,s.name FROM source_runs r JOIN research_sources s ON s.id=r.source_id ORDER BY started_at DESC LIMIT 50',
          )
        ).rows,
      }),
    ),
  );
  router.post(
    '/',
    route(async (req, res) => {
      const data = input.parse(req.body);
      safeUrl(data.url);
      ensure(data.connector !== 'pending' || !data.enabled, 400, 'Najpierw skonfiguruj konektor.');
      const id = randomUUID();
      await db.query(
        'INSERT INTO research_sources(id,name,url,connector,enabled,interval_hours,config) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [
          id,
          data.name,
          data.url,
          data.connector,
          data.enabled,
          data.interval_hours,
          JSON.stringify(data.config),
        ],
      );
      await audit(db, req.user, 'source.create', id, { name: data.name });
      res.status(201).json({ id });
    }),
  );
  router.patch(
    '/:id',
    route(async (req, res) => {
      const id = z.string().uuid().parse(req.params.id),
        data = input.parse(req.body);
      safeUrl(data.url);
      ensure(data.connector !== 'pending' || !data.enabled, 400, 'Najpierw skonfiguruj konektor.');
      const result = await db.query(
        'UPDATE research_sources SET name=$2,url=$3,connector=$4,enabled=$5,interval_hours=$6,next_run_at=CASE WHEN $5 AND NOT enabled THEN now() ELSE next_run_at END,config=config || $7::jsonb WHERE id=$1 RETURNING id',
        [
          id,
          data.name,
          data.url,
          data.connector,
          data.enabled,
          data.interval_hours,
          JSON.stringify(data.config),
        ],
      );
      ensure(result.rows.length, 404, 'Brak źródła.');
      await audit(db, req.user, 'source.update', id);
      res.json({ ok: true });
    }),
  );
  router.post(
    '/:id/run',
    route(async (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      const source = (await db.query('SELECT * FROM research_sources WHERE id=$1', [id])).rows[0];
      ensure(source?.enabled && source.connector !== 'pending', 400, 'Włącz obsługiwane źródło.');
      await db.query(
        'UPDATE research_sources SET next_run_at=now(),requested_at=now() WHERE id=$1',
        [id],
      );
      await audit(db, req.user, 'source.enqueue', id);
      res.status(202).json({ message: 'Zaplanowano pobranie. Worker sprawdza kolejkę co minutę.' });
    }),
  );
  router.post(
    '/:id/test',
    route(async (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      const source = (await db.query('SELECT * FROM research_sources WHERE id=$1', [id])).rows[0];
      ensure(source && source.connector !== 'pending', 400, 'Brak obsługi tego źródła.');
      try {
        res.json(await testSource(source));
      } catch (e) {
        throw new HttpError(422, `Test źródła nie powiódł się: ${e.message}`);
      }
    }),
  );
  return router;
}
