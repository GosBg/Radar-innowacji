import React, { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import Button from '../../components/ui/Button.jsx';
import SourceForm from './SourceForm.jsx';
const states = {
  running: 'W toku',
  success: 'OK',
  partial: 'Częściowy sukces',
  error: 'Błąd',
  interrupted: 'Przerwany',
};
const date = (v) => (v ? new Date(v).toLocaleString('pl') : 'Jeszcze nie wykonano');
export default function SourcesPage() {
  const [data, setData] = useState({ items: [], runs: [] }),
    [editing, setEditing] = useState(undefined),
    [notice, setNotice] = useState(''),
    [busy, setBusy] = useState('');
  async function refresh() {
    setData(await api('/admin/sources'));
  }
  useEffect(() => {
    refresh().catch((e) => setNotice(e.message));
    const t = setInterval(() => refresh().catch(() => {}), 10000);
    return () => clearInterval(t);
  }, []);
  async function action(source, kind) {
    setBusy(source.id);
    setNotice(
      kind === 'test' ? 'Sprawdzanie dostępu i przykładowego artykułu…' : 'Zlecanie pobrania…',
    );
    try {
      const r = await api(`/admin/sources/${source.id}/${kind}`, { method: 'POST' });
      setNotice(r.message || `Test OK: ${r.links} linków. Przykład: ${r.sample.title}`);
      await refresh();
    } catch (e) {
      setNotice(e.message);
    } finally {
      setBusy('');
    }
  }
  return (
    <main className="simple-page" id="main-content">
      <div className="eyebrow dark">ZARZĄDZANIE RESEARCH</div>
      <h1>Źródła i aktualizacje</h1>
      <p>
        Trwały harmonogram w PostgreSQL. Domyślny cykl co 24 godziny; po uruchomieniu worker
        nadrabia zaległe zadania. Lokalnie komputer i proces muszą być włączone.
      </p>
      <p className="notice">
        Analiza regułowa v3: wskazujemy źródła i niepewność. Brak podłączonego modelu AI. Bazy
        patentowe i naukowe wymagają dedykowanych integracji.
      </p>
      <p role="status" className="notice">
        {data.worker?.online
          ? 'Worker działa — harmonogram jest obsługiwany.'
          : 'Brak sygnału workera. Uruchom npm run dev lub npm run worker na serwerze.'}
      </p>
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      {editing !== undefined ? (
        <SourceForm
          key={editing?.id || 'new'}
          source={editing}
          onCancel={() => setEditing(undefined)}
          onSave={async (form) => {
            await api(`/admin/sources${editing ? '/' + editing.id : ''}`, {
              method: editing ? 'PATCH' : 'POST',
              body: form,
            });
            setEditing(undefined);
            await refresh();
          }}
        />
      ) : (
        <Button onClick={() => setEditing(null)}>Dodaj źródło</Button>
      )}
      <div className="sources-list">
        {data.items.map((s) => (
          <article className="manage-row" key={s.id}>
            <div>
              <h3>{s.name}</h3>
              <a href={s.url} target="_blank" rel="noopener noreferrer">
                Otwórz źródło ↗
              </a>
              <p>
                <span className="tag">
                  {s.connector === 'pending'
                    ? 'Do integracji'
                    : s.enabled
                      ? 'Aktywne'
                      : 'Wstrzymane'}
                </span>{' '}
                · {s.interval_hours} h · {s.connector}
              </p>
              <small>
                Ostatnie poprawne pobranie: {date(s.last_success_at)}
                <br />
                Następna próba:{' '}
                {s.connector === 'pending'
                  ? 'Brak konektora'
                  : s.enabled
                    ? date(s.next_run_at)
                    : 'Wstrzymana przez administratora'}
              </small>
              {s.connector === 'pending' && (
                <p className="notice">
                  To wpis planowanej integracji. Test i pobieranie będą dostępne po podłączeniu
                  konektora; samo włączenie nie tworzy integracji.
                </p>
              )}
              {s.last_error && <p className="field-error">{s.last_error}</p>}
            </div>
            <div className="row-actions">
              <Button variant="outline" onClick={() => setEditing(s)}>
                Edytuj
              </Button>
              <Button
                variant="outline"
                disabled={!!busy || s.connector === 'pending'}
                onClick={() => action(s, 'test')}
              >
                {busy === s.id ? 'Przetwarzanie…' : 'Testuj'}
              </Button>
              <Button
                disabled={!!busy || !s.enabled || s.connector === 'pending'}
                onClick={() => action(s, 'run')}
              >
                Odśwież teraz
              </Button>
            </div>
          </article>
        ))}
      </div>
      <h2>Ostatnie przebiegi</h2>
      {!data.runs.length && <p>Worker jeszcze nie rozpoczął pobierania.</p>}
      {data.runs.map((r) => (
        <div className="run-row" key={r.id}>
          <b>{r.name}</b>
          <span>
            {date(r.started_at)} · {states[r.status] || r.status} · sprawdzono {r.discovered} ·
            zmieniono {r.updated}
          </span>
          {r.error && <p className="field-error">{r.error}</p>}
        </div>
      ))}
    </main>
  );
}
