import React, { useState } from 'react';
import Button from '../../components/ui/Button.jsx';
const blank = {
  name: '',
  url: '',
  connector: 'html',
  enabled: false,
  interval_hours: 24,
  config: { linkSelector: 'article a', contentSelector: 'article' },
};
export default function SourceForm({ source, onSave, onCancel }) {
  const [form, setForm] = useState(source || blank),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const change = (key, value) => setForm((s) => ({ ...s, [key]: value }));
  return (
    <form
      className="source-form"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        try {
          await onSave(form);
        } catch (e) {
          setError(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2>{source ? 'Edytuj źródło' : 'Dodaj źródło'}</h2>
      <label>
        Nazwa
        <input
          required
          maxLength={120}
          value={form.name}
          onChange={(e) => change('name', e.target.value)}
        />
      </label>
      <label>
        Adres listy lub kanału HTTPS
        <input
          type="url"
          required
          value={form.url}
          onChange={(e) => change('url', e.target.value)}
        />
      </label>
      <label>
        Konektor
        <select value={form.connector} onChange={(e) => change('connector', e.target.value)}>
          <option value="html">Lista HTML → artykuły</option>
          <option value="rss">RSS / Atom → artykuły HTML</option>
          <option value="ncbr">NCBR — sukcesy beneficjentów</option>
          <option value="pending">Do integracji (API / inny format)</option>
        </select>
      </label>
      <div className="two-fields">
        <label>
          Selektor odnośników
          <input
            value={form.config.linkSelector || ''}
            onChange={(e) => change('config', { ...form.config, linkSelector: e.target.value })}
          />
        </label>
        <label>
          Selektor treści artykułu
          <input
            value={form.config.contentSelector || ''}
            onChange={(e) => change('config', { ...form.config, contentSelector: e.target.value })}
          />
        </label>
      </div>
      <label>
        Odstęp cykli (godziny)
        <input
          type="number"
          min={1}
          max={720}
          value={form.interval_hours}
          onChange={(e) => change('interval_hours', +e.target.value)}
        />
      </label>
      <label className="compare-check">
        <input
          type="checkbox"
          checked={form.enabled}
          onChange={(e) => change('enabled', e.target.checked)}
        />
        Włącz automatyczne pobieranie
      </label>
      <p className="muted">
        Włączone: worker pobiera kolejne partie i ponawia pełny cykl co wybraną liczbę godzin.
        Wyłączone: zachowuje karty, ale wstrzymuje następne cykle. Test sprawdza źródło bez
        importowania kart.
      </p>
      <p className="muted">
        Dodawaj źródła, których warunki pozwalają na pobieranie. Robot respektuje robots.txt.
        Serwisy wymagające logowania, klucza API, PDF lub JavaScript potrzebują osobnego konektora.
      </p>
      {error && (
        <p className="field-error" role="alert">
          {error}
        </p>
      )}
      <div className="row-actions">
        <Button disabled={busy}>{busy ? 'Zapisywanie…' : 'Zapisz źródło'}</Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Anuluj
        </Button>
      </div>
    </form>
  );
}
