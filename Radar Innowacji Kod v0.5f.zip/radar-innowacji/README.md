# Radar innowacji — BETA 0.4

React + Node.js/Express + **natywny PostgreSQL** + osobny proces workera.
Radar odkrywa istniejące rozwiązania w źródłach; konta nie publikują nowych pomysłów.

## Uruchomienie lokalne

Wymagany Node.js 24 lub nowszy. W katalogu projektu:

```sh
npm install
npm run dev
```

Polecenie uruchamia lokalny serwer PostgreSQL, API, React i worker. Pakiet `embedded-postgres` dostarcza prawdziwe binaria PostgreSQL — nie jest PGlite ani bazą WASM. Na Windows baza jest inicjalizowana w UTF-8. Dane pozostają po zamknięciu aplikacji.

Adres domyślny: http://localhost:3000. Jeśli port jest zajęty, launcher wybiera http://localhost:3001 i wypisuje adres. Backend i frontend mają wspólny origin. PostgreSQL nasłuchuje wyłącznie na `127.0.0.1:55432`; hasło generowane jest losowo i przechowywane poza frontendem w `.runtime/postgres-password`.

Nie uruchamiaj dwóch launcherów dla tego samego katalogu danych. Zatrzymuj je przez Ctrl+C. Nie usuwaj `.runtime`, jeśli chcesz zachować konta, źródła i wyniki researchu.

Możesz użyć własnego PostgreSQL: ustaw `DATABASE_URL` w `.env`. Wtedy launcher nie uruchamia własnej bazy. Przykładowe usługi PostgreSQL, Mailpit i ClamAV znajdują się w `compose.yaml`.

## Konta

**Zaloguj → Zaloguj profilem przykładowym** zawiera konta prywatne, firmowe i administratora. Lokalne konto administratora: login `admin`, hasło `admin`. Jego wybór nie omija formularza hasła.

Rejestracja rzeczywistych kont wymaga potwierdzenia e-maila. Bez SMTP lokalnie wyświetlany jest jednorazowy link weryfikacji/resetu; produkcyjne API go nie ujawnia. Hasła: Argon2id. Sesje: HttpOnly, SameSite, Secure na produkcji; operacje zapisu wymagają CSRF. Rodzaj konta jest niezmienny. Zdjęcia JPG/PNG do 5 MB są sprawdzane i ponownie kodowane.

Konta mogą oceniać potencjał (0,5–5), zapisywać ulubione, komentować i odpowiadać na komentarze główne. Ocena zastępuje poprzednią ocenę tego samego użytkownika w danej kategorii. Gwiazdki nie są dowodem dojrzałości ani wdrożenia.

Administrator zarządza źródłami, kontami, resetami haseł, rolami, zgłoszeniami i wyciszeniami komentowania od 1 godziny do 365 dni. Moderator może przeglądać karty i moderować publiczne komentarze; nie może zarządzać kontami ani źródłami. Archiwizacja i usunięcie karty wymagają administratora. Usunięta karta nie wraca automatycznie z tego samego URL — importer zapisuje wykluczenie.

## Research i cykl 24 h

1. Worker sprawdza harmonogram w PostgreSQL co minutę.
2. Pobiera listę dokumentów z aktywnego źródła i respektuje `robots.txt`.
3. Przetwarza kolejne partie po maksymalnie 20 dokumentów, zachowując kursor w bazie. Między partiami ma minutę przerwy; między pobraniami minimum sekundę lub wymagany crawl-delay.
4. Każdy pełny cykl jest ponawiany po skonfigurowanym odstępie, domyślnie 24 godzinach. Pełny cykl dużej bazy trwa dłużej niż jedna partia. Limit odkrywania wynosi 2000 odnośników na listę; konektory wielostronicowe należy rozszerzyć o paginację.
5. Adres i hash treści pozwalają rozpoznać aktualizację. Niezmieniona treść nie uruchamia ponownej klasyfikacji. Zmiana wersji klasyfikatora również powoduje ponowną analizę.
6. Aktualizowana jest ta sama karta, więc oceny, komentarze i ulubione pozostają. Poprzedni stan trafia do historii. Dokładna nazwa i znany twórca mogą powiązać kolejne źródło z kartą; podobieństwo leksykalne jest wyłącznie sygnałem dla moderatora.
7. Błędy pojedynczych stron są zapisywane, a pozostałe strony są przetwarzane. Błąd całej listy uruchamia ponowienia z odstępem 5–360 minut. Blokada PostgreSQL zapobiega równoczesnemu wykonaniu przez dwa workery. Po awarii zadanie jest podejmowane ponownie; zapisane już karty są rozpoznawane po URL.

Harmonogram działa tylko przy uruchomionym procesie. Laptop uśpiony przez dobę nie wykona researchu; zaległości ruszą po uruchomieniu. Na hostingu uruchom `npm start` i `npm run worker` jako osobne stale działające procesy ze wspólnym `DATABASE_URL`.

## Obsługiwane źródła i granice prototypu

- **NCBR — sukcesy beneficjentów:** działający konektor, aktywny od pierwszego uruchomienia. Dane są rzeczywiście pobierane, nie są to przykładowe innowacje.
- **HTML:** administrator podaje adres listy oraz selektory CSS odnośników i treści artykułu. Linki muszą prowadzić do tej samej domeny.
- **RSS/Atom:** odnośniki prowadzące do artykułów HTML w tej samej domenie. Przetwarzanie artykułów korzysta z konfigurowalnego selektora.
- **UPRP, EPO, PBN, PPM, PAN, BazTol, Interreg, CORDIS:** wpisy w rejestrze mają stan „Do integracji”. Nie udajemy, że ekran wyszukiwarki jest publicznym API. Integracje API, autoryzacja, paginacja i formaty tych usług wymagają osobnych adapterów oraz weryfikacji warunków dostępu. Google Scholar nie jest automatycznie scrapowany.
- PDF, dokumenty Office, renderowanie stron JavaScript, wyszukiwanie semantyczne i model AI nie są jeszcze podłączone. Konektory nie wykonują kodu pochodzącego ze źródeł.

Aktualna klasyfikacja to jawnie oznaczona **analiza regułowa v3**. Rozpoznaje obszar technologiczny, edukacyjny lub administracyjny oraz niektóre rodzaje podmiotów. Etap i TRL wymagają fragmentu źródłowego; brak danych oznacza „Nie ustalono”, a dla domen nietechnologicznych TRL nie jest stosowany. Reguły mogą popełniać błędy — karta pokazuje źródło i ograniczenia. Obecny panel nie jest uniwersalnym kreatorem dowolnych integracji.

Karty pokazują twórcę/beneficjenta oddzielnie od wydawcy źródła, problem, zastosowania, ocenę dojrzałości, źródła, datę publikacji (jeśli dostępną), odczytu, odkrycia i zmian. Brak potwierdzonego statusu IP pozostaje jawny. Polski beneficjent nie jest dowodem polskiego IP. Rekomendowany kolejny krok jest oznaczony jako sugestia.

Wyszukiwanie i filtry wykonywane są na serwerze. Porównanie obejmuje 2–4 karty. Ranking daty odkrycia jest oddzielony od rankingu ocen oddanych w danym okresie. Wybrany zestaw porównania jest przechowywany tylko w bieżącej sesji przeglądarki.

## Struktura kodu

```text
frontend/
  app/                  stan aplikacji, nawigacja, dialogi
  components/           reużywalne kontrolki, układ, karty, gwiazdki
  features/catalog/     katalog i filtry
  features/research/    źródła, dowody, porównanie, komentarze
  features/profiles/    rejestracja i logowanie
  features/moderation/  konta i zgłoszenia
  styles/               kaskada @layer: tokens, base, layout, components, utilities
backend/
  db/                   schemat, rozszerzenie researchu, startowe konta
  research/             fetch, konektory, klasyfikacja, pipeline, źródła
  routes/               wersjonowane /api/v1
  services/             poczta, retencja, projekcje, skanowanie
  middleware/           sesje i CSRF
  worker.js             osobny proces harmonogramu
scripts/                uruchamianie lokalnego PostgreSQL i testów
tests/                  testy domeny, API, importu, kopii i uprawnień
```

Stare formularze dodawania innowacji, prywatne wiadomości oraz ich endpointy zostały usunięte. Dawne tabele pozostawiono nieaktywne w schemacie dla niedestrukcyjnej zgodności ze starszym PostgreSQL; nie są używane przez nowy interfejs. Katalog publiczny wybiera rekordy researchu bez właściciela-konta. Stara baza PGlite w `.runtime/postgres`, jeśli istnieje, nie jest używana, automatycznie konwertowana ani usuwana.

## Sprawdzenie

```sh
npm test
npm run build
npm run format:check
```

`npm test` uruchamia osobny natywny PostgreSQL na porcie 55433, tworzy izolowane bazy i sprawdza m.in. sesje/CSRF/MFA, komentarze, wyciszenia, zachowanie ocen przy aktualizacji, brak odtworzenia usuniętych kart oraz szyfrowane kopie. Testy nie wymagają pobierania z zewnętrznych stron i nie modyfikują lokalnej bazy użytkownika.

## Kopie i retencja

Kopie są szyfrowane AES-256-GCM. Zachowywanych jest 7 ostatnich plików. Klucz szyfrowania przechowuj oddzielnie od kopii. Sesje i tokeny nie są kopiowane. Kopia obejmuje karty, źródła, historię i komentarze; odtwarzanie wymaga pustej bazy.

```sh
npm run backup
npm run restore -- /sciezka/do/kopii.enc
npm run retention
```

Polecenia utrzymaniowe wymagają `DATABASE_URL`. Przy lokalnym PostgreSQL uruchomionym przez launcher adres buduje się z loginu `radar`, portu `LOCAL_PG_PORT`, bazy `radar` i hasła z `.runtime/postgres-password`; nie umieszczaj tego hasła w kodzie ani repozytorium.

Retencja usuwa wygasłe sesje/tokeny, nieprzypięte pliki po dobie oraz zakończone zgłoszenia i audyt po `RETENTION_DAYS`. Usunięcie konta usuwa jego oceny i ulubione, anonimizuje powiązanie komentarzy z kontem i nie usuwa innowacji. Treść komentarza może nadal zawierać dane wpisane ręcznie — wymaga to obsługi wniosku o usunięcie. Rotacja kopii określa czas zachowania historycznych danych.

## Wdrożenie publiczne

Ta wersja pozostaje lokalną BETĄ. Produkcja wymaga oddzielnego PostgreSQL, HTTPS, SMTP, ClamAV, klucza szyfrowania, silnego hasła i MFA administratora oraz `ENABLE_EXAMPLES=false`. Konfiguracja odrzuca produkcyjne uruchomienie z kontami przykładowymi lub bez wymaganych sekretów.

Dostęp do źródeł blokuje prywatne adresy IP, niebezpieczne protokoły, dane logowania w URL, przekierowania poza domenę, nadmierne rozmiary i czas odpowiedzi. Zapytania SQL są parametryzowane, role pochodzą z sesji serwera. Limiter działa w pamięci jednej instancji: wiele instancji wymaga wspólnego magazynu limitów i plików. Lokalnie bez ClamAV nie ma skanu antywirusowego — pozostaje kontrola typu i dekodowanie obrazów. Przed publikacją potrzebny jest test docelowej infrastruktury, polityka retencji i kontrola uprawnień do korzystania ze źródeł.

## Tunel ngrok i hosting

Tuneluj cały serwer Express, nie osobny serwer Vite ani sam katalog dist. W `.env` ustaw `PUBLIC_ORIGIN=https://yasmine-unambulant-sha.ngrok-free.dev` oraz `SERVE_BUILD=true`. Następnie `npm run build` i `npm run dev`. Skieruj ngrok na dokładnie ten port, który wypisze launcher (np. `ngrok http 3001`). Ten sam proces obsługuje `/api/v1` i React, więc katalog i konta korzystają z tej samej bazy. Po zmianie `.env` zrestartuj proces i odśwież stronę. Nigdy nie ustawiaj dowolnego Origin ani nie wyłączaj CSRF.

Przy PUBLIC_ORIGIN cookie ma Secure i działa przez HTTPS (lokalnie otwieraj localhost w przeglądarce obsługującej Secure na localhost). Adres publiczny jest jawną listą dozwoloną. `SERVE_BUILD=true` usuwa zależność od publicznego WebSocket HMR. Przykładowe konta, szczególnie admin/admin, służą lokalnym testom: przed publiczną prezentacją zmień hasło administratora lub użyj odrębnej bazy produkcyjnej z wyłączonymi przykładami. Sam ngrok nie zapewnia całodobowego hostingu — komputer i worker nadal muszą działać.

`Włącz automatyczne pobieranie` aktywuje harmonogram obsługiwanego źródła. Włączenie po przerwie planuje najbliższy cykl. `Testuj` sprawdza listę i przykładowy dokument bez zapisu kart; `Odśwież teraz` zapisuje żądanie do harmonogramu, realizowane przez workera najpóźniej po zakończeniu bieżącej partii i kolejnym sprawdzeniu kolejki. Panel pokazuje sygnał życia workera. Wpisy „Do integracji” nie mają jeszcze konektora i nie mogą pobierać danych — przełącznik nie zastępuje implementacji API danego serwisu.

TRL jest niezależny od domeny zastosowania. Technologia edukacyjna może mieć TRL. Poziom ze źródła jest odróżniony od regułowego szacunku opartego na opisie walidacji. Brak informacji nie jest zamieniany na fikcyjną ocenę. Nowa analiza obejmuje kolejne aktualizowane karty, więc istniejące rekordy odświeżają się wraz z postępem cyklu workera.
